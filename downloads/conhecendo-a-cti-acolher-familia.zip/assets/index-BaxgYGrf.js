const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/FamilyWelcome-wbhGX3ID.js","assets/react-vendor-CycvGi9z.js","assets/FamilyWelcome-BhvNenP7.css","assets/BookReader-B-owekCN.js","assets/BookReader-iSPfZ99S.css","assets/PdfReader-D-tbJd6c.js","assets/PdfReader-BCyel6lV.css"])))=>i.map(i=>d[i]);
import{r as d,j as e,c as vo,R as xo}from"./react-vendor-CycvGi9z.js";(function(){const o=document.createElement("link").relList;if(o&&o.supports&&o.supports("modulepreload"))return;for(const r of document.querySelectorAll('link[rel="modulepreload"]'))n(r);new MutationObserver(r=>{for(const i of r)if(i.type==="childList")for(const t of i.addedNodes)t.tagName==="LINK"&&t.rel==="modulepreload"&&n(t)}).observe(document,{childList:!0,subtree:!0});function s(r){const i={};return r.integrity&&(i.integrity=r.integrity),r.referrerPolicy&&(i.referrerPolicy=r.referrerPolicy),r.crossOrigin==="use-credentials"?i.credentials="include":r.crossOrigin==="anonymous"?i.credentials="omit":i.credentials="same-origin",i}function n(r){if(r.ep)return;r.ep=!0;const i=s(r);fetch(r.href,i)}})();const go="modulepreload",bo=function(a){return"/"+a},za={},ja=function(o,s,n){let r=Promise.resolve();if(s&&s.length>0){let t=function(h){return Promise.all(h.map(f=>Promise.resolve(f).then(C=>({status:"fulfilled",value:C}),C=>({status:"rejected",reason:C}))))};document.getElementsByTagName("link");const u=document.querySelector("meta[property=csp-nonce]"),m=(u==null?void 0:u.nonce)||(u==null?void 0:u.getAttribute("nonce"));r=t(s.map(h=>{if(h=bo(h),h in za)return;za[h]=!0;const f=h.endsWith(".css"),C=f?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${h}"]${C}`))return;const b=document.createElement("link");if(b.rel=f?"stylesheet":go,f||(b.as="script"),b.crossOrigin="",b.href=h,m&&b.setAttribute("nonce",m),document.head.appendChild(b),f)return new Promise((A,y)=>{b.addEventListener("load",A),b.addEventListener("error",()=>y(new Error(`Unable to preload CSS for ${h}`)))})}))}function i(t){const u=new Event("vite:preloadError",{cancelable:!0});if(u.payload=t,window.dispatchEvent(u),!u.defaultPrevented)throw t}return r.then(t=>{for(const u of t||[])u.status==="rejected"&&i(u.reason);return o().catch(i)})};/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const jo=a=>a.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),Wa=(...a)=>a.filter((o,s,n)=>!!o&&o.trim()!==""&&n.indexOf(o)===s).join(" ").trim();/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var Co={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const qo=d.forwardRef(({color:a="currentColor",size:o=24,strokeWidth:s=2,absoluteStrokeWidth:n,className:r="",children:i,iconNode:t,...u},m)=>d.createElement("svg",{ref:m,...Co,width:o,height:o,stroke:a,strokeWidth:n?Number(s)*24/Number(o):s,className:Wa("lucide",r),...u},[...t.map(([h,f])=>d.createElement(h,f)),...Array.isArray(i)?i:[i]]));/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const P=(a,o)=>{const s=d.forwardRef(({className:n,...r},i)=>d.createElement(qo,{ref:i,iconNode:o,className:Wa(`lucide-${jo(a)}`,n),...r}));return s.displayName=`${a}`,s};/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const me=P("Activity",[["path",{d:"M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2",key:"169zse"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Le=P("ArrowLeft",[["path",{d:"m12 19-7-7 7-7",key:"1l729n"}],["path",{d:"M19 12H5",key:"x3x0zl"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const R=P("ArrowRight",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const T=P("ArrowUpRight",[["path",{d:"M7 7h10v10",key:"1tivn9"}],["path",{d:"M7 17 17 7",key:"1vkiza"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const D=P("BookOpen",[["path",{d:"M12 7v14",key:"1akyts"}],["path",{d:"M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z",key:"ruj8y"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ao=P("BookmarkCheck",[["path",{d:"m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2Z",key:"169p4p"}],["path",{d:"m9 10 2 2 4-4",key:"1gnqz4"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Pe=P("Bookmark",[["path",{d:"m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16z",key:"1fy3hk"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ja=P("Brain",[["path",{d:"M12 5a3 3 0 1 0-5.997.125 4 4 0 0 0-2.526 5.77 4 4 0 0 0 .556 6.588A4 4 0 1 0 12 18Z",key:"l5xja"}],["path",{d:"M12 5a3 3 0 1 1 5.997.125 4 4 0 0 1 2.526 5.77 4 4 0 0 1-.556 6.588A4 4 0 1 1 12 18Z",key:"ep3f8r"}],["path",{d:"M15 13a4.5 4.5 0 0 1-3-4 4.5 4.5 0 0 1-3 4",key:"1p4c4q"}],["path",{d:"M17.599 6.5a3 3 0 0 0 .399-1.375",key:"tmeiqw"}],["path",{d:"M6.003 5.125A3 3 0 0 0 6.401 6.5",key:"105sqy"}],["path",{d:"M3.477 10.896a4 4 0 0 1 .585-.396",key:"ql3yin"}],["path",{d:"M19.938 10.5a4 4 0 0 1 .585.396",key:"1qfode"}],["path",{d:"M6 18a4 4 0 0 1-1.967-.516",key:"2e4loj"}],["path",{d:"M19.967 17.484A4 4 0 0 1 18 18",key:"159ez6"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const xe=P("Check",[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Za=P("ChevronDown",[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const No=P("ChevronRight",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Y=P("ClipboardCheck",[["rect",{width:"8",height:"4",x:"8",y:"2",rx:"1",ry:"1",key:"tgr4d6"}],["path",{d:"M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2",key:"116196"}],["path",{d:"m9 14 2 2 4-4",key:"df797q"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const So=P("ClipboardList",[["rect",{width:"8",height:"4",x:"8",y:"2",rx:"1",ry:"1",key:"tgr4d6"}],["path",{d:"M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2",key:"116196"}],["path",{d:"M12 11h4",key:"1jrz19"}],["path",{d:"M12 16h4",key:"n85exb"}],["path",{d:"M8 11h.01",key:"1dfujw"}],["path",{d:"M8 16h.01",key:"18s6g9"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Po=P("ClipboardPenLine",[["rect",{width:"8",height:"4",x:"8",y:"2",rx:"1",key:"1oijnt"}],["path",{d:"M8 4H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-.5",key:"1but9f"}],["path",{d:"M16 4h2a2 2 0 0 1 1.73 1",key:"1p8n7l"}],["path",{d:"M8 18h1",key:"13wk12"}],["path",{d:"M21.378 12.626a1 1 0 0 0-3.004-3.004l-4.01 4.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z",key:"2t3380"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const pe=P("Download",[["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}],["polyline",{points:"7 10 12 15 17 10",key:"2ggqvy"}],["line",{x1:"12",x2:"12",y1:"15",y2:"3",key:"1vk2je"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ca=P("Eye",[["path",{d:"M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0",key:"1nclc0"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const yo=P("FilePenLine",[["path",{d:"m18 5-2.414-2.414A2 2 0 0 0 14.172 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2",key:"142zxg"}],["path",{d:"M21.378 12.626a1 1 0 0 0-3.004-3.004l-4.01 4.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z",key:"2t3380"}],["path",{d:"M8 18h1",key:"13wk12"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const qa=P("FileText",[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"M10 9H8",key:"b1mrlr"}],["path",{d:"M16 13H8",key:"t4e002"}],["path",{d:"M16 17H8",key:"z1uh3a"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const fe=P("GraduationCap",[["path",{d:"M21.42 10.922a1 1 0 0 0-.019-1.838L12.83 5.18a2 2 0 0 0-1.66 0L2.6 9.08a1 1 0 0 0 0 1.832l8.57 3.908a2 2 0 0 0 1.66 0z",key:"j76jl0"}],["path",{d:"M22 10v6",key:"1lu8f3"}],["path",{d:"M6 12.5V16a6 3 0 0 0 12 0v-3.5",key:"1r8lef"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ya=P("HeartHandshake",[["path",{d:"M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z",key:"c3ymky"}],["path",{d:"M12 5 9.04 7.96a2.17 2.17 0 0 0 0 3.08c.82.82 2.13.85 3 .07l2.07-1.9a2.82 2.82 0 0 1 3.79 0l2.96 2.66",key:"4oyue0"}],["path",{d:"m18 15-2-2",key:"60u0ii"}],["path",{d:"m15 18-2-2",key:"6p76be"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ne=P("HeartPulse",[["path",{d:"M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z",key:"c3ymky"}],["path",{d:"M3.22 12H9.5l.5-1 2 4.5 2-7 1.5 3.5h5.27",key:"1uw2ng"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const aa=P("House",[["path",{d:"M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8",key:"5wwlr5"}],["path",{d:"M3 10a2 2 0 0 1 .709-1.528l7-5.999a2 2 0 0 1 2.582 0l7 5.999A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",key:"1d0kgt"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ka=P("Info",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 16v-4",key:"1dtifu"}],["path",{d:"M12 8h.01",key:"e9boi3"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const fa=P("Languages",[["path",{d:"m5 8 6 6",key:"1wu5hv"}],["path",{d:"m4 14 6-6 2-3",key:"1k1g8d"}],["path",{d:"M2 5h12",key:"or177f"}],["path",{d:"M7 2h1",key:"1t2jsx"}],["path",{d:"m22 22-5-10-5 10",key:"don7ne"}],["path",{d:"M14 18h6",key:"1m8k6r"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Eo=P("Layers",[["path",{d:"M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z",key:"zw3jo"}],["path",{d:"M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12",key:"1wduqc"}],["path",{d:"M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17",key:"kqbvx6"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Mo=P("LayoutGrid",[["rect",{width:"7",height:"7",x:"3",y:"3",rx:"1",key:"1g98yp"}],["rect",{width:"7",height:"7",x:"14",y:"3",rx:"1",key:"6d4xhi"}],["rect",{width:"7",height:"7",x:"14",y:"14",rx:"1",key:"nxv5o0"}],["rect",{width:"7",height:"7",x:"3",y:"14",rx:"1",key:"1bb6yr"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ve=P("Library",[["path",{d:"m16 6 4 14",key:"ji33uf"}],["path",{d:"M12 6v14",key:"1n7gus"}],["path",{d:"M8 8v12",key:"1gg7y9"}],["path",{d:"M4 4v16",key:"6qkkli"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Io=P("ListChecks",[["path",{d:"m3 17 2 2 4-4",key:"1jhpwq"}],["path",{d:"m3 7 2 2 4-4",key:"1obspn"}],["path",{d:"M13 6h8",key:"15sg57"}],["path",{d:"M13 12h8",key:"h98zly"}],["path",{d:"M13 18h8",key:"oe0vm4"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ro=P("List",[["path",{d:"M3 12h.01",key:"nlz23k"}],["path",{d:"M3 18h.01",key:"1tta3j"}],["path",{d:"M3 6h.01",key:"1rqtza"}],["path",{d:"M8 12h13",key:"1za7za"}],["path",{d:"M8 18h13",key:"1lx6n3"}],["path",{d:"M8 6h13",key:"ik3vkj"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const eo=P("MessageCircle",[["path",{d:"M7.9 20A9 9 0 1 0 4 16.1L2 22Z",key:"vv11sd"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const zo=P("Monitor",[["rect",{width:"20",height:"14",x:"2",y:"3",rx:"2",key:"48i651"}],["line",{x1:"8",x2:"16",y1:"21",y2:"21",key:"1svkeh"}],["line",{x1:"12",x2:"12",y1:"17",y2:"21",key:"vw1qmm"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ko=P("Presentation",[["path",{d:"M2 3h20",key:"91anmk"}],["path",{d:"M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3",key:"2k9sn8"}],["path",{d:"m7 21 5-5 5 5",key:"bip4we"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const To=P("Printer",[["path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2",key:"143wyd"}],["path",{d:"M6 9V3a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v6",key:"1itne7"}],["rect",{x:"6",y:"14",width:"12",height:"8",rx:"1",key:"1ue0tg"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const he=P("RotateCcw",[["path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",key:"1357e3"}],["path",{d:"M3 3v5h5",key:"1xhq8a"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ha=P("Search",[["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}],["path",{d:"m21 21-4.3-4.3",key:"1qie3q"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const $e=P("ShieldCheck",[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const va=P("Stethoscope",[["path",{d:"M11 2v2",key:"1539x4"}],["path",{d:"M5 2v2",key:"1yf1q8"}],["path",{d:"M5 3H4a2 2 0 0 0-2 2v4a6 6 0 0 0 12 0V5a2 2 0 0 0-2-2h-1",key:"rb5t3r"}],["path",{d:"M8 15a6 6 0 0 0 12 0v-3",key:"x18d4x"}],["circle",{cx:"20",cy:"10",r:"2",key:"ts1r5v"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const wo=P("Syringe",[["path",{d:"m18 2 4 4",key:"22kx64"}],["path",{d:"m17 7 3-3",key:"1w1zoj"}],["path",{d:"M19 9 8.7 19.3c-1 1-2.5 1-3.4 0l-.6-.6c-1-1-1-2.5 0-3.4L15 5",key:"1exhtz"}],["path",{d:"m9 11 4 4",key:"rovt3i"}],["path",{d:"m5 19-3 3",key:"59f2uf"}],["path",{d:"m14 4 6 6",key:"yqp9t2"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ao=P("Users",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["path",{d:"M16 3.13a4 4 0 0 1 0 7.75",key:"1da9ce"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Oo=P("WifiOff",[["path",{d:"M12 20h.01",key:"zekei9"}],["path",{d:"M8.5 16.429a5 5 0 0 1 7 0",key:"1bycff"}],["path",{d:"M5 12.859a10 10 0 0 1 5.17-2.69",key:"1dl1wf"}],["path",{d:"M19 12.859a10 10 0 0 0-2.007-1.523",key:"4k23kn"}],["path",{d:"M2 8.82a15 15 0 0 1 4.177-2.643",key:"1grhjp"}],["path",{d:"M22 8.82a15 15 0 0 0-11.288-3.764",key:"z3jwby"}],["path",{d:"m2 2 20 20",key:"1ooewy"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Do=P("Wind",[["path",{d:"M12.8 19.6A2 2 0 1 0 14 16H2",key:"148xed"}],["path",{d:"M17.5 8a2.5 2.5 0 1 1 2 4H2",key:"1u4tom"}],["path",{d:"M9.8 4.4A2 2 0 1 1 11 8H2",key:"75valh"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const _e=P("X",[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]]),Fo=[{id:"cuidados-paciente-critico",title:"Cuidados com o paciente crítico",href:"/materiais/apostilas/cuidados-paciente-critico.pdf",sourceName:"Apostila_Cuidados_Paciente_Critico_CTI_Adulto[1].pdf",sourceSha256:"1907ec5fac6d7a096c9c1c340fd8b4c51cd142bf8bbfd4efb77a21e0e0656c7f",sourceBytes:10238106,sha256:"cc4befd2a5e038f21f58978c83c496cc6b68561f311f6c898e83f29daf953f23",bytes:10232257,pages:26,paletteChanges:{"#102e47 → #a73344":1,"#123b56 → #a73344":31,"#133b55 → #a73344":48,"#143b55 → #a73344":4,"#146c8d → #a73344":11,"#14809b → #738275":1,"#16809a → #738275":48,"#18708c → #a73344":96,"#476879 → #596b5e":1,"#547286 → #596b5e":26,"#bdd2dc → #e1e7df":48,"#c1d4dc → #e1e7df":26,"#edf6f8 → #f1f3ed":4,"#f2f7f9 → #f1f3ed":48},auxiliaryCredentialsRemovedFromAdaptedCopy:["Content Credentials"],validation:{allPagesChecked:26,textExact:!0,textCharacters:23076,fontBytesAndTextGeometryExact:!0,imageBytesAndGeometryExact:!0,images:11,linksAndGeometryExact:!0,links:18,pageDimensionsExact:!0,authorAndReferenceMetadataExact:!0,onlyKnownRgbOperatorsAndClearMarginStripeChanged:!0,colorOperatorsChanged:393,topMarginStripes:26,clinicalReviewPerformed:!1,antivirusScanPerformed:!1}},{id:"curativos-feridas",title:"Curativos e cuidados com feridas",href:"/materiais/apostilas/curativos-feridas.pdf",sourceName:"Apostila_Curativos_e_Cuidados_com_Feridas_CTI_Emergencia_APH[1].pdf",sourceSha256:"1165ce7164401331937b55b675e1fa8f04ea8b9058a7066cc5ed3c10e24b3e46",sourceBytes:24237328,sha256:"25a8d1c4c1a8fd8359ea9d008134d7dbe3208f6347d33a732d697563a5fd2fd5",bytes:24228286,pages:33,paletteChanges:{"#0c5b78 → #a73344":27,"#146c8d → #a73344":7,"#14728d → #a73344":12,"#16819a → #738275":74,"#174f67 → #a73344":82,"#17758d → #a73344":148,"#253946 → #293737":60,"#263b48 → #293737":262,"#526c79 → #596b5e":46,"#557280 → #596b5e":33,"#b7d3dc → #e1e7df":5,"#bdd5dc → #e1e7df":74,"#bed4dc → #e1e7df":2,"#bfd4dc → #e1e7df":33,"#dceef3 → #f1f3ed":2,"#eaf5f7 → #f1f3ed":2,"#f2f8fa → #f1f3ed":74,"#f6fafb → #f1f3ed":8},auxiliaryCredentialsRemovedFromAdaptedCopy:[],validation:{allPagesChecked:33,textExact:!0,textCharacters:32303,fontBytesAndTextGeometryExact:!0,imageBytesAndGeometryExact:!0,images:7,linksAndGeometryExact:!0,links:8,pageDimensionsExact:!0,authorAndReferenceMetadataExact:!0,onlyKnownRgbOperatorsAndClearMarginStripeChanged:!0,colorOperatorsChanged:951,topMarginStripes:33,clinicalReviewPerformed:!1,antivirusScanPerformed:!1}},{id:"evolucao-anotacao-enfermagem",title:"Evolução e anotação de enfermagem",href:"/materiais/apostilas/evolucao-anotacao-enfermagem.pdf",sourceName:"Apostila_Evolucao_e_Anotacao_de_Enfermagem_no_CTI_Adulto[1].pdf",sourceSha256:"bca781e8a7254b883658cd1d71cbafa9d6f695ec0cc2e2fdce886fac7c2787ce",sourceBytes:21312067,sha256:"aa186acfd3ac34aa3ce2511532103fb84d31c9b7053c3b3a0674f1f05b91ba16",bytes:21305044,pages:22,paletteChanges:{"#0c5b78 → #a73344":21,"#146c8d → #a73344":7,"#14728d → #a73344":25,"#16819a → #738275":44,"#174f67 → #a73344":52,"#17758d → #a73344":88,"#253946 → #293737":54,"#263b48 → #293737":176,"#526c79 → #596b5e":14,"#557280 → #596b5e":22,"#b7d3dc → #e1e7df":14,"#bdd5dc → #e1e7df":44,"#bed4dc → #e1e7df":4,"#bfd4dc → #e1e7df":22,"#dceef3 → #f1f3ed":4,"#eaf5f7 → #f1f3ed":10,"#f2f8fa → #f1f3ed":44,"#f6fafb → #f1f3ed":11},auxiliaryCredentialsRemovedFromAdaptedCopy:[],validation:{allPagesChecked:22,textExact:!0,textCharacters:26997,fontBytesAndTextGeometryExact:!0,imageBytesAndGeometryExact:!0,images:3,linksAndGeometryExact:!0,links:8,pageDimensionsExact:!0,authorAndReferenceMetadataExact:!0,onlyKnownRgbOperatorsAndClearMarginStripeChanged:!0,colorOperatorsChanged:656,topMarginStripes:22,clinicalReviewPerformed:!1,antivirusScanPerformed:!1}},{id:"medicacoes-bombas-infusao",title:"Medicações e bombas de infusão",href:"/materiais/apostilas/medicacoes-bombas-infusao.pdf",sourceName:"Apostila_Medicacoes_e_Bombas_de_Infusao_CTI_Adulto[1].pdf",sourceSha256:"182a12aaeab288c805ff7d67a07fda6849e6b3865548729d6fa81df92916e0d1",sourceBytes:9350505,sha256:"cd80e4f2e4d070e58695b97bc66963f4b1c2f5bf45b8ff4dce17c60ea043e49f",bytes:9341472,pages:42,paletteChanges:{"#102e47 → #a73344":1,"#123b56 → #a73344":37,"#133b55 → #a73344":67,"#146c8d → #a73344":10,"#16809a → #738275":67,"#18708c → #a73344":201,"#476879 → #596b5e":1,"#547286 → #596b5e":42,"#a9c4cf → #e1e7df":2,"#bdd2dc → #e1e7df":67,"#c1d4dc → #e1e7df":42,"#dcecf1 → #f1f3ed":2,"#f2f7f9 → #f1f3ed":67},auxiliaryCredentialsRemovedFromAdaptedCopy:["Content Credentials"],validation:{allPagesChecked:42,textExact:!0,textCharacters:34095,fontBytesAndTextGeometryExact:!0,imageBytesAndGeometryExact:!0,images:12,linksAndGeometryExact:!0,links:14,pageDimensionsExact:!0,authorAndReferenceMetadataExact:!0,onlyKnownRgbOperatorsAndClearMarginStripeChanged:!0,colorOperatorsChanged:606,topMarginStripes:42,clinicalReviewPerformed:!1,antivirusScanPerformed:!1}},{id:"monitorizacao-equipamentos",title:"Monitorização e equipamentos",href:"/materiais/apostilas/monitorizacao-equipamentos.pdf",sourceName:"Apostila_Monitorizacao_e_Equipamentos_CTI_Adulto[1].pdf",sourceSha256:"c9f6135ea5fd9c6a61144b798a1fb482f1907db1622ef93c257b70f2059cfba5",sourceBytes:9973013,sha256:"897eeaa99b239cd862d27e068e34bf882c36362518eab88de38182c6fd4cc716",bytes:9966782,pages:24,paletteChanges:{"#123b56 → #a73344":40,"#146c8d → #a73344":7,"#16809a → #738275":16,"#176a86 → #a73344":8,"#23343e → #293737":56,"#263d48 → #293737":154,"#334b58 → #293737":7,"#496474 → #596b5e":7,"#567482 → #596b5e":24,"#a9c4cf → #e1e7df":8,"#b6ced8 → #e1e7df":16,"#bdd2dc → #e1e7df":24,"#cce5ef → #596b5e":2,"#dcecf1 → #f1f3ed":8,"#eef6f8 → #f1f3ed":16},auxiliaryCredentialsRemovedFromAdaptedCopy:["Content Credentials"],validation:{allPagesChecked:24,textExact:!0,textCharacters:19138,fontBytesAndTextGeometryExact:!0,imageBytesAndGeometryExact:!0,images:8,linksAndGeometryExact:!0,links:10,pageDimensionsExact:!0,authorAndReferenceMetadataExact:!0,onlyKnownRgbOperatorsAndClearMarginStripeChanged:!0,colorOperatorsChanged:393,topMarginStripes:24,clinicalReviewPerformed:!1,antivirusScanPerformed:!1}}],Lo={materials:Fo},Vo=[{id:"cuidados-paciente-critico",title:"Cuidados com o Paciente Crítico",description:"Fichas de estudo sobre cuidados, observação e comunicação no CTI adulto.",moduleIds:["rotinas","dispositivos"]},{id:"curativos-feridas",title:"Curativos e Cuidados com Feridas",description:"Avaliação, técnica, coberturas, prevenção e registros no CTI, emergência e APH.",moduleIds:["rotinas","dispositivos"]},{id:"evolucao-anotacao-enfermagem",title:"Evolução e Anotação de Enfermagem",description:"Anotações do técnico, evolução do enfermeiro, exemplos e referências para estudo.",moduleIds:["registros"]},{id:"medicacoes-bombas-infusao",title:"Medicações e Bombas de Infusão",description:"Fichas de estudo, programação segura e monitorização no CTI adulto.",moduleIds:["rotinas","equipamentos"]},{id:"monitorizacao-equipamentos",title:"Monitorização e Equipamentos",description:"Monitorização e equipamentos no CTI adulto, com mapas de estudo e referências.",moduleIds:["equipamentos"]}],ge=Vo.map(a=>{const o=Lo.materials.find(s=>s.id===a.id);if(!o)throw new Error(`Arquivo da apostila não encontrado: ${a.id}`);return{...a,href:o.href,pages:o.pages,bytes:o.bytes,sha256:o.sha256,downloadFilename:`Conhecendo_a_CTI_Apostila_${a.id}.pdf`}}),$o=["apostila apostilas materiais de estudo PDF",...ge.flatMap(a=>[a.title,a.description])].join(" "),te=[{id:"caderno-digital",title:"Caderno CTI Adulto",description:"Leia uma página por vez e deslize para os lados, como um livro. Use os botões ou o índice para navegar.",href:"/materiais/caderno-cti-adulto-digital.pdf",originalFilename:"Caderno_CTI_Adulto_App_A4_Sem_Furos.pdf",pages:96,bytes:1196355,sha256:"a972f44330d1149e06eec607bc39ce314fb607e3d07f7c3c271864459107a0c8",use:"digital"},{id:"caderno-bolso",title:"Caderno de bolso para imprimir",description:"Quatro páginas de bolso em cada folha A4. Uma opção para quem quiser recortar e levar o caderno impresso.",href:"/materiais/caderno-cti-adulto-bolso-a4.pdf",originalFilename:"Caderno_CTI_Adulto_4_Por_A4_Atualizado_Sem_Furos.pdf",pages:24,bytes:1242866,sha256:"5cd9aa49767881706da4af5d6dc58ac09c95473915e56cba262a9d2cb94e9dd6",use:"print"}];[$o,...te.flatMap(a=>[a.title,a.description]),"PDF A4 bolso imprimir digital baixar materiais caderno plantão gasometria ventilação EVA BPS PAINAD CPOT RASS Glasgow delirium dispositivos medicações bombas cálculos sepse PCR registros transporte horários"].join(" ");const oa={id:"padis",label:"Devlin et al. — Diretriz PADIS, 2018. Referência [3] do caderno.",href:"https://sccm.org/clinical-resources/guidelines/guidelines/guidelines-for-the-prevention-and-management-of-pa"},de=[{id:"eva",label:"EVA",name:"Escala Visual Analógica",category:"Dor · autorrelato",purpose:"A EVA permite que a própria pessoa indique a intensidade da sua dor. No formato descrito no caderno, utiliza uma linha contínua de 10 cm, sem números, entre “sem dor” e “pior dor imaginável”.",when:["Quando a pessoa compreende a orientação e consegue marcar a linha.","Tente o autorrelato confiável primeiro. A intubação, por si só, não o impede."],measures:[{title:"Intensidade referida pela pessoa",detail:"A avaliação parte do relato do paciente; o observador não deve escolher a marca por ele."},{title:"Marca na linha contínua",detail:"No formulário de tamanho correto, mede-se a distância da extremidade “sem dor” até a marca feita pela pessoa."},{title:"Contexto da avaliação",detail:"Registre também local, horário e situação da dor, como repouso ou movimento."}],howToRead:["A linha de 10 cm corresponde a 100 mm. Use o formato e a unidade previstos no formulário adotado pelo serviço.","O caderno exemplifica uma marca a 60 mm em 100 mm como EVA 60/100 mm. Compare reavaliações quando o instrumento continuar adequado.","Pedir que a pessoa escolha um número de 0 a 10 corresponde a uma escala numérica. Isso é diferente da linha contínua da EVA."],care:["A ilustração desta tela não tem comprimento calibrado e não serve para medir a dor do paciente.","Se a pessoa não consegue fornecer um autorrelato confiável, discuta com o enfermeiro um instrumento adequado ao seu perfil.","Não atribua a intensidade da dor com base apenas na expressão facial ou nos sinais vitais."],criteria:{intro:"A EVA usa o autorrelato e a marca feita pela própria pessoa na linha contínua. A expressão facial e os sinais vitais não recebem pontos nesse instrumento.",method:"O resultado é a distância entre a extremidade “sem dor” e a marca. Local, contexto e horário enriquecem o registro, mas não são itens somados.",example:"Exemplo do caderno: marca a 60 mm em uma linha de 100 mm = EVA 60/100 mm.",steps:[{title:"Compreender e indicar a própria dor",detail:"A pessoa precisa compreender a orientação e conseguir marcar a linha. Tente uma forma de comunicação acessível."},{title:"Marcar a linha do formulário",detail:"O formulário descrito no caderno tem uma linha contínua de 10 cm, sem números, entre ausência de dor e a pior dor imaginável."},{title:"Medir a distância da marca",detail:"Meça a partir da extremidade “sem dor”, em milímetros, com o formulário de tamanho correto. A linha desta tela é somente ilustrativa."}]},range:{min:"0 mm",max:"100 mm",label:"Linha do formulário físico"},references:[{id:"eva-rebec",label:"ReBEC — RBR-86my7w2: EVA em linha de 10 cm. Referência [7] do caderno.",href:"https://ensaiosclinicos.gov.br/rg/RBR-86my7w2/1"},oa],sourcePages:[10,16]},{id:"bps",label:"BPS",name:"Behavioral Pain Scale",category:"Dor · observação",purpose:"A BPS observa comportamentos relacionados à dor. O caderno a descreve para o adulto crítico intubado, sem autorrelato confiável e com respostas comportamentais observáveis.",when:["Quando não é possível obter autorrelato confiável e o perfil do paciente corresponde ao instrumento adotado pelo serviço.","A presença de tubo orotraqueal, isoladamente, não determina a escolha da BPS. Verifique as possibilidades de comunicação."],measures:[{title:"Expressão facial",detail:"Observação de tensão e contração da face conforme os critérios da escala."},{title:"Membros superiores",detail:"Observação dos movimentos, da flexão e da retração dos membros superiores."},{title:"Adaptação à ventilação mecânica",detail:"Observação da tolerância à ventilação, da tosse e da interação com o ventilador no contexto avaliado."}],howToRead:["São três domínios, de 1 a 4 pontos cada. O total varia de 3 a 12.","BPS 3 é o mínimo; isoladamente, não comprova ausência de dor.","O resultado é um escore comportamental. Não converta BPS 6/12 em EVA 6/10 ou em uma intensidade numérica relatada pelo paciente."],care:["Defina e registre o contexto observado, como repouso ou cuidado, conforme o instrumento e a orientação do serviço.","Sedação profunda, bloqueio neuromuscular e alterações neurológicas podem limitar a observação dos comportamentos.","Tosse e dessincronia também exigem avaliação respiratória. Comunique os achados e não atribua automaticamente toda mudança à dor."],criteria:{intro:"São observados três domínios. Abra cada quadro para consultar os critérios resumidos das páginas 11 e 12 do caderno.",method:"Cada domínio recebe de 1 a 4 pontos; a soma dos três varia de 3 a 12. O mínimo de 3, isoladamente, não comprova ausência de dor.",example:"Exemplo educativo do caderno: face 2 + membros superiores 2 + adaptação à ventilação 2 = BPS 6/12.",domains:[{id:"expressao-facial",title:"Expressão facial",page:11,levels:[{points:1,criterion:"Face sem tensão."},{points:2,criterion:"Tensão parcial, como sobrancelhas contraídas."},{points:3,criterion:"Tensão de toda a face, como olhos fechados."},{points:4,criterion:"Careta com contração acentuada."}]},{id:"membros-superiores",title:"Membros superiores",page:12,levels:[{points:1,criterion:"Sem movimentação."},{points:2,criterion:"Flexão parcial."},{points:3,criterion:"Flexão completa de membros e dedos."},{points:4,criterion:"Retração contínua; membros contraídos."}]},{id:"adaptacao-ventilacao",title:"Adaptação à ventilação",page:12,levels:[{points:1,criterion:"Tolera ventilação e movimentos."},{points:2,criterion:"Tosse durante os movimentos."},{points:3,criterion:"Luta contra o ventilador."},{points:4,criterion:"Ventilação não controlável pelo padrão observado."}]}]},range:{min:"3",max:"12",label:"Total dos três domínios"},references:[{id:"bps-brasil",label:"Morete et al. — BPS-Brasil. RBTI, 2014;26:373–378. Referência [4] do caderno.",href:"https://www.scielo.br/j/rbti/a/pJ5k9VwdGcj9xWCjFn9wdZJ/?lang=pt"},oa],sourcePages:[11,12,15,16]},{id:"painad",label:"PAINAD",name:"Pain Assessment in Advanced Dementia",category:"Dor · demência avançada",purpose:"A PAINAD é um instrumento observacional para avaliação de dor em pessoas com demência avançada quando o autorrelato não é confiável.",when:["Nesse perfil específico, depois de tentar comunicação acessível com a pessoa.","Confirme a adequação da versão adotada pelo serviço com o enfermeiro. A impossibilidade de falar, por si só, não define a indicação."],measures:[{title:"Respiração independente da vocalização",detail:"Observação do padrão e do esforço respiratório."},{title:"Vocalização negativa",detail:"Observação de gemidos, choro, gritos ou manifestações vocais de sofrimento."},{title:"Expressão facial",detail:"Observação da face conforme os critérios do instrumento."},{title:"Linguagem corporal",detail:"Observação de relaxamento, tensão, inquietação, rigidez ou resistência ao cuidado."},{title:"Consolabilidade",detail:"Observação da necessidade de consolo e da resposta à voz, ao toque ou à distração."}],howToRead:["São cinco domínios de 0 a 2 pontos. O total varia de 0 a 10.","PAINAD 5/10 não equivale automaticamente a EVA 5/10. A escala é observacional, e não um autorrelato numérico.","Não classifique o total como dor leve, moderada ou intensa copiando faixas de uma escala numérica diferente."],care:["PAINAD não substitui automaticamente BPS ou CPOT no paciente sedado em ventilação mecânica.","Alterações respiratórias, agitação e expressão de sofrimento também podem ter outras causas; comunique e considere o contexto com a equipe.","Use a mesma escala nas reavaliações quando continuar adequada. Se a comunicação ou o perfil mudarem, registre o motivo da nova escolha."],criteria:{intro:"São observados cinco domínios no perfil de demência avançada descrito no caderno. Abra os quadros para consultar os critérios resumidos das páginas 13 e 14.",method:"Cada domínio recebe de 0 a 2 pontos; a soma dos cinco varia de 0 a 10. PAINAD 5/10 não equivale automaticamente a EVA 5/10.",domains:[{id:"respiracao",title:"Respiração independente da voz",page:13,levels:[{points:0,criterion:"Normal."},{points:1,criterion:"Dificuldade eventual ou hiperventilação breve."},{points:2,criterion:"Difícil e ruidosa; hiperventilação prolongada ou Cheyne-Stokes."}]},{id:"vocalizacao",title:"Vocalização negativa",page:13,levels:[{points:0,criterion:"Ausente."},{points:1,criterion:"Gemido eventual ou fala baixa de desagrado."},{points:2,criterion:"Chamados repetidos em sofrimento; gemidos altos, gritos ou choro."}]},{id:"expressao-facial",title:"Expressão facial",page:14,levels:[{points:0,criterion:"Sorri ou sem expressão."},{points:1,criterion:"Tristeza, medo ou sobrancelhas contraídas."},{points:2,criterion:"Careta."}]},{id:"linguagem-corporal",title:"Linguagem corporal",page:14,levels:[{points:0,criterion:"Corpo relaxado."},{points:1,criterion:"Tensão, inquietação ou agitação aflita."},{points:2,criterion:"Rigidez; punhos fechados; joelhos dobrados; resistência ao cuidado ou agressividade."}]},{id:"consolabilidade",title:"Consolabilidade",page:14,levels:[{points:0,criterion:"Não precisa de consolo."},{points:1,criterion:"Acalma ou se distrai com voz/toque."},{points:2,criterion:"Permanece inconsolável."}]}]},range:{min:"0",max:"10",label:"Total dos cinco domínios"},references:[{id:"painad-brasil",label:"Pinto et al. — PAINAD-Brasil. Einstein, 2015;13:14–19. Referência [5] do caderno.",href:"https://www.scielo.br/j/eins/a/3VW8CfBCDq3TfLHgkPw8ZTJ/?lang=pt"}],sourcePages:[10,13,14,16]},{id:"rass",label:"RASS",name:"Richmond Agitation-Sedation Scale",category:"Agitação e sedação",purpose:"A RASS descreve o nível de agitação e de sedação/despertar. Não é uma escala de dor. Dor e delirium precisam de avaliações próprias.",when:["Para descrever e acompanhar agitação e nível de despertar conforme treinamento e o instrumento adotado pelo serviço.","Compare o resultado com a meta individualizada pela equipe. Não existe uma meta de RASS universal para todos os pacientes."],measures:[{title:"Comportamento espontâneo",detail:"A observação inicial identifica calma, inquietação, agitação ou outras respostas descritas no instrumento."},{title:"Resposta à voz",detail:"São consideradas abertura dos olhos e presença e duração do contato visual, conforme os critérios completos da RASS."},{title:"Resposta ao estímulo físico",detail:"Etapa prevista para ausência de resposta à voz, conforme treinamento, supervisão e formulário adotado."}],howToRead:["Os níveis positivos descrevem agitação; 0 corresponde a alerta e calmo; os níveis negativos descrevem redução do despertar.","RASS 0 não significa ausência de dor. Um valor positivo, isoladamente, não identifica a causa da agitação.","O quadro abaixo resume os níveis para estudo. A sequência e os critérios completos, inclusive os tempos de contato visual, devem ser conferidos no instrumento adotado."],care:["Registre a resposta observada e as interferências na avaliação. Considere medicamentos e limitações sensoriais ou neurológicas com a equipe.","Não suspenda nem ajuste sedação apenas para testar ou com base no número da escala. Siga a prescrição e a supervisão do enfermeiro.","RASS não diagnostica delirium. Não realize estímulos físicos com base apenas nesta tela educativa."],criteria:{intro:"A avaliação considera o comportamento espontâneo, a resposta à voz, o contato visual e sua duração e, quando previsto no instrumento, a resposta ao estímulo físico.",method:"Os fatores não são somados. O resultado corresponde ao nível de agitação ou despertar observado na sequência de avaliação da RASS.",example:"Exemplo do caderno: contato visual por 5 segundos após a voz corresponde a RASS −2.",steps:[{title:"Comportamento espontâneo",detail:"Observe se a pessoa está alerta e calma, inquieta, agitada ou combativa. Os níveis 0 a +4 descrevem esses comportamentos."},{title:"Resposta à voz",detail:"Considere abertura dos olhos, movimentação, presença de contato visual e duração desse contato. Esses elementos distinguem os níveis −1, −2 e −3 conforme o instrumento."},{title:"Resposta ao estímulo físico",detail:"Na ausência de resposta à voz, a etapa física prevista distingue resposta presente (−4) de ausente (−5). A técnica exige treinamento e supervisão."}]},range:{min:"−5",max:"+4",label:"Níveis de despertar e agitação"},levelGuide:[{score:"+4",label:"Combativo",description:"Comportamento violento, com risco imediato."},{score:"+3",label:"Muito agitado",description:"Tenta retirar dispositivos ou agride."},{score:"+2",label:"Agitado",description:"Movimentos frequentes sem finalidade; luta contra o ventilador."},{score:"+1",label:"Inquieto",description:"Ansioso ou inquieto, sem movimento vigoroso ou agressivo."},{score:"0",label:"Alerta e calmo",description:"Estado de alerta e calma."},{score:"−1",label:"Sonolento",description:"Desperta à voz e mantém contato visual por mais de 10 s, conforme o resumo do caderno."},{score:"−2",label:"Sedação leve",description:"Desperta à voz com contato visual por menos de 10 s, conforme o resumo do caderno."},{score:"−3",label:"Sedação moderada",description:"Movimenta-se ou abre os olhos à voz, sem contato visual."},{score:"−4",label:"Sedação profunda",description:"Não responde à voz; responde ao estímulo físico previsto no instrumento."},{score:"−5",label:"Não despertável",description:"Sem resposta à voz nem ao estímulo físico previsto no instrumento."}],references:[{id:"rass-vanderbilt",label:"Vanderbilt/CIBS — RASS e CAM-ICU: recursos em português. Referência [8] do caderno.",href:"https://www.icudelirium.org/language-translations/portuguese-brazil"},oa],sourcePages:[17,18]}],Bo=[{id:"eva",label:"EVA",assesses:"Intensidade da dor por autorrelato.",population:"Pessoa que compreende e consegue marcar a linha.",report:"Marca da própria pessoa em uma linha contínua."},{id:"bps",label:"BPS",assesses:"Comportamentos relacionados à dor.",population:"Adulto crítico intubado, sem autorrelato confiável, com comportamentos observáveis.",report:"Face, membros superiores e adaptação à ventilação."},{id:"painad",label:"PAINAD",assesses:"Comportamentos relacionados à dor.",population:"Pessoa com demência avançada sem autorrelato confiável.",report:"Respiração, vocalização, face, corpo e consolabilidade."},{id:"rass",label:"RASS",assesses:"Agitação e sedação/despertar, e não a dor.",population:"Paciente cujo nível de agitação ou despertar precisa ser descrito e acompanhado.",report:"Comportamento e resposta à voz e aos estímulos previstos no instrumento."}];de.flatMap(a=>{var o,s;return[a.label,a.name,a.category,a.purpose,...a.when,...a.measures.flatMap(n=>[n.title,n.detail]),...a.howToRead,...a.care,a.criteria.intro,a.criteria.method,a.criteria.example??"",...((o=a.criteria.steps)==null?void 0:o.flatMap(n=>[n.title,n.detail]))??[],...((s=a.criteria.domains)==null?void 0:s.flatMap(n=>[n.title,...n.levels.map(r=>r.criterion)]))??[]]}).join(" ");const Ho=`2D
Radioterapia convencional bidimensional
2T
Dois tempos
3D
Radioterapia conformacional tridimensional
5-FU
5 Fluorouracil
A
Altura
A + B
Classificação de motilidade dos espermatozoides
AA
Antes do almoço
AAS
Ácido acetilsalicílico
ABD
Abdome
ABFM
Associação Brasileira de Física Médica
ABO
Grupo sanguíneo ABO
ABVD
Doxorrubicina + Bleomicina + Vimblastina + Dacarbazina
AC
Antes do café
AC + D
Doxorrubicina + Ciclofosfamida + Docitaxel
AC + T
Doxorrubicina + Ciclofosfamida + Taxol
ACD
Citrato Ácido Dextrose
ACFA
Fibrilação atrial crônica
ACR
American College of Rheumatology
ACTP
Angioplastia coronariana transluminal percutânea
ACWY
Vacina contra doenças meningocócicas invasivas causadas por neisseria meningitidis dos tipos A, C, W-135 e Y
ACX
Artéria circunflexa
ADA
Artéria descendente anterior
ADM
Amplitude de movimento
AE/Ao
Relação átrio esquerdo/aorta
AESP
Atividade elétrica sem pulso
AFE
Aceleração de fluxo expiratório
AG
Anestesia geral
AH
Assisted hatching
AIDS
Síndrome de imunodeficiência adquirida
AIG
Adequado para idade gestacional
AIH
Autorização de internação hospitalar
AINE
Anti-flamatórios não esteroides
AIT
Acidente isquêmico transitório
AJ
Antes da janta
AJD
Altura Joelho Direito
AJE
Altura Joelho Esquerdo
AL
Acelerador linear
ALIN
Alinhamento dos pronúcleos
AMO
Aspirado de Medula Óssea
AMP*
Ampola
AN
Ambas as narinas
ANT
Anterior
AP
Anátomo Patológico
ASG
Avaliação Subjetiva Global
ASG Ped
Avaliação Subjetiva Global Pediátrica
ASG-PPP
Avaliação Subjetiva Global Produzida pelo próprio paciente
ATBA
Antibiótico
ATG
Imunoglobulina Antimitócitos Humanos
AVC
Acidente Vascular Cerebral
AVE
Acidente Vascular Encefálico
AVP
Acesso Vascular Periférico
Anti HbC total
Anticorpos Anti IgM e Anti IgG para hepatite B
Anti TTG
Anticorpo anti-transglutaminase
Anti-HBsAg
Anticorpo hepatite B
Anti-HCV
Anticorpo hepatite C
Anti-RH
Imunoglobulina Anti-Rh
BAV
Bloqueio Atrio-ventricular
BAVT
Bloqueio atrio-ventricular Total
BCP
Broncopneumonia
BE
Base excess
BEAC
Carmustina + Etoposídeo + Citarabina + Ciclofosfamida
BEAM
Carmustina + Etoposideo + Citarabina + Melfalano
BEG
Bom estado geral
BEP
Bleomicina + Etoposideo + Cisplatina
BH
Balanço hídrico
BHCG
Fração beta da gonadotrofina coriônica humana
BHP
Balanço hídrico parcial
BHT
Balanço hídrico total
BI
Bomba de infusão
BIPAP
Pressão positiva em dois níveis
BISN*
Bisnaga
BLAST
Blastômeros
BMO
Biópsia de medula óssea
BN
Blastômero nucleado
BNF
Bulhas normofonéticas
BNM
Bloqueador neuromuscular
BNP
Brain natriuretic peptide
BOL*
Bolsa
BPM
Batimentos por minuto
BQLT
Bronquiolite
BR
Bolsa rota
BRAQUI
Braquiterapia
BSA
Bloqueio subaracnóide
BT
Bilirrubina total
BU
Bussulfano
BUEAM
Bussulfano + Etoposideo + Citarabina + Melfalano
BUEM
Bussulfano + Etoposideo + Melfalano
BUFLU
Bussulfano + Fludarabina
BV
Baixo ventre
BVA
Bronquiolite viral aguda
BX
Biópsia
Boost
Reforço
C
Conduta
C, A, J
C, A, J - Café, Almoço e Janta.
C.
Colimador
CA
Câncer
CAD
Cetoacidose diabética
CAP*
Cápsula
CAPD
Diálise peritoneal ambulatorial contínua
CAT
Cateterismo cardíaco
CB
Cell Block
CBCT
Cone Beam - Tomografia computadorizada
CBD
Circunferência Braço Direito
CBE
Circunferência Braço Esquerdo
CD34
Cluster of Differentiation 34
CDL
Catéter Duplo Lúmen
CE
Carboplatina+ Etoposide
CGVHD
Chronic Graft versus Host Disease
CHAD
Concentrado de Hemácias Adulto
CHG
Gluconato de Clorexidina
CMV
Citomegalovírus
CNAF
Catéter Nasal de Alto Fluxo
CO2
Gás carbônico
COL
Colimador
COM
Conforme Orientação Médica
CONC
Concentração
CONF
Conforme
CONG
Congelado
COREN
Conselho Regional de Enfermagem
CP
Citopatológico
CP MAST
Comprimido mastigável
CP REVEST
Comprimidos revestidos
CP*
Comprimido
CPA
Concentrado de Plaquetas por Aférese
CPAE
Central de produção de alimentos especiais
CPAP
Pressão positiva contínua
CPH
Células Progenitoras Hematopoiéticas
CPK
Creatinofosfoquinase
CPM
Conforme prescrição médica
CPO
Campo
CPP
Células progenitoras periféricas
CQ
Controle de qualidade
CR
Centro de recuperação
CRBM
Conselho Regional de Biomedicina
CREFITO
Conselho Regional de Fisioterapia e Terapia Ocupacional
CRF
Conselho Regional de Farmácia
CRM
Conselho Regional de Medicina
CRN
Conselho Regional de Nutrição
CRO
Conselho Regional de Odontologia
CRP
Conselho Regional de Psicologia
CRPA
Centro de recuperação pós-anestésica
CRTR
Conselho Regional de Técnicos em Radiologia
CSA
Ciclosporina
CTH
Células-Tronco Hematopoéticas
CTHMV
Centro de Terapia Hematológica Moinhos de Vento
CTI
Centro de Tratamento Intensivo
CTIA
Centro de Tratamento Intensivo Adulto
CTIP
Centro de Tratamento Intensivo Pediátrico
CTR
Cardiotocografia de repouso
CTV
Volume alvo Clínico de Radioterapia
CTX
Ciclofosfamida
CVA
Cateter Vesical de Alívio
CVC
Cateter venoso central
CVD
Cateter Vesical de Demora
CVVH
Hemofiltração veno-venosa contínua
CVVHD
Hemodiálise veno-venosa contínua
CX*
Caixa
CY
Ciclofosfamida
Ca
Cálcio
Cal
Caloria
Cateter DL
Cateter duplo lúmen
Cateter ML
Cateter monolúmen
Cateter TL
Cateter triplo lúmen
D
Direito
D+
Dias pós-transplante
D-
Dias pré-transplante
D0
Dia do transplante
DAPT
Terapia Antiplaquetária Dupla
DD
Decúbito Dorsal
DEVH
Doença do Enxerto Versus Hospedeiro
DEVHc
Doença do Enxerto Versus Hospedeiro Crônico
DIBH
Deep Inspiration Breath Hold
DLD
Decúbito Lateral Direito
DLE
Decúbito Lateral Esquerdo
DM
Diabete Mellitus
DMG
Diabete Mellitus Gestacional
DMR
Doador de Medula REDOME
DN
Data de Nascimento
DNA
Ácido Desoxirribonucleico
DNV
Declaração de Nascido Vivo
DOU
Dose única diária
DP
Diálise peritoneal
DPA
Diálise peritoneal ambulatorial
DPI
Diálise intermitente
DPOC
Doença pulmonar obstrutiva crônica
DPP
Descolamento prematuro de placenta
DPT
Duodenopancreatectomia
DRG*
Drágea
DRGE
Doença do refluxo gastroesofágico
DRM
Doença residual Mínima
DRR
Radiografia digitalmente reconstruída
DSA
Donor specific antibodies
DSAV
Defeito septal atrioventricular
DT
Difteria e Tétano
DTAP-R
Vacina Tríplice Bacteriana Acelular
DTM
Desordem temporomandibular
DU
Dinâmica uterina
DUM
Data da última menstruação
DV
Decúbito ventral
DVA
Derivação ventriculoatrial
DVE
Derivação Ventricular Externa
DVP
Derivação ventrículoperitoneal
E
Esquerdo
E/I
Estatura para idade
EAP
Edema agudo de pulmão
EBV
Epstein Barr vírus
ECG
Eletrocardiograma
ECO
Ecografia
ECOG
Eastern Cooperative Cooperative Group
EDA
Endoscopia digestiva alta
EE
Eletroestimulação
EEG
Eletroencefalograma
EJAC
Ejaculado
ELA
Esclerose lateral amiotrófica
ELET
Elétrons
ELPR
Expiração lenta prolongada
END
Endométrio
ENF
Enfermeiro
ENV*
Envelope
EP
Etoposídeo + Cisplatina
EPAP
Pressão positiva expiratória
EPI
Equipamento de Proteção Individual
EPO
Eritropoetina
EQU
Exame qualitativo de urina
ESCA
Esterilidade sem causa aparente
ESV
Extrassístole ventricular
EULAR
European league against rheumatism
EV
Endovenoso
EVA
Escala visual analógica
EXT
Extensão
FAB
Ferimento de arma branca
FAC
Fluorouracil + Doxorrubicina + Ciclofosfamida
FAE
Fezes amarelas endurecidas
FAF
Ferimento de arma de fogo
FAG
Fezes amarelas com grumos
FAL
Fezes amarelas líquidas
FAM
Força do Aperto de Mão
FAP
Fezes amarelas pastosas
FASL
Fezes amarelas semilíquidas
FAV
Fístula artériovenosa
FC
Frequência cardíaca
FE
Fração de ejeção
FEC
Fluorouracil + Epirrubicina + Ciclofosfamida
FID
Fossa ilíaca direita
FIE
Fossa ilíaca esquerda
FISIO
Fisioterapeuta
FIV
Fertilização “in vitro”
FL
Fezes líquidas
FLT3
FMS-like tyrosina kinase 3
FLU
Fludarabina
FM
Feto morto
FN
Fezes normais
FNP
Facilitação neuromuscular proprioceptiva
FNT
Fontanela normotensa
FO
Ferida operatória
FOLFIRI
Irinitecano + Leucovorin + Fluorouracil
FOLFOX
Oxaliplatina + Leucovorin + Fluorouracil
FOT
Fótons
FP
Fezes pastosas
FR
Frequência respiratória
FRAG
Fragmentação
FSC
Fossa supra clavicular
FSL
Fezes semilíquidas
FT
Fezes transição
FV
Fibrilação ventricular
FVE
Fezes verdes endurecidas
FVG
Fezes verdes com grumos
FVL
Fezes verdes liquidas
FVP
Fezes verdes pastosas
FVSL
Fezes verdes semilíquidas
FX
Fração
FiO2
Fração inspirada de oxigênio
Flex
Flexão
G P C A E
Número de: gestações, partos normais, cesáreas, abortamentos e gestações ectópicas
G.
Gantry
G1
Gêmeo 1
G2
Gêmeo 2
G3
Gêmeo 3
G4
Gêmeo 4
GA
Gasometria arterial
GCS
Escala de Glasgow
GCSF
Fator estimulador de colônia granulocítica
GEA
Gastroenterite aguda
GEMBUMEL
Gencitabina+ Bussulfan+ Melfalan
GGT
Gama glutamiltransferase
GIG
Grande para idade gestacional
GMR
Germe Multirresistente
GPF
Colo grosso, posterior, fechado
GTV
Volume alvo Palpável (gross) de Radioterapia
GVHD
Graft versus Host Disease
Gt*
Gota
Gy
Gray(s)
HAP
Hipertensão arterial pulmonar
HAQ
Health assessment questionnaire
HAS
Hipertensão arterial sistêmica
HBsAg
Antígeno hepatite B
HC
hipercalorico
HCD
Hemicorpo direito
HCE
Hemicorpo esquerdo
HCO3
Bicarbonato
HCT-CI
Hepatopoietic Cell Transplant Specific Comorbity Index
HCV
Hepatite C
HD
Hipótese Diagnóstica
HD
Hemodiálise
HDA
História da Doença Atual
HDFVVC
Hemodiafiltração venovenosa contínua
HDL
High Density Lipoprotein
HDR
Braquiterapia de alta taxa de dose
HEP A
Vacina Hepatite A
HEP A+B
Vacina Hepatite A+B
HEP B
Vacina Hepatite B
HEXA
Difteria, Tétano, Pertussis acelular (coqueluche), Poliomielite, Haemophilus tipo B
HF
História Familiar
HGT
Hemoglicoteste
HIDAC
Citarabina em altas doses
HIV
Vírus da imunodeficiência humana
HLA
Antígeno Leucocitário Humano
HMC
Hemocultura
HMG
Hemograma
HMP
História Médica Pregressa
HMV
Hospital Moinhos de Vento
HP
Hiperprotéico
HPV
Vacina Quadrivalente Recombinante Contra Papilomavírus Humano
HSA
Hemorragia Subaracnoidea
HSD
Hemorragia Subdural
HTLV
Vírus linfotrópico de células T humanas
HTX
Hemitórax
HVA
Vírus hepatite A
Haplo
Doador Haploidêntico
Hb
Hemoglobina
Ht
Hematócrito
I
Impressão
IAM
Infarto agudo do miocárdio
IAMCSST
Infarto agudo do miocárdio com supra de segmento ST
IAMSSST
Infarto agudo do miocárdio sem supra de segmento ST
IC
Insuficiência cardíaca
ICATH
Intracath
ICAV
Intracavitário
ICC
Insuficiência cardíaca congestiva
ICE
Insuficiência cardíaca esquerda
ICSI
Injeção intracitoplasmática de espermatozoides
ID
Intradérmica
IDN
Interação droga x nutriente
IFT
Imunofenotipagem
IG
Idade gestacional
IGO
Idade gestacional obstétrica
IGRT
Radioterapia guiada por imagem
IIU
Inseminação intrauterina
ILA
Índice de líquido amniótico
IM
Intramuscular
IMC
Índice de massa corporal
IMC PG
Índice de massa corporal pré-gestacional
IMC/I
Índice de massa corporal para idade
IMRT
Radioterapia por intensidade modulada
INJ*
Injetável
INR
Razão normal internacional
IOM
Institute of Medicine
IOT
Intubação Orotraqueal
IPAP
Pressão positiva inspiratória na via aérea
IPV
Vacina Poliomielite Inativada
IRA
Insuficiência renal aguda
IRC
Insuficiência renal crônica
IS
Imunossupressão
IST
Isotônico
ITU
Infecção do trato urinário
ITV
Volume alvo Interno de Radioterapia
IV
Intravenoso
IVAS
Infecção de vias aéreas superiores
IVIG
Imunoglobulina Humana Intravenosa
IgA
Imunoglobulina A
IgE
Imunoglobulina E
IgG
Imunoglobulina G
IgM
Imunoglobulina M
Iso
Isocentro
Iso CT
Marca do isocentro da tomografia
JEC
Junção escamocolunar
JUG
Jugular
K
Potássio
KCl
Cloreto de potássio
KPC
Klebsiella pneumoniae carbapenemase
KPS
Karnofsky Performance Scale
KTTP
Tempo de tromboplastina parcial
KeV
Kilovolt
LA
Líquido amniótico
LAB
Laboratório
LAC
Líquido amniótico claro
LAM
Líquido amniótico meconial
LAT
Lateral
LATM
Líquido amniótico tinto de mecônio
LCA
Ligamento cruzado anterior
LDL
Low Density Lipoprotein
LDR
Braquiterapia de baixa taxa de dose
LE
Líquidos eliminados
LEUC
Leucócitos
LFN
Linfonodos
LID
Lobo inferior direito
LIE
Lobo inferior esquerdo
LLA
Leucemia linfóide aguda
LLC
Leucemia Linfóide Crônica
LM
Leite materno
LMA
Leucemia mielóide aguda
LMC
Leucemia mielóide crônica
LMO
Leite materno ordenhado
LOC
Lúcido, orientado e coerente
LR
Líquidos recebidos
Long
Longitudinal
M
Modificado
M.
Ângulo de mesa
MA
Médico assistente
MAC
Método anticoncepcional
MAP
Monitorização anteparto
MASSO
Massoterapia
MAV
Malformação arteriovenosa
MEC
Mecônio
MEG
Mau estado geral
MEL
Melfalano
MF
Movimentação fetal
MHB
Manobras de higiene brônquica
MIC
Concentração inibitória mínima
MID
Membro inferior direito
MIE
Membro inferior esquerdo
MLC
Colimador de Multiplas Folhas
MLCHD
Colimador de Multiplas Folhas de Alta Definição
MM
Mieloma Múltiplo
MMF
Micofenolato mofetil
MMR
Vacina contra caxumba, sarampo e rubéola
MOD
Modulado
MOE
Motricidade ocular externa
MP
Médico plantonista
MRSA
Methicillin-resistant Staphylococcys aureaus – Staphylococcus aureus resistente à Meticilina/Oxacilina
MSD
Membro superior direito
MSE
Membro superior esquerdo
MSSA
Methicillin-resistant Staphylococcys aureaus – Staphylococcus aureus sensível à Meticilina/Oxacilina
MTX
Metástase
MUC
Mucosas úmidas e coradas
MV
Murmúrio vesicular
MVUD
Murmúrio vesicular uniformemente distribuído
MeV
Megavolt
Mg
Magnésio
MsIs
Membros inferiores
MsSs
Membros superiores
N/V
Náuseas e/ou vômitos
NA
Não se aplica
NAP
Não aparentado
ND
Não Detectado
NDN
Nada digno de nota
NEO
Neoplasia
NGS
Next Generation Sequencing
NIPS
Neonatal infant pain scale
NMPOA
Núcleo Mama Porto Alegre
NPAD
Não padronizado
NPO
Nada por via oral
NPS
Nitroprussiato
NPT
Nutrição parenteral potal
NRS 2002
Nutritional Risk Screening
NTG
Nitroglicerina
NUT
Nutricionista
Na
Sódio
O
Objetivo
O2
Oxigênio
OAD
Campo oblíquo anterior direito
OAE
Campo oblíquo anterior esquerdo
OAR
Órgãos de Risco em Radioterapia
OBL
Campo oblíquo
OBS
Observação
OCE
Óstio cervical externo
OFA
Órgãos fonoarticulatórios
OMS
Organização Mundial da Saúde
ON
Óculos nasal
OPAS
Organização Panamericana de Saúde
OPD
Campo oblíquo posterior direito
OPE
Campo oblíquo posterior esquerdo
OPME
Órteses, próteses e materiais especiais
OV
Ovário
P
Fósforo
P-ROM
Photographic Range of Motion
P/ C
Relação poteinúria/creatinúria
P/E
Peso para estatura
P/I
Peso para idade
PA
Pressão arterial
PAI + CD
Anticorpos irregulares + coombs direto
PAM
Pressão arterial média
PAP
Pressão da artéria pulmonar
PB
Perímetro braquial
PBE
Peritonite Bacteriana Espontânea
PBF
Perfil Biofísico Fetal
PC
Perímetro cefálico
PC/I
Perímetro cefálico para idade
PCA
Persistência do canal arterial
PCO2
Pressão parcial de gás carbônico
PCR
Parada cardiorrespiratória
PCT*
Pacote
PCTE
Paciente
PE
Pré-eclâmpsia
PED
Pediatria
PEEP
Pressão expiratória positiva
PEG
Pré-eclâmpsia grave
PESA
Punção de espermatozoides epididimários
PET
Positron emission tomography
PI
Peso ideal
PIA
Pressão intra-abdominal
PIC
Pressão intracraniana
PICC
Cateter central de inserção periférica
PIG
Pequeno para idade gestacional
PIP
Pressão inspiratória positiva
PL
Punção Lombar
PMT
Prematuro
PN
Peso de nascimento
PNA
Pielonefrite aguda
PNCE
Parto normal com episiotomia
PNEUMO 13V
Vacina pneumocócica 13 valente (conjugada com 13 sorotipos)
PNEUMO 23V
Vacina pneumocócica 23 valente (conjugada com 23 sorotipos)
PNR
Paciente não reanimável
PNSE
Parto normal sem episiotomia
PO
Pós-operatório
PO2
Pressão parcial de oxigênio
POI
Pós-operatório Imediato
POST
Campo posterior
PP
Perda de peso
PPG
Peso pré-gestacional
PPL
Punho percussão lombar
PPS
Perfil Psicossocial
PPlato
Pressão de Plantô
PRI
Primus
PROF
Profundidade
PRV
Volume de Planejamento de Órgão de Risco de Radioterapia
PRÉ-OP
Pré-operatório
PSA
Antígeno Prostático específico
PT
Perímetro torácico
PTH
Paratormônio
PTI
Púrpura Trombocitopênica Idiopática
PTN
Proteína
PTT
Púrpura Trombocitopênica Trombótica
PTV
Volume alvo de Planejamento de Radioterapia
PU
Peso usual
PUVA
Psoraleno + irradiação com raios ultravioleta
PVC
Pressão venosa central
PVC free
Livre de Policloreto de Vinil
Pcath
Portocath
PsVs
Padrões ventilatórios
Q/L
Quarto/Leito
QA
Controle de qualidade
QID
Quadrante inferior direito
QIE
Quadrante inferior esquerdo
QP
Queixa Principal
QT
Quimioterapia
QUADRA Acelular
Difteria, Tétano, Pertussis (Acelular) e Poliomelite 1,2 e 3 (inativada)
R-CHOP
Rituximabe + Vincristina + Doxorrubicina + Ciclofosfamida
R-CVP
Rituximabe + Vincristina + Ciclofosfamida
R-ICE
Rituximabe + Ifosfamida + Carboplatina + Etoposideo
RA
Ruídos adventícios
RAM
Reação adversa ao medicamento
RAP
Resposta auditiva provocada
RASS
Richmond Agitation Sedation Scale
RC
Remissão completa
RCIU
Retardo de crescimento intrauterino
RDNPM
Retardo desenvolvimento neuropsicomotor
RDW
Red cell distribution width
RE
Rotação externa
REDOME
Registro Nacional de Doadores Voluntários de Medula Óssea
REF
Radioterapia estereotáxica fracionada
REG
Regular estado geral
REREME
Registro Nacional de Receptores de Medula Óssea
RFP
Realinhamento femuropatelar
RG
Resíduo gástrico
RGE
Refluxo gastro esofágico
RH
Fator Rhesus
RHA
Ruído hidroaéreo
RHD
Ração hídrica diária
RI
Rotação interna
RID
Região inguinal direita
RIE
Região inguinal esquerda
RLA
Registro latinoamericano de reprodução assistida
RM
Ressonância magnética
RMR
Receptor Medula REREME
RN
Recém-nascido
RO
Recuperação obstétrica
ROTAVÍRUS 5V
Vacina contra rotavírus vivo, oral, pentavalente
RPG
Reedução postural global
RR
Ritmo regular
RS
Revisão de Sistemas
RTX
Radioterapia
RX
Raio X
RX AP
Raio X anteroposterior
RX P
Raio X perfil
RX PA
Raio X posteroanterior
Rt-PCR
Reverse Transcription Polymerase Chain Reaction
Rx Tx
Raio X de Tórax
RxT
Radioterapia
S
Subjetivo
SABR
Radioterapia Estereotáxica Corpórea Ablativa
SAD
Distância fonte isocentro
SAP
Serviço de atendimento ao paciente
SARS-CoV2
Síndrome respiratória aguda severa Coronavírus 2
SAT
Saturação
SBL*
Sublingual
SBP
Sociedade Brasileira de Pediatria
SBRT
Radioterapia Estereotáxica Corpórea
SC
Subcutâneo
SCA
Síndrome coronariana aguda
SCD
Subclávia direita
SCE
Subclávia esquerda
SCI
Serviço de controle de infecção
SCIH
Serviço de controle de infecção hospitalar
SCP
Sistema de Classificação de Paciente
SCUF
Ultrafiltração contínua lenta
SDRA
Síndrome do desconforto respiratório agudo
SF
Soro fisiológico
SG
Soro glicosado
SGB
Streptococcus B-hemolítico grupo B
SGF
Soro glico-fisiológico
SIC
Segundo informação coletada
SIRS
Síndrome de insuficiência respiratória
SLED
Sustained Low Efficiency prolongada – Hemodiálise prolongada
SM
Seio materno
SMD
Síndrome mielodisplásica
SMX-TMP
Sulfametoxazol + Trimetoprima
SN
Se necessário
SNC
Sistema nervoso central
SNE
Sonda nasoenteral
SNG
Sonda nasogástrica
SOE
Sonda oroentérica
SOG
Sonda orogástrica
SOL*
Solução
SP
Sem particularidades
SPTZ
Espermatozoide
SR
Senhor
SRA
Senhora
SRS
Radiocirurgia
SRSfx
Radiocirurgia Fracionada
SS
Sem sopros
SSD
Distância fonte pele
SSS
Soro sintético substituto
SUP*
Supositório
SUSP*
Suspensão
SV
Sinais Vitais
SVA
Sonda vesical de alívio
SVD
Sonda vesical de demora
SpO2
Saturação periférica de oxigênio
T
Término
T1
Tempo T1
T2
Tempo T2
T4
Tiroxina
TAC
Tacrolimus
TAP
Taquicardia Atrial Paroxística
TAX
Temperatura axilar
TB
Tuberculose
TB01 ou TB02
Acelerador Linear 1 ou 2
TBI
Irradiação corporal total
TC
Tomografia Computadorizada
TC4D
Tomografia Computadorizada 4D
TCE
Traumatismo crânioencefálico
TCLE
Termo de Consentimento Livre e Esclarecido
TCTH
Transplante de células tronco hematopoiéticas
TEC
Tempo de enchimento capilar
TEC ENF
Técnico de enfermagem
TEMP
Temperatura
TENS
Estimulação elétrica nervosa transcutânea
TEP
Tromboembolismo pulmonar
TET
Tubo endotraqueal
TETRA VIRAL
Tetra viral (Sarampo, Caxumba, Rubéola e Varicela)
TFAP
Treinamento funcional do assoalho pélvico
TFD
Tratamento fora do domicílio
TFG
Taxa de Filtração Glomerular
TG EXT
TS
Tipagem sanguínea
TSC
Tiragem subcostal
TSV
Taquicardia supraventricular
TTO
Tratamento
TU
Tumor
TV
Taquicardia ventricular
TVP
Trombose venosa profunda
TX
Transplante
UCA
Urocultura
UDI
Unidade de diagnóstico por imagem
UF
Ultrafiltração
UM
Unidade monitora
UN*
Unidade
UP
Úlcera de pressão
US
Ultrassom
US TV
Ultrassom transvaginal
UTI NEO
Unidade de tratamento intensivo neonatal
VAC
Volume de ar corrente
VAS
Vias aéreas superiores
VCD
Velcade, Ciclofosfamida e Dexametasona
VCM
Volume corpuscular médio
Tangente externa
TG INT
Tangente interna
TGI
Trato gastrointestinal
TGO
Transaminase Glutâmico Oxalacética
TGP
Transaminase Glutâmico Pirúvica
TIG
Taxa de infusão de glicose
TMNEc
Tumor, linfonodos, metástases, estádio clínico
TMO
Transplante de medula óssea
TN
Terapia nutricional
TNE
Terapia Nutricional Enteral
TNF
Tubo nasofaríngeo
TNO
Terapia nutricional oral
TNT
Tubo nasotraqueal
TOT
Tubo orotraqueal
TP
Tempo de Protrombina
TPA
Time de Planejamento de Alta
TPE
Plasmaferese
TPP
Trabalho de parto prematuro
TPS
Sistema de Planejamento de Radioterapia
TQT
Traqueostomia
TRS
Terapia renal substitutiva
VCT
Valor calórico total
VCV
Ventilação Ciclada a Volume
VD
Ventrículo direito
VE
Ventrículo esquerdo
VEF1
Volume Expiratório Forçado no minuto 1
VERT
Vertical
VET
Valor energético total
VGPR
Very good parcial response
VIA P
Via parenteral
VLP
Videolaparoscopia
VM
Ventilação mecânica
VMAT
Radioterapia em Arco Volumétrico Modulado
VMI
Ventilação mecânica invasiva
VMNI
Ventilação mecânica não invasiva
VNI
Ventilação não invasiva
VO
Via oral
VP
Veia periférica
VPC
Ventilação pressão controlada
VRET
Via retal
VSG
Velocidade de sedimentação globular
VSR
Vírus sincicial respiratório
VTD
Velcade, Talidomida e Dexametasona
WC
Banheiro (“Water Closet”)
XPE
Xarope
XiO
Sistema de planejamento radioterapia convencional marca CMS, modelo XiO
g*
Grama
h*
Hora
kcal
Quilocaloria
kg
Quilograma
l
Litro
mEq
Miliequivalente
mcg*
Micrograma
mg*
Miligrama
min
Minuto
ml*
Mililitro
mmHg
Milímetros de mercúrio
mpm
Movimentos por minuto
ng
Nanograma
seg
Segundo
ºC
Graus Celsius
`,Go="Texto fornecido pelo responsável pelo projeto, que informou conferência com a instituição.",Uo={"AC + D":{term:"AC + D",definition:"Doxorrubicina + Ciclofosfamida + Docitaxel"},ECOG:{term:"ECOG",definition:"Eastern Cooperative Cooperative Group"},FOLFIRI:{term:"FOLFIRI",definition:"Irinitecano + Leucovorin + Fluorouracil"},KeV:{term:"KeV",definition:"Kilovolt"},MSSA:{term:"MSSA",definition:"Methicillin-resistant Staphylococcys aureaus – Staphylococcus aureus sensível à Meticilina/Oxacilina"},MV:{term:"MV",definition:"Murmúrio vesicular"},NPT:{term:"NPT",definition:"Nutrição parenteral total"},PPlato:{term:"PPlat",definition:"Pressão de Plantô"},"R-CHOP":{term:"R-CHOP",definition:"Rituximabe + Vincristina + Doxorrubicina + Ciclofosfamida",supplement:"é um protocolo de tratamento oncológico padrão para o linfoma não-Hodgkin e outros linfomas de células B. A sigla representa a combinação de cinco medicamentos"},"R-CVP":{term:"R-CVP",definition:"Rituximabe + Vincristina + Ciclofosfamida",supplement:"refere-se a um protocolo de quimioimunoterapia utilizado no tratamento do câncer, mais especificamente para o linfoma não Hodgkin de células B",reference:{label:"R-CVP — Cancer Research UK (link fornecido)",href:"https://www.cancerresearchuk.org/about-cancer/treatment/drugs/r-cvp"}},SIRS:{term:"SIRS",definition:"Síndrome de insuficiência respiratória"},"TG EXT":{term:"TG EXT",definition:"Tangente externa"},VEF1:{term:"VEF1",definition:"Volume Expiratório Forçado no minuto 1"}},oo={sourceLabel:Go,entries:Uo},Qe={label:"Transcrição fornecida para o projeto; fonte indicada: glossário no Google Looker Studio",href:"https://datastudio.google.com/u/0/reporting/43feb19a-9a1e-41e5-b86a-2dd1914020ea/page/p_tx8e7de5fd"},Ta={MSSA:"A redação mantida traz “resistant” em inglês e “sensível” em português na mesma definição.",SIRS:"Confirmar com o responsável a correspondência entre esta sigla e a expansão enviada.",PPlato:"Conferir a expressão “Pressão de Plantô” na transcrição. O texto enviado foi preservado.",VEF1:"Conferir a expressão de tempo “minuto 1” com a fonte. O texto enviado foi preservado.",ECOG:"Conferir a repetição “Cooperative Cooperative” na transcrição.",KeV:"Conferir a correspondência entre a sigla e a unidade informada na fonte.",MeV:"Conferir a correspondência entre a sigla e a unidade informada na fonte.","AC + D":"Conferir a grafia dos nomes e a composição informada com o responsável pelo material; não usar como orientação de tratamento.",FOLFIRI:"Conferir a grafia dos nomes e a composição informada com o responsável pelo material; não usar como orientação de tratamento.","R-CHOP":"O complemento fornecido menciona cinco medicamentos, enquanto a lista recebida contém quatro. Nenhum componente foi acrescentado.","R-CVP":"Conferir a composição informada com o responsável pelo material. Nenhum componente foi acrescentado ao texto enviado."},wa=oo.entries,_o=oo.sourceLabel,Oa={AVP:"#dispositivos",BH:"#rotinas",BHP:"#rotinas",BHT:"#rotinas",BI:"#equipamentos",BIPAP:"#equipamentos",CNAF:"#equipamentos",CPAP:"#equipamentos",CTI:"#acolhimento",CTIA:"#acolhimento",CVA:"#dispositivos",CVC:"#dispositivos",CVD:"#dispositivos",EPI:"#acolhimento",EVA:"#escalas",FC:"#equipamentos",FiO2:"#equipamentos",FR:"#equipamentos",GCS:"#escalas",PA:"#equipamentos",PAM:"#equipamentos",PEEP:"#equipamentos",PICC:"#dispositivos",RASS:"#escalas",SNE:"#dispositivos",SNG:"#dispositivos",SVA:"#dispositivos",SVD:"#dispositivos",SpO2:"#equipamentos",TET:"#dispositivos",TOT:"#dispositivos",TQT:"#dispositivos",VM:"#equipamentos"},$=Ho.split(/\r?\n/).map(a=>a.trim()).filter(Boolean),xa=[],ia="Tangente externa";for(let a=0;a<$.length;)if($[a]==="TG EXT"&&$[a+1]==="TS"){if($.filter(o=>o===ia).length!==1)throw new Error("Conferir o trecho deslocado de TG EXT na transcrição.");xa.push({term:$[a],definition:ia}),a+=1}else if($[a]===ia&&$[a-1]==="Volume corpuscular médio")a+=1;else{if(!$[a+1])throw new Error(`Definição ausente na transcrição: ${$[a]}`);xa.push({term:$[a],definition:$[a+1]}),a+=2}const Da=new Map,ee=xa.map(({term:a,definition:o})=>{const s=Object.hasOwn(wa,a)?wa[a]:void 0,n=(s==null?void 0:s.term)??a,r=a.normalize("NFKD").replace(/[\u0300-\u036f]/g,"").toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"")||"termo",i=(Da.get(r)??0)+1;Da.set(r,i);const t=n.normalize("NFD").replace(/[\u0300-\u036f]/g,"").toUpperCase().charAt(0);return{id:i===1?r:`${r}-${i}`,term:n,definition:(s==null?void 0:s.definition)??o,aliases:n===a?[]:[a],href:Object.hasOwn(Oa,a)?Oa[a]:void 0,sourceLabel:s?_o:Qe.label,reviewNote:Object.hasOwn(Ta,a)?Ta[a]:void 0,supplement:s==null?void 0:s.supplement,reference:s==null?void 0:s.reference,group:a==="ºC"?"C":/[0-9]/.test(t)?"0–9":/[A-Z]/.test(t)?t:"O"}}),Oe=a=>a.normalize("NFKD").replace(/[\u0300-\u036f]/g,"").toLowerCase().replace(/\s*([+/*.-])\s*/g,"$1").replace(/\s+/g," ").trim();function Qo(a){const o=Oe(a);if(!o)return ee;const s=o.split(" ");return ee.filter(n=>{const r=Oe([n.term,...n.aliases,n.definition,n.supplement??""].join(" "));return s.every(i=>r.includes(i))}).sort((n,r)=>{const i=t=>t.term===a.trim()?4:Oe(t.term)===o?3:Oe(t.term).startsWith(o)?2:0;return i(r)-i(n)})}const ye={"term.glasgow":"term.gcs","term.bps":"tool.glossario","term.diurese":"tool.glossario","term.pai":"tool.glossario","term.painad":"tool.glossario","term.perfusao":"tool.glossario","term.pni":"tool.glossario","term.pop":"tool.glossario","term.sbar":"tool.glossario"},W=[{id:"preceptor",title:"Identificar meu preceptor e enfermeiro supervisor",detail:"Confirme com quem você vai acompanhar os cuidados e a quem levar dúvidas antes de realizar uma atividade.",href:"#acolhimento",sourceLabel:"Módulo Bem-vindo à CTI · Equipe multiprofissional"},{id:"equipe",title:"Conhecer a equipe e os canais de comunicação",detail:"Peça uma apresentação das funções da equipe e de como contatar os profissionais responsáveis no setor.",href:"#acolhimento",sourceLabel:"Módulo Bem-vindo à CTI · Equipe multiprofissional"},{id:"materiais",title:"Localizar os materiais com orientação",detail:"Faça um reconhecimento acompanhado do setor e pergunte onde ficam os materiais de uso cotidiano e de emergência. A localização depende do serviço.",href:"#acolhimento",sourceLabel:"Módulo Bem-vindo à CTI · Segurança e primeiro dia"},{id:"maos",title:"Conhecer os recursos para higiene das mãos",detail:"Localize os recursos disponíveis e revise com o preceptor quando e como higienizar as mãos, conforme as orientações do serviço.",href:"#acolhimento",sourceLabel:"Módulo Bem-vindo à CTI; Caderno, p. 40",sourcePage:40},{id:"epis",title:"Conferir EPIs e precauções",detail:"Pergunte onde encontrar os EPIs e como identificar as precauções e as medidas previstas para cada situação. Confirme as dúvidas com o preceptor.",href:"#acolhimento",sourceLabel:"Módulo Bem-vindo à CTI; Caderno, p. 40",sourcePage:40},{id:"identificacao",title:"Revisar identificação, privacidade e sigilo",detail:"Conheça a conferência da identificação e as formas autorizadas de comunicação. Não fotografe pacientes, prontuários ou telas para estudar.",href:"#acolhimento",sourceLabel:"Módulo Bem-vindo à CTI; Caderno, p. 3",sourcePage:3},{id:"plantao",title:"Entender a organização do plantão",detail:"Acompanhe como são recebidas as informações, os horários e as pendências. Pergunte quais atividades você pode acompanhar e executar sob supervisão.",href:"#rotinas",sourceLabel:"Módulo Rotinas da CTI; Caderno, pp. 3 e 39",sourcePage:39},{id:"equipamentos",title:"Reconhecer os equipamentos com o preceptor",detail:"Identifique os equipamentos do setor e saiba a quem comunicar um alarme. A leitura do aplicativo não substitui treinamento para operar ou ajustar equipamentos.",href:"#equipamentos",sourceLabel:"Módulo Equipamentos hospitalares; Caderno, p. 8",sourcePage:8},{id:"ajuda",title:"Saber como pedir ajuda e acionar o fluxo de emergência",detail:"Confirme com a equipe como solicitar ajuda imediata e quais são suas atribuições. Não espere terminar um registro para comunicar uma situação urgente.",href:"#rotinas",sourceLabel:"Módulo Rotinas da CTI · Alterações clínicas e registros"},{id:"registros",title:"Conhecer as orientações de registro",detail:"Pergunte como registrar cuidados e comunicações no sistema autorizado, com supervisão. Não coloque informações de pacientes neste aplicativo.",href:"#registros",sourceLabel:"Módulo Anotações de enfermagem; Caderno, p. 38",sourcePage:38}],H=a=>({label:`Caderno CTI Adulto — página ${a}`,href:`/materiais/caderno-cti-adulto-digital.pdf#page=${a}`}),Q=[{id:"alarme-na-mobilizacao",title:"Um alarme durante a mobilização",subject:"Equipamentos",summary:"Um alarme surge durante um cuidado acompanhado pela equipe. O foco é observar e comunicar.",goal:"Reconhecer que o alarme exige atenção ao paciente e avaliação da equipe responsável.",steps:[{id:"reconhecer-alarme",situation:"Situação fictícia: durante uma mobilização acompanhada pelo preceptor, o ventilador começa a alarmar. Você ainda não sabe a causa.",question:"Qual atitude deve orientar sua participação?",options:[{text:"Silenciar o alarme e terminar o cuidado antes de avisar.",feedback:"Silenciar sem avaliar a causa pode atrasar o reconhecimento de uma falha. O alarme precisa ser comunicado e o paciente observado."},{text:"Observar o paciente e avisar imediatamente a equipe responsável.",feedback:"Essa é a atitude esperada nesta situação. A equipe precisa avaliar o paciente e a causa do alarme; o estagiário participa com supervisão."},{text:"Mudar os parâmetros até o alarme desaparecer.",feedback:"Fazer o alarme desaparecer não demonstra que o problema foi resolvido. A alteração de parâmetros não cabe ao estagiário por iniciativa própria."},{text:"Esperar que outro estudante reconheça o equipamento.",feedback:"Esperar pode atrasar a ajuda. Acione a equipe responsável e descreva o que observou, sem depender de outro estudante para decidir."}],answer:1},{id:"comunicar-alarme",situation:"Na continuação simulada, o preceptor assume a avaliação. Você foi orientado a comunicar o que presenciou, sem fazer um diagnóstico.",question:"Qual comunicação é mais útil?",options:[{text:"“O ventilador está quebrado, tenho certeza.”",feedback:"A causa ainda não foi estabelecida. Atribuir um diagnóstico ao equipamento pode desviar a avaliação dos achados reais."},{text:"“Foi só um alarme, então não houve problema.”",feedback:"A presença de um alarme não permite concluir que nada ocorreu. Descreva o momento, o cuidado em andamento e os achados observados."},{text:"“O alarme começou durante a mobilização; precisamos avaliar o paciente e o circuito.”",feedback:"A mensagem informa o contexto e pede avaliação, sem afirmar uma causa não confirmada. Acrescente somente os achados que realmente observou."},{text:"“Depois conto na passagem de plantão.”",feedback:"A passagem de plantão não substitui a comunicação imediata de uma mudança durante o cuidado. Primeiro solicite a avaliação necessária."}],answer:2}],discussion:"Converse com o preceptor: como pedir ajuda no setor e quais observações você pode realizar dentro de sua competência? Reveja o cuidado ao paciente antes de interpretar apenas a tela do equipamento.",relatedModule:{label:"Revisar equipamentos hospitalares",href:"#equipamentos"},sources:[H(8)]},{id:"duvida-sobre-sonda",title:"A sonda está liberada para uso?",subject:"Dispositivos",summary:"Há uma dúvida sobre a liberação da sonda para a dieta. O caso trabalha verificação e comunicação.",goal:"Distinguir presença e fixação do dispositivo de confirmação e liberação para o uso prescrito.",steps:[{id:"esclarecer-liberacao",situation:"Situação fictícia: antes de uma dieta prescrita, você não consegue confirmar se a sonda nasoenteral está liberada para uso.",question:"O que fazer diante dessa dúvida?",options:[{text:"Não iniciar a administração e esclarecer a liberação com o enfermeiro.",feedback:"Essa é a atitude esperada. A dúvida precisa ser esclarecida antes do uso, seguindo o processo de confirmação e liberação adotado pelo serviço."},{text:"Iniciar uma pequena quantidade para testar a sonda.",feedback:"Administrar para testar não confirma posicionamento seguro. Esclareça a liberação e o método de confirmação antes de iniciar o cuidado."},{text:"Usar porque a sonda parece bem fixada.",feedback:"A fixação externa, sozinha, não comprova posicionamento nem liberação. A conferência precisa seguir o processo institucional."},{text:"Seguir a opinião de um colega que também está começando.",feedback:"A dúvida sobre liberação exige orientação do profissional responsável e verificação no processo autorizado, não apenas a opinião de outro estudante."}],answer:0},{id:"registrar-interrupcao",situation:"Na continuação simulada, o enfermeiro orientou aguardar a avaliação antes de iniciar a dieta.",question:"Como essa ocorrência deve ser tratada no registro autorizado?",options:[{text:"Registrar a dieta como administrada porque estava prescrita.",feedback:"Prescrição não significa execução. O registro deve refletir o cuidado efetivamente realizado e não pode indicar uma administração que não ocorreu."},{text:"Omitir a ocorrência porque não houve administração.",feedback:"Uma interrupção ou não início e sua razão podem ser relevantes à continuidade do cuidado. Registre conforme o padrão institucional."},{text:"Escrever apenas “sonda ruim”, sem explicar.",feedback:"A expressão é vaga e sugere uma conclusão não verificada. Descreva a dúvida, a comunicação e a orientação recebida de maneira objetiva."},{text:"Registrar o não início, o motivo e a comunicação e orientação recebidas.",feedback:"Essa é a descrição esperada nesta situação. Acrescente horário e identificação dos envolvidos conforme o sistema e as regras do serviço."}],answer:3}],discussion:"Pergunte ao preceptor onde conferir a liberação de uso e como registrar a dieta não iniciada. O exercício não ensina um método de confirmação de posição nem autoriza usar o dispositivo.",relatedModule:{label:"Revisar dispositivos",href:"#dispositivos"},sources:[H(25),H(38)]},{id:"comunicacao-de-mudanca",title:"Uma mudança precisa ser comunicada",subject:"Comunicação",summary:"Organize uma comunicação de ajuda e preserve uma pendência na passagem de plantão.",goal:"Comunicar achados e contexto sem aguardar o registro ou presumir que a outra pessoa já sabe.",steps:[{id:"pedir-avaliacao",situation:"Situação fictícia: você percebe uma mudança em relação à observação anterior durante um cuidado supervisionado. O enfermeiro ainda não recebeu essa informação.",question:"Qual mensagem favorece uma avaliação oportuna?",options:[{text:"“Está diferente; depois vejo se continua.”",feedback:"Esperar sem comunicar pode atrasar a avaliação. Descreva a mudança percebida e peça ajuda pelo fluxo do setor, sem presumir que ela vai passar."},{text:"“Observei esta mudança em relação à avaliação anterior; preciso de sua avaliação.”",feedback:"A mensagem apresenta a mudança e solicita avaliação. Complemente com contexto, horários e achados objetivos, sem atrasar a chamada para terminar um registro."},{text:"“Já sei a causa; vou alterar o tratamento.”",feedback:"Uma mudança observada não autoriza concluir a causa ou alterar o tratamento. O estudante deve comunicar e seguir a orientação do profissional responsável."},{text:"“Vou mandar uma foto do prontuário para alguém conferir.”",feedback:"Fotos e compartilhamento em canais não autorizados comprometem o sigilo. Use o fluxo de comunicação assistencial autorizado pelo serviço."}],answer:1},{id:"transferir-pendencia",situation:"Na continuação simulada, a equipe foi avisada e deixou uma reavaliação como pendência. O plantão está terminando.",question:"O que deve ser transmitido à equipe que recebe o plantão?",options:[{text:"Somente que “o plantão foi tranquilo”.",feedback:"Uma descrição genérica omite a mudança e a pendência. A continuidade do cuidado depende de informações específicas e verificáveis."},{text:"Uma hipótese pessoal como se fosse um diagnóstico confirmado.",feedback:"Separe os achados observados das hipóteses. Apresente o contexto e a avaliação pendente sem atribuir uma confirmação que não existe."},{text:"A mudança, o que foi comunicado e feito e qual reavaliação permanece pendente.",feedback:"Esses elementos ajudam a dar continuidade ao cuidado. Confirme dúvidas com quem recebe o plantão e use o instrumento institucional."},{text:"Nada, porque a equipe seguinte pode descobrir no prontuário.",feedback:"O prontuário não substitui uma passagem de plantão clara. Pendências precisam ser comunicadas pelo fluxo previsto, preservando o sigilo."}],answer:2}],discussion:"Com o preceptor, adapte uma comunicação fictícia ao roteiro SBAR: situação, contexto, dados observados e ajuda necessária. Descubra o canal local e o que fazer se a ajuda não chegar.",relatedModule:{label:"Revisar rotinas e passagem de plantão",href:"#rotinas"},sources:[H(39),H(38)]},{id:"registro-do-cuidado",title:"Uma anotação que conta o que aconteceu",subject:"Registros",summary:"Escolha uma descrição objetiva e lide com um volume que não pôde ser medido.",goal:"Distinguir observações e ações realizadas de expressões vagas ou informações presumidas.",steps:[{id:"descrever-cuidado",situation:"Situação fictícia: durante uma higiene supervisionada, houve desconforto. A equipe foi informada e ajustou a posição conforme orientação.",question:"Qual princípio orienta a anotação desse cuidado?",options:[{text:"Registrar “banho feito, tudo normal”, para ser breve.",feedback:"A expressão omite o desconforto e as ações. Brevidade não deve eliminar informações necessárias à compreensão do cuidado."},{text:"Copiar a anotação anterior e mudar o horário.",feedback:"A anotação deve corresponder à observação e ao cuidado daquele momento. Copiar sem avaliar pode perpetuar informações incorretas."},{text:"Incluir detalhes que você não observou para deixar o relato completo.",feedback:"Completar lacunas com suposições compromete o registro. Descreva o que observou, fez e comunicou, sem inventar achados."},{text:"Descrever horário, achados, cuidado, comunicação e resposta observada.",feedback:"Esses elementos tornam o cuidado rastreável. Use o padrão institucional e registre apenas o que foi observado ou efetivamente realizado."}],answer:3},{id:"volume-nao-medido",situation:"Na continuação simulada, uma eliminação ocorreu, mas o volume não pôde ser medido.",question:"Como lidar com essa informação?",options:[{text:"Informar a ocorrência e que o volume não foi medido, conforme o padrão local.",feedback:"Essa descrição preserva o que se sabe e o que não foi medido. Comunique a situação ao responsável quando pertinente e siga o padrão de registro."},{text:"Repetir o volume do período anterior.",feedback:"Um volume anterior não representa uma nova medição. Reutilizá-lo cria um dado que não foi obtido."},{text:"Estimar e registrar como se o volume tivesse sido medido.",feedback:"Uma estimativa não pode aparecer como uma medição real. Registre a limitação com clareza, seguindo as regras do serviço."},{text:"Omitir a eliminação para evitar um campo incompleto.",feedback:"A omissão esconde uma ocorrência relevante. Informe que houve eliminação e a impossibilidade de mensurar, sem inventar o volume."}],answer:0}],discussion:"Compare com o preceptor uma anotação fictícia vaga e outra objetiva. Quais dados permitem entender o evento sem acrescentar julgamentos? Não insira informações de pacientes neste aplicativo.",relatedModule:{label:"Revisar anotações de enfermagem",href:"#registros"},sources:[H(38),H(24)]},{id:"escolha-e-limites-das-escalas",title:"Qual informação cada escala oferece?",subject:"Escalas",summary:"Diferencie relato de dor, comportamento observado e nível de despertar.",goal:"Reconhecer o autorrelato e os limites da observação, sem converter uma escala em outra.",steps:[{id:"valorizar-autorrelato",situation:"Situação fictícia: uma pessoa intubada compreende a orientação e consegue indicar sua experiência por uma comunicação acessível.",question:"Qual princípio deve orientar a escolha do instrumento de dor com o enfermeiro?",options:[{text:"Usar PAINAD em toda pessoa intubada.",feedback:"A PAINAD tem um perfil de uso específico, descrito no caderno para demência avançada sem autorrelato confiável. A intubação não determina essa escolha."},{text:"Concluir ausência de dor porque a pessoa está quieta.",feedback:"Imobilidade não comprova ausência de dor. É necessário considerar a comunicação possível, o contexto e o instrumento adequado."},{text:"Tentar o autorrelato confiável e escolher um instrumento adequado ao perfil.",feedback:"Esse é o princípio descrito no caderno. A intubação, por si só, não impede autorrelato; confirme a comunicação e o instrumento com o enfermeiro."},{text:"Definir a dor apenas pela frequência cardíaca no monitor.",feedback:"Sinais vitais isolados não medem a experiência da dor. A avaliação precisa considerar o autorrelato quando possível e instrumentos apropriados."}],answer:2},{id:"distinguir-sedacao-dor",situation:"Na continuação simulada, durante a discussão de outro exemplo, alguém afirma que uma pessoa sem movimentos não sente dor porque está sedada.",question:"Qual resposta ajuda a revisar essa conclusão?",options:[{text:"“Sedação sempre elimina a necessidade de avaliar a dor.”",feedback:"Sedação e analgesia não são equivalentes. A ausência de movimentos não dispensa considerar dor e limitações da avaliação."},{text:"“A ausência de movimentos pode limitar a observação; RASS e escalas de dor avaliam aspectos diferentes.”",feedback:"Essa distinção está nos materiais. Registre as limitações e discuta a avaliação com o enfermeiro; não converta RASS em uma medida de dor."},{text:"“Basta transformar o valor da RASS em uma nota de dor.”",feedback:"A RASS descreve agitação e despertar, não intensidade da dor. Seus níveis não devem ser convertidos em um escore de autorrelato."},{text:"“O estudante deve suspender a sedação para testar.”",feedback:"O exercício não autoriza suspender ou ajustar sedação. A avaliação deve seguir a orientação responsável, o treinamento e o instrumento do serviço."}],answer:1}],discussion:"Discuta com o preceptor quais formas de comunicação estão disponíveis e o que pode impedir observar uma resposta. Reveja as diferenças entre EVA, BPS, PAINAD e RASS, sem classificar pacientes com este exercício.",relatedModule:{label:"Revisar escalas clínicas",href:"#escalas"},sources:[H(10),H(15),H(18)]}];["casos simulados fictícios PBL aprendizagem baseada em problemas",...Q.flatMap(a=>[a.title,a.subject,a.summary,a.goal,a.discussion,...a.steps.flatMap(o=>[o.situation,o.question,...o.options.flatMap(s=>[s.text,s.feedback])])])].join(" ");const io=[{subject:"Segurança",text:"Antes de iniciar um cuidado, como deve ser confirmada a identificação da pessoa?",options:["Conferindo a identificação conforme o protocolo institucional.","Usando somente o número do leito indicado na passagem de plantão.","Reconhecendo a pessoa pela aparência e pelos equipamentos presentes.","Considerando suficiente que outro estudante confirme o leito."],answer:0,explanation:"A identificação deve seguir a conferência prevista pelo serviço. Leito, aparência ou reconhecimento informal não substituem esse processo antes do cuidado."},{subject:"Segurança",text:"O que orienta a escolha dos EPIs durante as atividades no setor?",options:["A preferência pessoal por um equipamento mais confortável.","O uso do mesmo conjunto de EPIs em todas as situações.","A exposição prevista e as precauções orientadas pelo serviço.","A escolha de outro estudante, sem conferir a orientação local."],answer:2,explanation:"Os EPIs e as medidas adicionais dependem da exposição e das precauções aplicáveis. O preceptor deve apresentar como reconhecer e seguir essas orientações no serviço."},{subject:"Segurança",text:"Ao terminar um cuidado no box, qual conferência favorece a segurança?",options:["Considerar a tarefa encerrada assim que terminar o procedimento principal.","Conferir posição e proteção da pessoa, conexões, linhas sem tração, alarmes e pendências.","Revisar somente o material descartado, deixando as conexões para o próximo turno.","Verificar apenas se a tela do monitor continua ligada."],answer:1,explanation:"O cuidado termina com uma conferência do conjunto: pessoa protegida, dispositivos e conexões preservados, alarmes ativos e informações pertinentes comunicadas. A checagem segue o plano e a orientação da equipe."},{subject:"Registros",text:"Por que a expressão “diurese boa” é insuficiente em uma anotação?",options:["Porque toda anotação de eliminação precisa usar somente siglas.","Porque descrever a urina é permitido apenas na passagem de plantão.","Porque o registro deve conter somente a interpretação do profissional.","Porque não informa volume medido, período e características observadas."],answer:3,explanation:"O registro deve apresentar dados observados e medidos, com o período correspondente. “Boa” é uma avaliação vaga e não permite acompanhar a eliminação ao longo do cuidado."},{subject:"Registros",text:"Situação fictícia: após a higiene, qual informação ajuda a documentar a resposta ao cuidado?",options:["Achados observados, tolerância e resposta da pessoa, além do cuidado realizado.","Somente a frase “higiene completa”, sem outros dados pertinentes.","Uma cópia do registro de higiene feito no turno anterior.","Um julgamento sobre a personalidade da pessoa durante o banho."],answer:0,explanation:"A anotação deve refletir o cuidado efetivamente realizado e a resposta observada, incluindo achados pertinentes. Copiar outro turno ou usar julgamentos não descreve o que aconteceu."},{subject:"Registros",text:"Como devem ser escolhidas as siglas usadas na anotação de enfermagem?",options:["Usando abreviações pessoais, desde que reduzam o tempo de escrita.","Adotando as abreviações mais usadas nas conversas de celular.","Utilizando siglas padronizadas e a identificação exigida pelo serviço.","Criando uma sigla nova quando o nome do dispositivo for longo."],answer:2,explanation:"Siglas padronizadas e identificação adequada ajudam a tornar o registro compreensível e rastreável. Abreviações inventadas podem gerar interpretações diferentes."},{subject:"Ética",text:"Qual atitude expressa acolhimento e humanização antes de um cuidado?",options:["Iniciar o cuidado e explicar apenas se a pessoa perguntar.","Apresentar-se, explicar o cuidado e preservar a intimidade.","Conversar somente com os colegas, mesmo quando a pessoa consegue participar.","Considerar que a presença de equipamentos dispensa a explicação."],answer:1,explanation:"Apresentação, explicação e respeito à intimidade fazem parte do cuidado. A condição clínica e os equipamentos não retiram a dignidade nem a necessidade de comunicação adequada."},{subject:"Ética",text:"Por quais meios devem circular as informações assistenciais necessárias ao cuidado?",options:["Por qualquer grupo de mensagens em que haja profissionais de saúde.","Em conversas no corredor, desde que o nome da pessoa seja omitido.","Em arquivos pessoais do estudante, para facilitar consultas posteriores.","Pelos canais autorizados, com os profissionais que precisam dessas informações."],answer:3,explanation:"O sigilo exige usar os canais autorizados e compartilhar informações com finalidade assistencial. Omitir apenas o nome não elimina a possibilidade de identificação indireta."},{subject:"Escalas",text:"Qual característica distingue a EVA apresentada no aplicativo de uma escala numérica?",options:["A intensidade é inferida pela expressão facial do paciente.","O resultado é a soma de comportamentos observados pela equipe.","A própria pessoa marca a dor em uma linha contínua, cuja distância é medida.","A intensidade é definida pela frequência cardíaca exibida no monitor."],answer:2,explanation:"A EVA descrita no caderno usa uma linha contínua no formulário físico; a pessoa faz a marca e a distância é medida. Pedir apenas um número corresponde a outro formato, e a linha da tela é ilustrativa."},{subject:"Escalas",text:"Quais são os três domínios observados na BPS descrita no caderno?",options:["Expressão facial, membros superiores e adaptação à ventilação.","Abertura ocular, resposta verbal e resposta motora.","Respiração, consolabilidade e diurese.","Pressão arterial, temperatura e frequência cardíaca."],answer:0,explanation:"A BPS reúne expressão facial, membros superiores e adaptação à ventilação. Cada domínio tem critérios próprios; sinais vitais não substituem esses itens nem o autorrelato quando ele é confiável."},{subject:"Escalas",text:"O que significa reconhecer que BPS 3 é a pontuação mínima da escala?",options:["Que o resultado comprova, sozinho, ausência de dor.","Que BPS 3 pode ser registrada automaticamente como EVA zero.","Que a observação do contexto deixa de ser necessária.","Que é o mínimo do instrumento, sem comprovar isoladamente ausência de dor."],answer:3,explanation:"O caderno ressalta que BPS 3, isoladamente, não comprova ausência de dor. O resultado precisa ser registrado com contexto e achados, sem conversão automática para uma escala de autorrelato."},{subject:"Escalas",text:"Para qual perfil a PAINAD é apresentada nos materiais do aplicativo?",options:["Qualquer pessoa intubada, independentemente das possibilidades de comunicação.","Pessoa com demência avançada sem autorrelato confiável, após tentar comunicação acessível.","Qualquer pessoa que prefira não responder à pergunta naquele momento.","Pessoa alerta que compreende e consegue comunicar sua própria dor."],answer:1,explanation:"A PAINAD é apresentada para demência avançada sem autorrelato confiável. A impossibilidade de falar, por si só, não indica o instrumento; sua adequação deve ser confirmada com a equipe."},{subject:"Escalas",text:"Qual informação a RASS organiza?",options:["O nível de agitação e de despertar, com critérios próprios.","A intensidade da dor relatada pela pessoa em uma linha contínua.","A confirmação isolada de delirium.","O risco de infecção de um dispositivo."],answer:0,explanation:"A RASS descreve agitação e sedação/despertar. Dor e delirium exigem avaliações próprias; uma classificação na RASS não autoriza o estudante a ajustar medicamentos."},{subject:"Dispositivos",text:"Qual definição corresponde ao PICC?",options:["Sonda destinada à drenagem de urina em sistema fechado.","Tubo de via aérea introduzido pela boca.","Cateter central inserido por uma veia periférica.","Interface usada exclusivamente para fornecer oxigênio pelo nariz."],answer:2,explanation:"PICC é um cateter central de inserção periférica. Sua identificação e seus cuidados devem seguir as orientações específicas do serviço; o aspecto externo não basta para confirmar tipo ou posição."},{subject:"Dispositivos",text:"Qual princípio orienta a observação de uma sonda vesical de demora?",options:["Desconectar o sistema periodicamente para conferir se há urina.","Preservar o sistema fechado e observar fixação, fluxo e integridade.","Considerar suficiente observar a bolsa somente na passagem de plantão.","Interpretar ausência de drenagem como ausência de necessidade de acompanhamento."],answer:1,explanation:"A SVD exige preservação do sistema fechado e observação de fixação, fluxo e integridade. Desconexões desnecessárias aumentam o risco de infecção; mudanças e desconforto devem ser comunicados."},{subject:"Dispositivos",text:"Situação fictícia: o curativo de um acesso venoso está úmido ou solto. Como interpretar esse achado?",options:["É suficiente observar apenas se a solução continua correndo.","A fixação do cateter elimina a necessidade de avaliar o curativo.","O aspecto do curativo não interfere na observação do acesso.","O achado precisa de avaliação e cuidado conforme o protocolo, com comunicação à equipe."],answer:3,explanation:"Curativo úmido, sujo ou solto precisa de avaliação e do cuidado previsto no protocolo. A continuidade da infusão não substitui a observação do sítio, do curativo e das conexões."},{subject:"Dispositivos",text:"Durante higiene ou mobilização de uma pessoa com tubo orotraqueal, qual cuidado deve integrar o planejamento?",options:["Planejar com a equipe como preservar fixação e conexões e evitar tração.","Considerar que a fixação dispensa observar a posição do dispositivo.","Deixar a conferência das conexões somente para o fim do plantão.","Realizar a movimentação sem apoio porque o tubo já está instalado."],answer:0,explanation:"A equipe deve planejar o cuidado para preservar fixação e conexões e evitar tração. Deslocamentos e falhas exigem comunicação imediata, sem reposicionar o tubo por iniciativa própria."},{subject:"Equipamentos",text:"Por que a qualidade do sinal precisa ser considerada ao observar o monitor multiparamétrico?",options:["Porque qualquer alarme confirma, sozinho, um diagnóstico.","Porque artefatos e problemas de sensores podem distorcer a leitura.","Porque a tela substitui a observação da pessoa.","Porque um valor isolado mostra toda a evolução do quadro."],answer:1,explanation:"Movimento, sensores e qualidade do sinal podem influenciar as leituras. A observação reúne a condição da pessoa, os sinais, as tendências e a avaliação da equipe, sem concluir pelo número isolado."},{subject:"Equipamentos",text:"Como reconhecer a solução e a terapia associadas a uma bomba de infusão?",options:["Pela posição em que a bomba está colocada no suporte.","Pela aparência da bomba, sem conferir o rótulo.","Pela lembrança do que estava sendo infundido no turno anterior.","Conferindo identificação, prescrição e linha com a equipe responsável."],answer:3,explanation:"A terapia precisa ser conferida pela identificação e pela prescrição, acompanhando a linha correspondente com a equipe. A posição ou aparência da bomba não identifica o conteúdo administrado."},{subject:"Equipamentos",text:"Qual característica identifica o funcionamento geral de uma bomba de seringa?",options:["A captação de sinais cardíacos por eletrodos.","A coleta de secreções em um frasco por vácuo.","Um mecanismo que movimenta o êmbolo de uma seringa compatível.","A drenagem de urina para uma bolsa coletora."],answer:2,explanation:"A bomba de seringa movimenta o êmbolo de uma seringa compatível para controlar a administração. Reconhecer essa finalidade não substitui a capacitação para instalar, manipular ou programar o equipamento."},{subject:"Rotinas",text:"O que o balanço hídrico reúne em um período definido?",options:["Os volumes de entradas e saídas, com registros e horários correspondentes.","Somente a quantidade de urina observada no fim do plantão.","Somente o volume de soluções que ainda está nas bombas.","Uma descrição geral do estado da pele, sem volumes."],answer:0,explanation:"O acompanhamento do balanço inclui entradas e saídas efetivamente registradas no período. Seu resultado precisa ser considerado no contexto do cuidado e não define, sozinho, a volemia."},{subject:"Rotinas",text:"Situação fictícia: surge uma dúvida na conferência da prescrição antes de administrar um medicamento. Qual é o momento de esclarecê-la?",options:["Depois da administração, para não atrasar o registro.","Na próxima passagem de plantão, se não houver queixa.","Antes de administrar, com o enfermeiro responsável.","Somente quando a solução terminar."],answer:2,explanation:"Dúvidas sobre prescrição, identificação e verificações de segurança devem ser esclarecidas antes da administração. O estudante não deve improvisar ou alterar a prescrição por iniciativa própria."},{subject:"Comunicação",text:"Qual conjunto de informações favorece a continuidade do cuidado na passagem de plantão?",options:["Somente os procedimentos que já foram concluídos.","Somente as condições observadas na admissão.","Apenas a lista de equipamentos que está no box.","Condições atuais, mudanças, dispositivos, riscos e pendências relevantes."],answer:3,explanation:"A passagem de plantão organiza informações atuais, eventos, dispositivos, riscos, metas e pendências conforme o instrumento institucional. Dúvidas devem ser esclarecidas, preservando o sigilo."},{subject:"Comunicação",text:"Situação fictícia: uma mudança importante exige ajuda imediata. Qual sequência favorece o cuidado?",options:["Terminar toda a anotação e só depois avisar a equipe.","Solicitar ajuda pelo fluxo do serviço e registrar os achados e ações pertinentes.","Aguardar a próxima medição antes de comunicar qualquer mudança.","Anotar somente “equipe avisada”, sem identificar o que ocorreu."],answer:1,explanation:"Em uma situação urgente, não se deve esperar concluir o registro para pedir ajuda. A comunicação segue o fluxo do serviço, e a anotação deve refletir achados, horários, profissional acionado e cuidados efetivamente realizados."}],Ko=[{label:"Bem-vindo à CTI — Segurança e primeiro dia; Caderno, página 3",page:3,moduleId:"acolhimento"},{label:"Bem-vindo à CTI — Segurança e primeiro dia; Caderno, página 40",page:40,moduleId:"acolhimento"},{label:"Rotinas da CTI; Caderno, página 40",page:40,moduleId:"rotinas"},{label:"Anotações de enfermagem — Eliminações e balanço; Caderno, página 23",page:23,moduleId:"registros"},{label:"Anotações de enfermagem — Higiene, conforto e mobilização; Caderno, página 38",page:38,moduleId:"registros"},{label:"Caderno CTI Adulto — Anotação de enfermagem, página 38",page:38,moduleId:"registros"},{label:"Bem-vindo à CTI — Ética, sigilo e humanização",moduleId:"acolhimento"},{label:"Bem-vindo à CTI — Ética, sigilo e humanização",moduleId:"acolhimento"},{label:"Escalas clínicas — EVA; Caderno, página 10",page:10,moduleId:"escalas"},{label:"Escalas clínicas — BPS; Caderno, páginas 11–12",page:11,moduleId:"escalas"},{label:"Escalas clínicas — BPS; Caderno, página 11",page:11,moduleId:"escalas"},{label:"Escalas clínicas — PAINAD; Caderno, páginas 13–14",page:13,moduleId:"escalas"},{label:"Escalas clínicas — RASS; Caderno, páginas 17–18",page:17,moduleId:"escalas"},{label:"Dispositivos — PICC; Glossário — PICC; Caderno, página 22",page:22,moduleId:"dispositivos"},{label:"Dispositivos — Sonda vesical de demora; Caderno, página 23",page:23,moduleId:"dispositivos"},{label:"Dispositivos — Cateter venoso central; Caderno, página 22",page:22,moduleId:"dispositivos"},{label:"Dispositivos — Tubo orotraqueal; Caderno, página 8",page:8,moduleId:"dispositivos"},{label:"Equipamentos hospitalares — Monitor multiparamétrico; Caderno, páginas 4–5",page:4,moduleId:"equipamentos"},{label:"Equipamentos hospitalares — Bomba de infusão; Caderno, página 28",page:28,moduleId:"equipamentos"},{label:"Equipamentos hospitalares — Bomba de seringa",moduleId:"equipamentos"},{label:"Rotinas da CTI — Balanço hídrico e dispositivos; Glossário — BH; Caderno, página 24",page:24,moduleId:"rotinas"},{label:"Rotinas da CTI — Administração segura de medicamentos; Caderno, página 28",page:28,moduleId:"rotinas"},{label:"Rotinas da CTI — Recebimento e passagem de plantão; Caderno, página 39",page:39,moduleId:"rotinas"},{label:"Rotinas da CTI — Alterações clínicas e registros; Caderno, páginas 38–39",page:39,moduleId:"rotinas"}],Aa=io.map((a,o)=>({text:a.text,...Ko[o]})),J={title:"Bundle de prevenção da PAV",purpose:"PAV significa pneumonia associada à ventilação mecânica. O bundle reúne medidas aplicadas de forma articulada para reduzir esse risco. Sua composição, frequência de conferência e exceções seguem o protocolo do serviço.",care:"Conheça o conjunto de medidas com o preceptor e o enfermeiro: higiene das mãos e da boca, posição da cabeceira, integridade do circuito, cuidado com o cuff e observação da via aérea. Registre o cuidado efetivamente realizado no sistema autorizado.",risk:"A aplicação exige avaliação individual, treinamento e respeito às atribuições profissionais. Não altere parâmetros ventilatórios, pressão do cuff ou sedação por iniciativa própria. O tópico não é um protocolo institucional validado nem um formulário de avaliação de paciente."},so=[{id:"higiene-das-maos",title:"Higiene das mãos",detail:"Realize a higiene das mãos nos momentos e com a técnica orientados pelo serviço, incluindo os cuidados com a pessoa e seus dispositivos. Conheça também as precauções e os EPIs indicados com o preceptor.",scope:"Cuidados acompanhados pelo preceptor, conforme as orientações do serviço."},{id:"cabeceira",title:"Cabeceira quando indicada",detail:"O caderno descreve cabeceira de 30 a 45° quando indicada e sem contraindicação. Confira a indicação, a posição e a tolerância com a equipe, inclusive após higiene ou mobilização, respeitando o plano individual.",scope:"A posição depende da avaliação individual e das contraindicações."},{id:"higiene-oral",title:"Higiene oral conforme o POP",detail:"Observe a cavidade oral e realize a higiene conforme o Procedimento Operacional Padrão (POP), o plano de cuidados e a supervisão recebida. Técnica, frequência e produtos dependem da avaliação e da orientação do serviço; esta tela não define um antisséptico obrigatório.",scope:"Execução conforme competência, treinamento e supervisão aplicáveis."},{id:"circuito-e-condensado",title:"Circuito íntegro e atenção ao condensado",detail:"Observe a integridade do circuito e das conexões. Evite manipulações e desconexões desnecessárias e que o condensado alcance a pessoa. O manejo do condensado e as trocas de componentes seguem o protocolo e a orientação da equipe.",scope:"Observe e comunique falhas; não improvise montagem ou troca de componentes."},{id:"cuff",title:"Cuff (balonete) e segurança da via aérea",detail:"O caderno orienta conferir o cuff pelo método, atribuição e faixa adotados no setor. Confirme com o enfermeiro quem realiza a verificação e como ela é registrada. Esta tela não estabelece uma faixa de pressão nem ensina a ajustar o balonete.",scope:"Verificação e ajuste dependem de atribuição, capacitação e protocolo."},{id:"secrecoes-e-aspiracao",title:"Secreções e necessidade de aspiração",detail:"Secreções, sinais de obstrução e piora ventilatória precisam de avaliação. Comunique prontamente o enfermeiro e auxilie no preparo do material e da monitorização conforme orientação. Segundo o resumo do caderno e a resolução nele citada, na equipe de enfermagem a aspiração de pacientes graves com TOT/TQT é privativa do enfermeiro. No estágio, acompanhe e auxilie sob orientação.",scope:"O estudante não executa aspiração de paciente grave com base nesta tela."},{id:"necessidade-de-ventilacao",title:"Reavaliação diária da necessidade de ventilação",detail:"A apostila descreve a avaliação diária da necessidade de ventilação pela equipe. Compartilhe com o enfermeiro as mudanças observadas e acompanhe o plano de cuidado. Decisões sobre desmame, extubação e sedação cabem à equipe habilitada; não altere parâmetros nem suspenda sedação por iniciativa própria.",scope:"Avaliação e decisões da equipe responsável, com metas individualizadas."},{id:"conferencia-e-registro",title:"Conferência conjunta, registro e comunicação",detail:"Conheça o checklist do bundle adotado pelo serviço e confira as medidas com a equipe. Registre os cuidados realmente realizados, os achados e a comunicação no sistema autorizado, conforme o padrão local. Comunique quando uma medida indicada não puder ser cumprida e esclareça a orientação para aquela situação.",scope:"Registro assistencial somente no sistema autorizado; não informe dados de pacientes no app."}],ro=[{id:"caderno-pav",label:"Caderno CTI Adulto — PAV e secreções, página 9.",href:"/materiais/caderno-cti-adulto-digital.pdf#page=9"},{id:"apostila-pav",label:"Apostila Cuidados com o Paciente Crítico — prevenção de pneumonia associada à VM, página 4.",href:"/materiais/apostilas/cuidados-paciente-critico.pdf#page=4"},{id:"caderno-registro",label:"Caderno CTI Adulto — anotação de enfermagem, página 38.",href:"/materiais/caderno-cti-adulto-digital.pdf#page=38"},{id:"caderno-referencias-pav",label:"Caderno CTI Adulto — referências [14] e [17], página 43.",href:"/materiais/caderno-cti-adulto-digital.pdf#page=43"},{id:"anvisa-pav",label:"Anvisa — Protocolo de prevenção de PAV. Link da referência [14] do caderno.",href:"https://www.gov.br/anvisa/pt-br/assuntos/servicosdesaude/prevencao-e-controle-de-infeccao-e-resistencia-microbiana/prevencao-das-principais-iras/pneumonia-associada-a-ventilacao-mecanica/protocolo-4-prevencoo-de-pav-final.pdf"},{id:"cofen-aspiracao",label:"Cofen — Resolução 557/2017, aspiração de vias aéreas. Link da referência [17] do caderno.",href:"https://www.cofen.gov.br/resolucao-cofen-no-05572017/"}],Xo=["PAV bundle de PAV bundle PAV pacote conjunto medidas pneumonia associada ventilação mecânica prevenção",J.title,J.purpose,J.care,J.risk,...so.flatMap(a=>[a.title,a.detail,a.scope])].join(" "),ga={id:"acolher-familia",title:"Acolher também é cuidar",description:"Aprenda a acolher familiares e promover uma assistência humanizada e segura",label:"Família e humanização",topics:[]},Ke=[{id:"acolhimento",title:"Acolhimento familiar",description:"Apresentação, escuta, empatia, atribuições e privacidade."},{id:"visitante",title:"Como orientar o visitante",description:"Vínculo, conversa, higiene das mãos e participação segura."},{id:"falas",title:"O que dizer? O que evitar?",description:"Oito situações para consultar exemplos e seus limites."},{id:"simulador",title:"Simulador de comunicação",description:"Pratique oito situações fictícias e leia a explicação de cada alternativa."},{id:"material",title:"Material para entregar ao familiar",description:"Conheça, baixe ou imprima o folheto próprio para familiares."}],Na=[{id:"apresentar-se",title:"Apresente-se e ofereça ajuda",text:"Cumprimente o visitante de forma respeitosa, diga seu nome e sua função real e pergunte de que orientação ele precisa. Se estiver em estágio, apresente-se como estagiário e indique que atua com supervisão. Não se apresente como profissional de outra categoria.",example:"“Olá, meu nome é ___. Sou ___ aqui da CTI. Posso ajudar com alguma orientação?”",referenceIds:["etica-enfermagem","comunicacao-familiar"]},{id:"explicar-funcao",title:"Explique sua função e seus limites",text:"Explique em linguagem simples como pode ajudar no acolhimento e nos cuidados, de acordo com suas atribuições e a supervisão aplicável. Dúvidas sobre diagnóstico, tratamento ou prognóstico devem ser encaminhadas ao profissional responsável. Não antecipe informações que não recebeu autorização para comunicar.",example:"“Posso orientar sobre a visita e chamar a equipe responsável para conversar sobre essa dúvida clínica.”",referenceIds:["etica-enfermagem"]},{id:"escutar",title:"Escute antes de responder",text:"Dê espaço para o familiar falar, evite interrupções e palavras técnicas desnecessárias. Confira se compreendeu a preocupação e se sua orientação foi entendida. Respeite diferenças culturais, crenças, preferências e necessidades de comunicação, solicitando os recursos autorizados quando necessário.",example:"“Quero entender melhor o que está preocupando você. Pode me contar?”",referenceIds:["comunicacao-familiar","etica-enfermagem"]},{id:"acolher-ansiedade",title:"Acolha a ansiedade sem prometer resultados",text:"Reconheça que a internação pode trazer medo, choro e incerteza. Ofereça escuta e ajuda dentro de suas possibilidades, respeitando se a pessoa prefere silêncio ou companhia. Evite minimizar sentimentos, comparar situações ou garantir recuperação. Se houver necessidade, solicite apoio à equipe pelos canais do serviço.",example:"“Vejo que este momento está sendo difícil. Posso ficar aqui por um momento ou chamar alguém da equipe para ajudar?”",referenceIds:["comunicacao-familiar","etica-enfermagem"]},{id:"encaminhar-duvidas",title:"Encaminhe dúvidas clínicas com responsabilidade",text:"Ouça a pergunta e reconheça quando ela ultrapassa suas atribuições ou as informações que pode fornecer. Combine o encaminhamento ao enfermeiro ou ao profissional responsável, conforme a organização do setor. Não invente respostas, interpretações dos equipamentos, prazos ou garantias de melhora.",example:"“Entendo que você queira essa informação. Vou encaminhar sua pergunta ao profissional responsável, para que ela seja esclarecida adequadamente.”",referenceIds:["etica-enfermagem","comunicacao-familiar"]},{id:"preservar-privacidade",title:"Preserve privacidade e confidencialidade",text:"Confirme, pelos meios autorizados do serviço, quem pode receber informações. O parentesco, por si só, não dispensa a verificação da autorização e da vontade da pessoa assistida. Evite conversas sobre condições clínicas em corredores ou ao alcance de outros visitantes. Não mostre prontuários, telas ou imagens nem compartilhe dados por canais pessoais.",example:"“Para preservar a privacidade, vou confirmar com a equipe como podemos encaminhar essa conversa e quem está autorizado a receber as informações.”",referenceIds:["etica-enfermagem"]}],Sa=[{id:"paciente-sedado",title:"Paciente sedado",text:"Oriente que o familiar pode falar com calma, dizer quem é e compartilhar palavras de afeto, respeitando as condições clínicas, as preferências da pessoa e as orientações da equipe. A presença e a comunicação podem manter o vínculo mesmo quando não há resposta observável.",attention:"Não é possível afirmar, para cada pessoa sedada, que ela necessariamente ouve ou compreende tudo. Não prometa uma resposta. Antes de tocar ou realizar qualquer cuidado, peça orientação à equipe.",referenceIds:["comunicacao-familiar"]},{id:"assuntos-cotidiano",title:"Assuntos do cotidiano",text:"Sugira assuntos familiares e de interesse da pessoa, como lembranças agradáveis, acontecimentos cotidianos ou mensagens de afeto. Respeite suas preferências, sua vontade de conversar e a necessidade de descanso. Fale com a pessoa, sem presumir que ela não participa da conversa por estar sem resposta.",attention:"Evite discutir conflitos ou trazer notícias potencialmente perturbadoras sem orientação adequada. Se não souber o que dizer ou se perceber desconforto, peça apoio à equipe.",referenceIds:["comunicacao-familiar"]},{id:"higiene-maos",title:"Higienização das mãos",text:"Oriente a higiene das mãos antes e depois do contato com o paciente e conforme as indicações do serviço. Quando estiverem visivelmente sujas ou após usar o banheiro, utilize água e sabonete. A preparação alcoólica é utilizada quando indicada e as mãos não estão visivelmente sujas; friccione conforme a orientação recebida e aguarde secar.",attention:"Mostre onde e como higienizar as mãos. Peça à equipe orientação sobre precauções e EPIs aplicáveis à visita. O uso de luvas não substitui a higiene das mãos.",referenceIds:["higiene-maos"]},{id:"equipamentos-dispositivos",title:"Equipamentos e dispositivos",text:"Explique que monitores, bombas, ventiladores, sondas e cateteres fazem parte dos recursos de cuidado. O visitante não deve tocar nos controles, puxar, desconectar ou reposicionar dispositivos. Um alarme pode ter diferentes causas e precisa ser avaliado pela equipe.",attention:"Se algo parecer diferente ou um alarme tocar, chame a equipe. O familiar não deve silenciar alarmes, alterar ajustes ou tentar resolver o problema por conta própria.",referenceIds:["seguranca-visitante"]},{id:"participacao-segura",title:"Participação segura da família",text:"Convide o familiar a compartilhar com a equipe informações relevantes sobre hábitos, preferências, necessidades de comunicação e aspectos importantes para a pessoa. Valorize a vontade do próprio paciente quando ele puder expressá-la. A família pode fazer perguntas e comunicar o que percebe sem precisar interpretar sinais ou equipamentos.",attention:"Participar de cuidados diretos depende de autorização, orientação e supervisão, conforme a avaliação da equipe e as normas institucionais. Não convide o visitante a executar procedimentos ou manipular dispositivos com base apenas neste aplicativo.",referenceIds:["comunicacao-familiar","seguranca-visitante"]}],Re=[{id:"familiar-chorando",title:"Familiar chorando",recommended:"“Vejo que este momento está sendo difícil. Quer me contar o que está preocupando você? Posso ajudar a chamar a equipe.”",avoid:"“Não chore, isso não é motivo para tanto. Vai ficar tudo bem.”",explanation:"Acolher é reconhecer a emoção e oferecer escuta e ajuda, sem obrigar a pessoa a falar ou prometer recuperação. Minimizar o sofrimento pode dificultar a confiança e o diálogo.",referenceIds:["comunicacao-familiar","etica-enfermagem"]},{id:"pergunta-prognostico",title:"Pergunta sobre o prognóstico",recommended:"“Entendo sua preocupação com a recuperação. Essa conversa precisa ser feita pelo profissional responsável. Vou ajudar a encaminhar sua pergunta.”",avoid:"“Tenho certeza de que vai sair daqui logo; pode ficar tranquilo.”",explanation:"O acolhimento não autoriza prever a evolução ou garantir desfechos. Reconheça a dúvida, respeite as atribuições e encaminhe uma conversa adequada, sem prometer quando ela ocorrerá se isso não estiver combinado.",referenceIds:["etica-enfermagem","comunicacao-familiar"]},{id:"medo-equipamentos",title:"Medo dos equipamentos",recommended:"“Esses recursos ajudam a equipe a acompanhar e cuidar. Posso explicar de forma geral e chamar o responsável para suas dúvidas. Evite tocar nos controles e nas conexões.”",avoid:"“É só olhar os números: se estiverem verdes, está tudo normal.”",explanation:"A aparência da tela, a cor ou um valor isolado não permitem concluir como a pessoa está. Ofereça uma explicação simples da finalidade e uma forma de pedir ajuda, sem interpretar o quadro clínico.",referenceIds:["seguranca-visitante","comunicacao-familiar"]},{id:"sedado-consegue-ouvir",title:"A pessoa sedada consegue ouvir?",recommended:"“Não posso garantir o que ela está ouvindo ou compreendendo. Se a equipe orientar, você pode falar com calma, dizer quem é e compartilhar palavras de carinho, sem esperar uma resposta.”",avoid:"“Ela ouve e entende tudo, mesmo sem responder.”",explanation:"Ausência de resposta não permite assegurar nem excluir a percepção. Apoie o vínculo de forma respeitosa e compatível com as condições clínicas, sem transformar uma possibilidade em certeza.",referenceIds:["comunicacao-familiar"]},{id:"monitor-alarme",title:"Monitor apresentando alarme",recommended:"“Vou chamar a equipe para avaliar. Por favor, não toque no aparelho nem tente desligar o alarme.”",avoid:"“Isso é normal. Pode apertar esse botão para parar o barulho.”",explanation:"Alarmes exigem atenção e podem ter diferentes causas. O familiar deve chamar a equipe; o profissional age conforme sua competência, supervisão e fluxo local, sem minimizar o alarme ou delegar ajustes ao visitante.",referenceIds:["seguranca-visitante","etica-enfermagem"]},{id:"nao-sabe-conversar",title:"Não sabe como conversar com o paciente",recommended:"“Você pode dizer que está aqui e falar de assuntos de que ele gosta, respeitando sua vontade e o descanso. Não precisa encontrar palavras perfeitas. Se tiver dúvida, podemos pedir orientação à equipe.”",avoid:"“Precisa conversar o tempo todo para ele melhorar.”",explanation:"Apoie uma presença possível e respeitosa, sem impor tempo de conversa ou responsabilizar o familiar pela recuperação. Preferências, descanso e orientações da equipe devem orientar a visita.",referenceIds:["comunicacao-familiar"]},{id:"quer-manipular-dispositivo",title:"Quer manipular um dispositivo",recommended:"“Não mexa nessa sonda ou conexão. Vou chamar a equipe para verificar. Sua ajuda pode ser avisar o que você percebeu.”",avoid:"“Pode ajeitar ou reconectar; é só encaixar novamente.”",explanation:"Manipular ou reconectar dispositivos pode causar dano e não deve ser delegado ao visitante. Intervenções precisam de avaliação e atuação da equipe habilitada, conforme as atribuições e o protocolo aplicável.",referenceIds:["seguranca-visitante","etica-enfermagem"]},{id:"informacao-fora-competencia",title:"Pede informações fora da sua competência",recommended:"“Essa informação precisa ser confirmada pelo responsável. Vou encaminhar sua dúvida e respeitar a privacidade da pessoa.”",avoid:"“Vou dar uma olhada no prontuário e contar minha interpretação para você.”",explanation:"Não especule sobre informações clínicas, mostre prontuários ou ultrapasse suas atribuições. Confirme a autorização para compartilhar informações e encaminhe a pergunta pelos canais do serviço.",referenceIds:["etica-enfermagem"]}],be=[{id:"escutar-sem-promessas",title:"Quando o familiar chora",situation:"Situação fictícia: durante a visita, uma pessoa começa a chorar e diz que tem medo de perder seu familiar. Ela não fez uma pergunta clínica específica.",question:"Qual resposta favorece o acolhimento?",options:[{text:"Reconhecer o sofrimento, oferecer escuta e perguntar se ela deseja apoio da equipe.",feedback:"A resposta acolhe a emoção e oferece ajuda sem exigir que a pessoa pare de chorar ou prometer um resultado clínico."},{text:"Dizer que ela precisa ser forte e parar de chorar para não atrapalhar a recuperação.",feedback:"Essa fala minimiza o sofrimento e atribui ao familiar uma responsabilidade indevida pela recuperação. Reconheça a emoção e ofereça apoio."},{text:"Garantir que tudo ficará bem para tranquilizá-la rapidamente.",feedback:"Uma promessa de recuperação não pode ser sustentada por esta situação. Acolha a preocupação sem garantir um desfecho."}],answer:0,explanation:"Escutar, respeitar o tempo da pessoa e oferecer ajuda são ações educativas de acolhimento. A necessidade de apoio adicional e a forma de acioná-lo dependem da equipe e da organização local.",referenceIds:["comunicacao-familiar","etica-enfermagem"]},{id:"encaminhar-prognostico",title:"Uma pergunta sobre a recuperação",situation:"Situação fictícia: um visitante pergunta ao estagiário se a pessoa internada vai se recuperar e em quantos dias poderá ir para casa. O cenário não fornece avaliação ou previsão da equipe.",question:"Como responder dentro dos limites de sua atuação?",options:[{text:"Usar o aspecto do monitor para estimar uma data de alta.",feedback:"A tela do equipamento não permite prever recuperação ou alta. Não faça estimativas nem interpretações clínicas com base nesta situação."},{text:"Responder que não sabe e encerrar a conversa sem encaminhamento.",feedback:"Reconhecer o limite é necessário, mas o acolhimento pode incluir uma forma de encaminhar a dúvida ao profissional responsável."},{text:"Reconhecer a preocupação e ajudar a encaminhar a pergunta ao profissional responsável.",feedback:"Essa resposta acolhe a dúvida sem inventar prazos ou prognóstico, respeitando as atribuições e o fluxo autorizado de comunicação."}],answer:2,explanation:"Acolher e encaminhar não exige adivinhar uma resposta. Informações sobre evolução, tratamento e prognóstico precisam ser comunicadas pelo responsável, com respeito à privacidade e à autorização aplicável.",referenceIds:["etica-enfermagem","comunicacao-familiar"]},{id:"explicar-equipamentos",title:"Receio diante dos equipamentos",situation:"Situação fictícia: um visitante diz que está assustado com as telas e os aparelhos ao lado do leito. Ele quer entender por que estão ali, sem pedir um diagnóstico.",question:"Qual abordagem educativa é mais adequada?",options:[{text:"Ensinar a identificar a gravidade pela cor dos números na tela.",feedback:"Cor ou número isolado não definem a condição clínica. Essa explicação pode criar falsa segurança e levar a interpretações inadequadas."},{text:"Explicar a finalidade geral dos recursos e orientar a chamar a equipe, sem tocar nos controles.",feedback:"Uma explicação simples pode reduzir dúvidas sem atribuir ao visitante a interpretação ou o manejo dos equipamentos."},{text:"Pedir que ele observe e ajuste os aparelhos para ajudar quando a equipe estiver ocupada.",feedback:"O visitante não deve ajustar equipamentos. A avaliação e o manejo precisam ser feitos pela equipe habilitada conforme suas atribuições."}],answer:1,explanation:"Explique somente o que cabe à sua função e ao que foi autorizado. Convide o visitante a comunicar dúvidas e observações, sem deduzir diagnóstico, prognóstico ou segurança pelos aparelhos.",referenceIds:["seguranca-visitante","comunicacao-familiar"]},{id:"conversar-sem-certezas",title:"Conversar com a pessoa sedada",situation:"Situação fictícia: um familiar pergunta se a pessoa sedada consegue ouvi-lo. Não há informação individual sobre nível de consciência, percepção ou compreensão.",question:"Que orientação respeita o vínculo e a incerteza?",options:[{text:"Explicar que não é possível garantir a percepção e orientar uma fala calma e respeitosa conforme a equipe.",feedback:"A resposta apoia a presença e a comunicação sem afirmar que a pessoa necessariamente ouve, compreende ou responderá."},{text:"Afirmar que toda pessoa sedada entende tudo o que é dito.",feedback:"O cenário não permite essa certeza. Sedação e ausência de resposta não autorizam garantir audição ou compreensão individual."},{text:"Dizer que conversar é inútil enquanto não houver resposta.",feedback:"Ausência de resposta não permite concluir que a comunicação não tem lugar. Apoie o vínculo sem garantir ou excluir percepção."}],answer:0,explanation:"Uma comunicação cuidadosa evita certezas não sustentadas. O familiar pode se apresentar e usar palavras de afeto, respeitando preferências, condições clínicas e orientação da equipe.",referenceIds:["comunicacao-familiar"]},{id:"alarme-e-ajuda",title:"Um alarme durante a visita",situation:"Situação fictícia: o monitor começa a emitir um alarme. O visitante aponta para um botão e pergunta se pode apertá-lo para interromper o som. A causa do alarme não foi avaliada.",question:"Qual resposta deve orientar a comunicação com o visitante?",options:[{text:"Autorizar o visitante a apertar o botão enquanto procura alguém.",feedback:"O visitante não deve silenciar ou ajustar equipamentos. Isso pode atrasar a avaliação do alarme pela equipe."},{text:"Dizer que alarmes são sempre normais e que ele pode ignorar.",feedback:"O alarme pode ter diferentes causas e ainda não foi avaliado. Não minimize a situação nem garanta ausência de problema."},{text:"Pedir que não toque no aparelho e acionar a equipe para avaliar conforme o fluxo do setor.",feedback:"A resposta orienta uma ação segura ao visitante e encaminha a avaliação à equipe, sem interpretar a causa ou ensinar ajustes."}],answer:2,explanation:"O profissional participa conforme suas atribuições, supervisão e fluxo local. O familiar contribui chamando a equipe e descrevendo o que percebeu; não deve tentar corrigir ou silenciar alarmes.",referenceIds:["seguranca-visitante","etica-enfermagem"]},{id:"apoio-para-conversar",title:"“Não sei o que dizer”",situation:"Situação fictícia: durante a visita, um familiar diz que não sabe como conversar e teme falar algo inadequado. O cenário não informa uma restrição específica à comunicação.",question:"Qual sugestão evita pressão e respeita a pessoa?",options:[{text:"Exigir que ele converse sem parar para estimular a recuperação.",feedback:"Não há indicação de que conversar continuamente seja necessário. Evite impor uma tarefa ou responsabilizar o familiar pela evolução."},{text:"Sugerir palavras simples de presença ou assuntos de interesse, respeitando descanso e orientações da equipe.",feedback:"A sugestão acolhe a dúvida e oferece possibilidades sem impor uma forma única de presença ou prometer benefício clínico."},{text:"Orientar a discutir conflitos familiares para fazer a pessoa reagir.",feedback:"Conversas potencialmente perturbadoras não devem ser usadas para provocar reações. Respeite preferências e peça orientação quando houver dúvida."}],answer:1,explanation:"Presença, fala e silêncio podem ser respeitados conforme a vontade da pessoa e as condições da visita. A equipe pode ajudar a adequar a comunicação sem criar obrigações ou garantias.",referenceIds:["comunicacao-familiar"]},{id:"dispositivo-sem-manipulacao",title:"Uma conexão parece fora do lugar",situation:"Situação fictícia: um visitante percebe algo diferente em uma conexão e se oferece para encaixá-la. O tipo de dispositivo e a causa da alteração não foram identificados.",question:"Qual orientação é segura nesta situação?",options:[{text:"Pedir que não manipule a conexão e chamar a equipe para verificar.",feedback:"A resposta evita uma intervenção sem avaliação. O visitante pode comunicar a observação enquanto a equipe assume a verificação."},{text:"Ensinar rapidamente como reconectar, pois o familiar está disposto a ajudar.",feedback:"Disposição para ajudar não substitui avaliação, atribuição ou capacitação. Não delegue reconexões e ajustes de dispositivos ao visitante."},{text:"Pedir uma foto para avaliar depois, antes de chamar a equipe.",feedback:"O cenário pede avaliação da equipe, sem adiar a ajuda ou registrar imagens de pacientes e dispositivos para canais pessoais."}],answer:0,explanation:"Nenhuma técnica de reconexão é indicada por este exercício. O cuidado direto depende da equipe habilitada e dos protocolos aplicáveis; a parceria do familiar inclui observar e pedir ajuda.",referenceIds:["seguranca-visitante","etica-enfermagem"]},{id:"limites-e-confidencialidade",title:"Uma dúvida clínica fora da sua atuação",situation:"Situação fictícia: um visitante pede ao técnico ou estagiário uma interpretação de resultados que não foram apresentados pela equipe. Não foi confirmada sua autorização para receber informações.",question:"Como acolher a solicitação preservando limites e privacidade?",options:[{text:"Mostrar a tela do prontuário para que o visitante faça sua própria interpretação.",feedback:"Mostrar prontuários ou telas sem autorização compromete a confidencialidade. Também não substitui uma explicação do profissional responsável."},{text:"Dar uma interpretação pessoal, pois se trata de um familiar interessado.",feedback:"O parentesco não dispensa a confirmação de autorização e uma opinião pessoal não substitui a comunicação profissional dentro das atribuições."},{text:"Reconhecer a dúvida, confirmar o encaminhamento autorizado e chamar o responsável para esclarecê-la.",feedback:"A resposta oferece ajuda sem divulgar dados indevidamente, inventar interpretação ou ultrapassar a competência de quem acolhe."}],answer:2,explanation:"Acolhimento inclui proteger a vontade e a privacidade da pessoa assistida. A equipe deve verificar quem está autorizado e organizar o esclarecimento conforme as atribuições profissionais.",referenceIds:["etica-enfermagem","comunicacao-familiar"]}],sa={unit:"CTI Cardio",reportedRule:"Um visitante por vez",note:"Informação local relatada pelo responsável pelo projeto, ainda sujeita à confirmação institucional. Não é regra universal da CTI nem autorização de visita. Confirme com a equipe as orientações vigentes, exceções e formas de acolhimento; este aplicativo não substitui essa confirmação."},Be=[{id:"etica-enfermagem",title:"Cofen — Resolução nº 564/2017, Código de Ética dos Profissionais de Enfermagem",href:"https://www.cofen.gov.br/resolucao-cofen-no-5642017/",scope:"Referência normativa proposta para discussão de atribuições, sigilo e privacidade. A equipe revisora deve conferir o texto, sua vigência e a adequação das orientações ao contexto.",lastAccessedAt:null,note:"O acesso externo foi bloqueado com HTTP 403 nesta execução; o texto não foi lido ou conferido aqui. O vínculo não comprova revisão clínica, vigência normativa confirmada ou aprovação institucional do módulo."},{id:"comunicacao-familiar",title:"NHS — Intensive care",href:"https://www.nhs.uk/conditions/intensive-care/",scope:"Leitura geral proposta sobre cuidados intensivos e orientação às famílias. A equipe precisa conferir a pertinência ao público brasileiro e ao módulo; esta indicação não sustenta uma garantia sobre audição ou compreensão durante sedação.",lastAccessedAt:null,note:"O acesso externo foi bloqueado com HTTP 403 nesta execução; a página não foi lida ou conferida aqui. Trata-se de leitura proposta, sem atribuir à fonte apoio textual verificado a cada frase ou validação clínica e institucional."},{id:"higiene-maos",title:"OMS — Hand hygiene",href:"https://www.who.int/teams/integrated-health-services/infection-prevention-control/hand-hygiene",scope:"Portal e materiais educativos propostos para conferência das indicações de higiene das mãos. Não substituem a seleção de uma referência específica, a revisão das orientações ao visitante ou os protocolos aplicáveis.",lastAccessedAt:null,note:"O acesso externo foi bloqueado com HTTP 403 nesta execução; o portal não foi lido ou conferido aqui. A existência do link não valida cada frase nem representa revisão clínica ou aprovação institucional do material."},{id:"seguranca-visitante",title:"Conhecendo a CTI — Equipamentos hospitalares",href:"#equipamentos",scope:"Origem educativa reaproveitada do módulo existente e do pedido do responsável: finalidade geral de equipamentos, comunicação de alarmes e prevenção de manipulação indevida. Os materiais relacionados permanecem na biblioteca do projeto.",lastAccessedAt:null,note:"Leitura educativa do próprio projeto, com revisão profissional e de referências pendente. Não é protocolo institucional aprovado nem comprovação de vigência. As orientações específicas ao visitante exigem validação pela equipe responsável."}];[ga.title,ga.description,"A família faz parte do cuidado",...Ke.flatMap(a=>[a.title,a.description]),...Na.flatMap(a=>[a.title,a.text,a.example]),...Sa.flatMap(a=>[a.title,a.text,a.attention]),...Re.flatMap(a=>[a.title,a.recommended,a.avoid,a.explanation]),...be.flatMap(a=>[a.title,a.situation,a.question,a.explanation,...a.options.flatMap(o=>[o.text,o.feedback])])].join(" ");const M=(a,o,s,n)=>({title:a,purpose:o,care:s,risk:n}),k=[{id:"acolhimento",title:"Bem-vindo à CTI",description:"Seu primeiro passo na terapia intensiva: pessoas, cuidado e acolhimento.",label:"Comece por aqui",topics:[M("O que é uma CTI?","O Centro de Terapia Intensiva reúne equipe especializada e recursos para monitorar e cuidar de pessoas com condições graves ou risco de deterioração.","Conheça o setor com seu preceptor e identifique os canais de comunicação. O cuidado considera a pessoa e sua família, além da condição clínica.","A gravidade e a necessidade de suporte variam. Não deduza um diagnóstico pelos equipamentos presentes."),M("Equipe multiprofissional","Enfermagem, medicina, fisioterapia, nutrição, farmácia e outras áreas compartilham o cuidado, conforme a organização do serviço.","Identifique seu enfermeiro supervisor e preceptor. O técnico participa dos cuidados dentro de sua competência e sob orientação e supervisão do enfermeiro.","Não execute procedimentos que não domina ou para os quais não recebeu autorização e supervisão."),M("Ética, sigilo e humanização","Preservar dignidade, privacidade e confidencialidade faz parte de todo cuidado.","Apresente-se, explique o cuidado e respeite a intimidade. Utilize apenas os canais autorizados para compartilhar informações assistenciais.","Não fotografe pacientes, prontuários ou telas. Não compartilhe casos identificáveis em redes sociais."),M("Segurança e primeiro dia","A integração começa com a identificação do paciente, a higiene das mãos e a comunicação segura.","Confirme identificação conforme protocolo; conheça higiene das mãos, EPIs, fluxo de emergência, descarte de resíduos e precauções com seu preceptor.","Se houver dúvida, interrompa a atividade de forma segura e peça orientação antes de continuar.")]},{id:"rotinas",title:"Rotinas da CTI",description:"Entenda a organização do cuidado ao longo do plantão.",label:"Dia a dia",topics:[M("Recebimento e passagem de plantão","Dar continuidade ao cuidado com informações claras sobre condições, dispositivos, pendências e riscos.","Use o instrumento institucional, confirme dúvidas e comunique mudanças ao enfermeiro. Preserve o sigilo.","Omissões e informações presumidas podem comprometer a continuidade do cuidado."),M("Sinais vitais e glicemia capilar","Observar tendências e registrar medições realizadas com técnica e equipamentos adequados.","Confirme identificação e indicação, siga o procedimento local, registre horário e resultado e comunique alterações ao enfermeiro.","Não interprete números isolados nem ajuste tratamento por conta própria."),M("Higiene, conforto e mobilização","Promover conforto e preservar a integridade da pele.","Planeje higiene e mudança de decúbito com a equipe conforme avaliação individual, tolerância, dispositivos e plano de cuidados. Observe a pele e comunique lesões.","Evite tração de dispositivos e mobilização sem apoio. Não aplique intervalos universais de reposicionamento."),M("Administração segura de medicamentos","Executar os cuidados prescritos dentro da competência profissional e com a supervisão aplicável.","Confira prescrição, identificação, alergias e verificações institucionais. Esclareça dúvidas com o enfermeiro antes de administrar e registre o realizado.","Este guia não fornece doses ou diluições. Não altere prescrição, velocidade ou programação por iniciativa própria."),M("Balanço hídrico e dispositivos","Acompanhar entradas, saídas e condições dos dispositivos conforme o plano de cuidados.","Meça e registre volumes e horários com os instrumentos previstos. Observe inserções, fixações e conexões sem manipulação desnecessária.","Não estime volumes como se fossem medidos. Comunique desconexões, perdas, obstruções e alterações."),M("Alterações clínicas e registros","Reconhecer mudanças e comunicar prontamente à equipe responsável.","Acione o fluxo de emergência quando necessário, comunique ao enfermeiro e registre achados objetivos, ações realizadas e a comunicação.","Não espere finalizar um registro para solicitar ajuda em uma situação urgente."),J]},{id:"equipamentos",title:"Equipamentos hospitalares",description:"Conheça os recursos que fazem parte do cuidado intensivo.",label:"Explore os equipamentos",topics:[M("Monitor multiparamétrico","Exibe sinais e tendências a partir de sensores, cabos, manguito e tela.","Observe o paciente, integridade dos sensores e qualidade do sinal; comunique alarmes e mudanças ao enfermeiro.","Artefatos podem distorcer leituras. Não silencie alarmes de forma permanente nem ajuste limites sem orientação."),M("Ventilador mecânico","Oferece suporte ventilatório por meio de circuito, interface e sistema de controle e alarmes.","Observe o paciente, conexões e fixação conforme orientação. Avise imediatamente diante de desconexão, alarme ou desconforto.","Não modifique parâmetros ventilatórios por iniciativa própria. A atuação requer treinamento e supervisão."),M("Bomba de infusão","Controla a administração de soluções por equipo e sistema programável.","Verifique identificação da solução e do paciente, prescrição, linha e alarmes com a equipe responsável.","Erros de programação, incompatibilidades e oclusões podem causar dano. Não ajuste a taxa sem prescrição e orientação."),M("Bomba de seringa","Administra soluções por um mecanismo que movimenta o êmbolo de uma seringa compatível.","Confirme seringa, identificação, conexão e programação conforme prescrição e procedimento institucional.","Trocas e manipulação de linhas exigem capacitação. Não use este material como instrução operacional."),M("Aspirador","Sistema de vácuo, frasco coletor e conexões para remoção de secreções quando indicada.","Conheça montagem, EPIs e descarte com seu preceptor. A aspiração em pacientes graves possui regras de competência e supervisão.","Não execute aspiração sem indicação, capacitação e verificação das atribuições profissionais."),M("Oxigenoterapia","Interfaces, fluxômetro e fonte de oxigênio permitem fornecer oxigênio conforme prescrição.","Confira interface, conexões, pele e prescrição. Comunique desconforto e alterações à equipe.","Oxigênio é uma terapia: não defina fluxos ou metas por conta própria. Mantenha fontes de ignição afastadas."),M("Cânula nasal de alto fluxo","Sistema com cânula, circuito e aquecimento/umidificação para suporte respiratório.","Observe conforto, pele, conexões e alarmes. Solicite avaliação da equipe diante de piora ou falha.","Não altere fluxo, temperatura ou concentração de oxigênio sem orientação profissional responsável."),M("Terapia renal substitutiva","Equipamentos com circuito extracorpóreo e filtro para suporte à função renal em situações indicadas.","Reconheça o equipamento, proteja as linhas durante os cuidados e comunique alarmes à equipe habilitada.","Não manipule o circuito, acessos ou parâmetros sem atribuição e capacitação específicas.")]},{id:"escalas",title:"Escalas clínicas",description:"Dor: EVA, BPS e PAINAD. Agitação e sedação: RASS. Consciência: Glasgow.",label:"Avaliação orientada",topics:[M("EVA — Escala Visual Analógica","Instrumento de autorrelato de intensidade da dor, usualmente uma linha contínua entre ausência de dor e a pior dor imaginável.","A pessoa precisa compreender e conseguir indicar sua experiência. Use o instrumento validado adotado pelo serviço.","Não confunda automaticamente EVA com escala numérica. Não atribua dor com base apenas na aparência."),M("BPS — Behavioral Pain Scale","Avalia comportamentos relacionados à dor em contextos para os quais foi validada, incluindo pacientes sob ventilação mecânica.","Considera expressão facial, membros superiores e adaptação ao ventilador. Consulte a versão validada e o treinamento institucional.","Não substitui o autorrelato quando ele é possível. O protótipo não calcula pontuação."),M("PAINAD","Instrumento observacional de dor desenvolvido para pessoas com demência avançada.","Considera respiração, vocalização negativa, expressão facial, linguagem corporal e consolabilidade. Confirme a pertinência com o enfermeiro.","Não aplique automaticamente a todo paciente que não fala. Use a versão validada, sem improvisar critérios."),M("RASS","Organiza a avaliação do nível de agitação e sedação por observação e resposta a estímulos padronizados.","A aplicação requer sequência e critérios do instrumento validado e treinamento da equipe.","Uma classificação não autoriza ajuste de sedativos pelo estudante. Este protótipo não oferece calculadora."),M("Escala de Coma de Glasgow","Avalia respostas ocular, verbal e motora com critérios padronizados.","Registre os componentes e fatores que impedem a avaliação, como limitações à resposta verbal. Utilize o instrumento oficial e orientação profissional.","Não invente pontuações para respostas não testáveis. Confundidores precisam ser documentados.")]},{id:"dispositivos",title:"Dispositivos",description:"Identificação, finalidade e atenção à segurança.",label:"Cuidado seguro",topics:[M("Cateter venoso central (CVC)","Acesso venoso central utilizado conforme indicação clínica.","Confirme identificação da linha, observe curativo e inserção e comunique dor, secreção, sangramento ou desconexão.","Risco de infecção e eventos mecânicos. Não manipule ou troque conexões fora do protocolo e da sua competência."),M("PICC","Cateter central inserido por uma veia periférica.","Identifique o dispositivo, preserve fixação e curativo e siga as restrições e cuidados prescritos.","Não force infusão em caso de resistência e não manipule sem capacitação. Comunique alterações."),M("Sonda vesical de demora","Drena urina por um sistema de coleta fechado quando indicada.","Observe fixação, fluxo e integridade do sistema. Mantenha a bolsa na posição orientada pelo protocolo e registre o volume medido.","Desconexão e manipulação desnecessária elevam o risco de infecção. Comunique ausência de drenagem e desconforto."),M("Sonda nasoenteral","Permite acesso enteral conforme indicação e confirmação de posicionamento pelo processo institucional.","Confira identificação, fixação e liberação para uso. Siga prescrição e orientações de higiene e administração.","Não infunda dieta ou medicamentos diante de dúvida sobre posição ou liberação. Comunique deslocamento e desconforto."),M("Tubo orotraqueal","Dispositivo de via aérea que pode se conectar ao suporte ventilatório.","Observe fixação e conexões durante higiene e mobilização com a equipe. Comunique deslocamento ou falha imediatamente.","Tração e desconexão são riscos graves. Não reposicione o tubo ou manipule o balonete sem atribuição e orientação."),M("Traqueostomia","Via aérea estabelecida por abertura na traqueia e cânula.","Identifique a cânula, observe pele, fixação e secreções e siga o plano de cuidados com supervisão.","Obstrução e deslocamento exigem resposta imediata da equipe. Trocas de cânula não são ensinadas neste guia."),M("Cateteres de oxigenoterapia","Interfaces para fornecimento de oxigênio, incluindo cânulas e máscaras.","Confira a interface prescrita, observe pontos de pressão e comunique desconforto ou desconexão.","Não altere terapia por iniciativa própria; diferentes interfaces têm indicações e limitações distintas.")]},{id:"registros",title:"Anotações de enfermagem",description:"Aprenda com exemplos fictícios, objetivos e contextualizados.",label:"Comunicação que cuida",topics:[M("Sinais vitais e glicemia","Adequado: “No horário registrado, sinais vitais e glicemia aferidos; resultados lançados nos campos próprios. Alteração observada comunicada ao enfermeiro responsável.”","Na prática, registre os valores realmente medidos, horário, achados e a identificação de quem recebeu a comunicação. Este exemplo não é um registro completo.","Inadequado: “Tudo normal.” É vago, não informa medições ou observações e não permite rastrear o cuidado."),M("Medicamentos","Adequado: registrar medicamento efetivamente administrado, dose, via e horário conforme prescrição, além de intercorrências e ações realizadas.","Utilize dados reais da assistência no prontuário autorizado e o padrão institucional de checagem. Não copie modelos sem adequação.","Inadequado: “Medicado conforme rotina.” Omite informações essenciais e pode ocultar omissões. Não cheque antes de administrar."),M("Higiene, conforto e mobilização","Adequado: “Higiene realizada com apoio da equipe; pele observada durante o cuidado; posição ajustada conforme plano. Paciente relata maior conforto.”","Descreva local e características de achados, tolerância e medidas tomadas, quando presentes. Todos os exemplos são fictícios.","Inadequado: “Banho feito, sem problemas.” A expressão não descreve o cuidado nem a resposta observada."),M("Eliminações e balanço","Adequado: registrar tipo de eliminação, volume efetivamente medido, horário e características observadas nos campos próprios.","Identifique quando um volume não pôde ser medido, em vez de estimá-lo como medição.","Inadequado: “Diurese boa.” Não informa quantidade, período ou características."),M("Intercorrências e comunicação","Adequado: descrever achado objetivo, horário, profissional acionado, orientações recebidas e cuidados efetivamente executados.","Registre de maneira cronológica, clara e identificada, conforme as normas aplicáveis e o sistema institucional.","Inadequado: “Paciente complicado; equipe avisada.” Contém julgamento e não permite identificar evento, destinatário e conduta.")]},{id:"quiz",title:"Quiz interativo",description:"Pratique com situações fictícias e aprenda com cada resposta.",label:"Teste seus conhecimentos",topics:[]},{id:"biblioteca",title:"Biblioteca científica",description:"Cadernos, apostilas de estudo e fontes para aprofundar o aprendizado.",label:"Aprenda com fontes",topics:[]},ga],Wo=[{title:"Anvisa — Segurança do paciente",url:"https://www.gov.br/anvisa/pt-br/assuntos/servicosdesaude/seguranca-do-paciente",description:"Materiais oficiais e orientações sobre segurança na assistência."},{title:"Ministério da Saúde — Saúde de A a Z",url:"https://www.gov.br/saude/pt-br/assuntos/saude-de-a-a-z",description:"Portal de consulta a informações públicas de saúde."},{title:"Cofen — Legislação",url:"https://www.cofen.gov.br/categoria/legislacao/",description:"Consulte as normas vigentes sobre exercício profissional e registros."},{title:"Coren-RS",url:"https://www.portalcoren-rs.gov.br/",description:"Conselho regional: orientações sobre o exercício profissional."},{title:"Glasgow Coma Scale",url:"https://www.glasgowcomascale.org/",description:"Fonte do instrumento e recursos para avaliação estruturada."},{title:"Society of Critical Care Medicine",url:"https://www.sccm.org/",description:"Sociedade científica de cuidados intensivos; materiais em inglês."}],ra=[{subject:"Segurança",text:"Durante o cuidado, um monitor dispara um alarme. Qual é a atitude mais adequada ao estagiário?",options:["Desativar os alarmes para evitar ruídos.","Observar o paciente e solicitar avaliação da equipe responsável.","Alterar os limites até o alarme parar.","Aguardar a próxima passagem de plantão."],answer:1,explanation:"Alarmes exigem atenção ao paciente e comunicação à equipe. Não ajuste limites por iniciativa própria."},{subject:"Registros",text:"Qual anotação oferece melhor rastreabilidade?",options:["Paciente bem.","Plantão tranquilo.","Descrever achado, horário, profissional comunicado e ações realizadas.","Copiar a anotação anterior."],answer:2,explanation:"O registro deve ser objetivo, cronológico e refletir o cuidado realmente realizado."},{subject:"Ética",text:"Um colega pede uma foto do prontuário para estudar em casa. Como agir?",options:["Enviar se ocultar somente o nome.","Enviar em um grupo fechado.","Pedir que apague depois de estudar.","Não fotografar e buscar materiais educativos sem dados de pacientes."],answer:3,explanation:"O sigilo inclui informações que podem identificar o paciente de forma indireta. Utilize materiais educativos autorizados."},{subject:"Escalas",text:"Caso simulado: uma pessoa compreende instruções e consegue comunicar sua dor. Qual princípio orienta a avaliação?",options:["Valorizar o autorrelato e escolher um instrumento adequado.","Usar PAINAD em todos os pacientes.","Inferir ausência de dor porque não há choro.","Escolher uma pontuação pelo monitor."],answer:0,explanation:"Quando possível, o autorrelato orienta a avaliação da dor. A seleção e aplicação do instrumento exigem adequação e orientação."},{subject:"Escalas",text:"Caso simulado: a resposta verbal não pode ser testada por uma limitação. O que fazer ao avaliar Glasgow?",options:["Inventar um valor médio.","Usar o valor máximo automaticamente.","Documentar a limitação e seguir a orientação do instrumento e da equipe.","Ignorar a limitação no registro."],answer:2,explanation:"Componentes não testáveis e confundidores precisam ser documentados. Não se deve inventar pontuações."},{subject:"Dispositivos",text:"Há dúvida sobre a liberação de uma sonda para administrar dieta. Qual a conduta?",options:["Administrar uma pequena quantidade para testar.","Não iniciar; esclarecer a liberação com o enfermeiro.","Usar a sonda porque está fixada.","Perguntar a outro estudante e seguir."],answer:1,explanation:"Fixação não comprova liberação para uso. Esclareça a dúvida com o profissional responsável antes da administração."},{subject:"Equipamentos",text:"Um ventilador apresenta um alarme durante a mobilização. Qual ação é apropriada?",options:["Mudar os parâmetros ventilatórios.","Desligar o equipamento.","Observar o paciente e acionar imediatamente a equipe responsável.","Ignorar se a tela continuar ligada."],answer:2,explanation:"A avaliação da equipe é necessária. O estudante não deve ajustar parâmetros por iniciativa própria."},{subject:"Rotinas",text:"Um volume de eliminação não pôde ser medido. Como registrar?",options:["Inventar um valor aproximado e marcar como medido.","Repetir o volume anterior.","Omitir a eliminação.","Informar a ocorrência e que o volume não foi medido."],answer:3,explanation:"Registros devem representar o que foi observado e medido, sem transformar estimativas em dados objetivos."},...io];function Jo(a,o){return a.reduce((s,n,r)=>s+ +(n.answer===o[r]),0)}function no(){return e.jsxs("p",{children:["Abriu pelo WhatsApp? Use a opção ",e.jsx("strong",{children:"Abrir no navegador"}),". Se ela não aparecer, copie o link e cole no ",e.jsx("strong",{children:"Safari no iPhone"})," ou no ",e.jsx("strong",{children:"Chrome no Android"}),"."]})}function to(){return e.jsxs("p",{className:"pdf-open-help",children:["O PDF abre em outra aba ou no visualizador do aparelho. Para voltar, selecione a aba ",e.jsx("strong",{children:"Conhecendo a CTI"})," ou feche apenas a aba do PDF. Se abrir em outro aplicativo, volte pelo ícone ",e.jsx("strong",{children:"Conhecendo a CTI"})," ou pelo alternador de aplicativos. Não é preciso fechar o aplicativo inteiro."]})}function Zo(){return e.jsxs("details",{className:"pdf-help mobile-help",children:[e.jsx("summary",{children:"Como salvar o PDF no celular — iPhone e Android"}),e.jsxs("p",{children:[e.jsx("strong",{children:"Abrir PDF"})," abre o arquivo original no navegador ou no visualizador do celular. O link pede uma nova aba; alguns aparelhos podem baixar o documento. Use os controles do visualizador para ampliar a leitura."]}),e.jsx("h3",{children:"iPhone (iOS)"}),e.jsxs("ol",{children:[e.jsx("li",{children:"No Safari, use o gesto de ampliar com dois dedos para ler o PDF."}),e.jsxs("li",{children:["Para voltar ao aplicativo, toque no botão de ",e.jsx("strong",{children:"abas"})," do Safari e selecione a aba ",e.jsx("strong",{children:"Conhecendo a CTI"}),", ou feche apenas a aba do PDF."]}),e.jsxs("li",{children:["Se abriu o aplicativo pelo ícone na tela inicial e o PDF abriu no Safari, volte pelo ícone ",e.jsx("strong",{children:"Conhecendo a CTI"})," ou pelo alternador de aplicativos."]}),e.jsxs("li",{children:["Para salvar o PDF aberto, toque em ",e.jsx("strong",{children:"Compartilhar → Salvar em Arquivos"}),", escolha uma pasta e toque em ",e.jsx("strong",{children:"Salvar"}),". Depois, encontre o arquivo no aplicativo ",e.jsx("strong",{children:"Arquivos"}),"."]})]}),e.jsx("h3",{children:"Android"}),e.jsxs("ol",{children:[e.jsxs("li",{children:["No Chrome, o PDF pode abrir no próprio navegador ou em outro visualizador. Se ele for baixado, abra ",e.jsx("strong",{children:"Arquivos/Files → Downloads"})," e toque no documento."]}),e.jsx("li",{children:"Use os controles de zoom do visualizador ou o gesto de ampliar com dois dedos."}),e.jsxs("li",{children:["Para voltar, selecione a aba ",e.jsx("strong",{children:"Conhecendo a CTI"})," no Chrome ou feche apenas a aba do PDF. Se outro visualizador foi aberto, use ",e.jsx("strong",{children:"Voltar"})," do Android ou o alternador de aplicativos."]}),e.jsxs("li",{children:["Para guardar uma cópia, use ",e.jsx("strong",{children:"Baixar PDF"})," na Biblioteca ou o comando ",e.jsx("strong",{children:"Baixar/Salvar"})," do visualizador. Procure o arquivo em ",e.jsx("strong",{children:"Arquivos/Files → Downloads"}),"."]})]}),e.jsx("p",{children:"Os controles dentro do PDF pertencem ao navegador ou ao visualizador. A página do aplicativo continua disponível; não é necessário fechar o aplicativo inteiro para retornar."}),e.jsx(no,{}),e.jsxs("p",{children:[e.jsx("strong",{children:"Ler caderno"})," continua abrindo o livro dentro do aplicativo, com uma página por vez e deslize para os lados. ",e.jsx("strong",{children:"PDF original"})," abre o arquivo no navegador. ",e.jsx("strong",{children:"Baixar para imprimir"})," mantém o caderno de bolso separado."]})]})}function Yo(){return e.jsxs("div",{className:"mobile-help",children:[e.jsx("p",{children:"Adicione um ícone do aplicativo à tela inicial do seu celular para abrir o guia com mais facilidade."}),e.jsx("h3",{children:"iPhone (iOS)"}),e.jsxs("ol",{children:[e.jsxs("li",{children:["Abra o endereço do aplicativo no ",e.jsx("strong",{children:"Safari"}),"."]}),e.jsxs("li",{children:["Toque em ",e.jsx("strong",{children:"Compartilhar"})," (quadrado com uma seta para cima)."]}),e.jsxs("li",{children:["Escolha ",e.jsx("strong",{children:"Adicionar à Tela de Início"})," e confirme em ",e.jsx("strong",{children:"Adicionar"}),"."]})]}),e.jsx("h3",{children:"Android"}),e.jsxs("ol",{children:[e.jsxs("li",{children:["Abra o endereço do aplicativo no ",e.jsx("strong",{children:"Chrome"}),"."]}),e.jsxs("li",{children:["Toque no ",e.jsx("strong",{children:"menu ⋮"})," e procure ",e.jsx("strong",{children:"Adicionar à tela inicial"})," ou ",e.jsx("strong",{children:"Instalar aplicativo"}),"."]}),e.jsxs("li",{children:["Confirme em ",e.jsx("strong",{children:"Adicionar"})," ou ",e.jsx("strong",{children:"Instalar"}),", conforme a opção exibida."]})]}),e.jsx("p",{children:"Os nomes dos menus podem variar conforme o navegador e a versão do celular. Você também pode continuar usando o aplicativo pelo navegador."}),e.jsx(no,{})]})}const L=a=>({label:`Caderno CTI Adulto · página ${a}`,href:`/materiais/caderno-cti-adulto-digital.pdf#page=${a}`}),na=a=>({label:`Apostila Monitorização e equipamentos · página ${a}`,href:`/materiais/apostilas/monitorizacao-equipamentos.pdf#page=${a}`}),Xe=[{moduleId:"equipamentos",topicTitle:"Monitor multiparamétrico",kind:"monitor",description:"Tela e três acessórios ilustrativos de monitorização. Os acessórios disponíveis variam conforme o equipamento.",parts:[{name:"Tela do monitor",detail:"Apresenta sinais, curvas e alarmes; a ilustração não contém medições."},{name:"Eletrodos e cabos",detail:"Permitem captar o sinal elétrico para a monitorização cardíaca."},{name:"Sensor de oximetria",detail:"Sensor óptico relacionado à leitura da SpO₂."},{name:"Manguito",detail:"Acessório utilizado na medida não invasiva da pressão arterial."}],attention:"Observe o paciente e a qualidade do sinal. Movimento e acessórios mal posicionados podem alterar a leitura; comunique alarmes e mudanças ao enfermeiro.",source:na(4)},{moduleId:"equipamentos",topicTitle:"Ventilador mecânico",kind:"ventilator",description:"Unidade de controle, circuito e umidificação apresentados de forma simplificada, sem representar uma montagem.",parts:[{name:"Unidade de controle e tela",detail:"Reúne a apresentação de informações e dos alarmes do equipamento."},{name:"Circuito ventilatório",detail:"Conjunto de tubos do sistema de suporte ventilatório."},{name:"Sistema de umidificação",detail:"Pode integrar o suporte, conforme o equipamento e o plano de cuidado."}],attention:"Observe paciente, fixações e conexões com a equipe. Alarmes, desconexão e desconforto exigem avaliação; parâmetros não devem ser alterados por iniciativa do estudante.",source:na(11)},{moduleId:"equipamentos",topicTitle:"Bomba de infusão",kind:"infusion",description:"Bomba, recipiente de solução e equipo ilustrados como componentes para reconhecimento, sem indicar preparo ou conexão.",parts:[{name:"Recipiente da solução",detail:"A identificação deve corresponder à prescrição e à terapia administrada."},{name:"Bomba e tela",detail:"Sistema programável que controla a administração."},{name:"Equipo e linha",detail:"Precisam ser compatíveis e identificados; não se reconhece a terapia apenas pela posição da bomba."}],attention:"Compare identificação, prescrição e programação com a equipe. Comunique alarmes, interrupções e alterações do acesso, sem ajustar a taxa por iniciativa própria.",source:L(28)},{moduleId:"equipamentos",topicTitle:"Bomba de seringa",kind:"syringe",description:"Seringa e mecanismo de movimentação do êmbolo em uma representação externa simplificada.",parts:[{name:"Seringa compatível",detail:"A seringa e a solução devem corresponder ao equipamento e à prescrição."},{name:"Mecanismo de movimentação",detail:"Movimenta o êmbolo para controlar a administração."},{name:"Tela e identificação",detail:"Permitem conferir a programação com a prescrição, conforme o treinamento do serviço."}],attention:"Trocas, manipulação e programação exigem capacitação e supervisão. O desenho não ensina a instalar seringa nem ajustar uma infusão.",source:L(28)},{moduleId:"equipamentos",topicTitle:"Aspirador",kind:"suction",description:"Elementos do sistema de aspiração separados visualmente para reconhecimento; a disposição não é um guia de montagem.",parts:[{name:"Fonte de vácuo",detail:"Origem da sucção do sistema."},{name:"Frasco coletor",detail:"Recipiente destinado à coleta no sistema."},{name:"Extensão",detail:"Tubulação do conjunto, cuja integridade deve ser observada."},{name:"Filtro",detail:"Componente do sistema conforme o modelo de equipamento."}],attention:"Conheça o equipamento e os EPIs com o preceptor. Aspiração exige indicação, capacitação e respeito às atribuições profissionais.",source:na(11)},{moduleId:"equipamentos",topicTitle:"Oxigenoterapia",kind:"oxygen",description:"Fonte de oxigênio, fluxômetro e interface como elementos de reconhecimento; não representa ajuste ou montagem.",parts:[{name:"Fonte de oxigênio",detail:"Fornece o gás ao sistema prescrito."},{name:"Fluxômetro",detail:"Equipamento relacionado ao controle do fluxo, sem valores ou ajustes neste desenho."},{name:"Interface",detail:"Cânula ou máscara escolhida segundo a prescrição e o contexto clínico."}],attention:"Confira a interface prescrita e observe pele, conforto e conexões. Não defina fluxos ou metas por conta própria; mantenha fontes de ignição afastadas.",source:L(8)},{moduleId:"equipamentos",topicTitle:"Cânula nasal de alto fluxo",kind:"high-flow",description:"Cânula, circuito e unidade de aquecimento/umidificação apresentados esquematicamente, sem indicar conexões.",parts:[{name:"Cânula nasal",detail:"Interface que fica em contato com o nariz e exige observação da pele e do conforto."},{name:"Circuito",detail:"Tubulação do sistema de suporte respiratório."},{name:"Aquecimento e umidificação",detail:"Integram o sistema, conforme o equipamento utilizado."}],attention:"Comunique falhas, alarmes, desconforto ou piora. Fluxo, temperatura e concentração de oxigênio dependem da orientação do profissional responsável.",source:L(8)},{moduleId:"equipamentos",topicTitle:"Terapia renal substitutiva",kind:"renal",description:"Equipamento, filtro e linhas de um circuito extracorpóreo em uma visão geral sem representar acesso ao paciente.",parts:[{name:"Equipamento de terapia renal",detail:"Sistema utilizado para suporte à função renal em situações indicadas."},{name:"Filtro",detail:"Componente do circuito extracorpóreo."},{name:"Linhas do circuito",detail:"Precisam ser protegidas de tração durante os cuidados e a movimentação."}],attention:"A modalidade e o manejo são definidos pela equipe habilitada. Comunique alarmes e alterações; não manipule circuito, acesso ou parâmetros sem atribuição e capacitação.",source:L(24)},{moduleId:"dispositivos",topicTitle:"Cateter venoso central (CVC)",kind:"venous",description:"Somente a região externa de um cateter e seu curativo. A posição interna da ponta e a técnica de inserção não são representadas.",parts:[{name:"Extensões e conexões",detail:"As vias devem estar identificadas; número e aparência variam conforme o cateter."},{name:"Fixação",detail:"Ajuda a preservar a estabilidade do dispositivo e precisa ser observada durante o cuidado."},{name:"Curativo e região de inserção",detail:"Observe integridade, umidade, dor, secreção, sangramento ou deslocamento."}],attention:"Evite tração e desconexões desnecessárias. Alterações no sítio e resistência devem ser comunicadas; não manipule ou force a infusão.",source:L(22)},{moduleId:"dispositivos",topicTitle:"PICC",kind:"venous",description:"Representação apenas da região externa e do curativo. O PICC é um cateter central inserido por uma veia periférica; sua ponta interna não é mostrada.",parts:[{name:"Extensões e conexões",detail:"Observe a identificação da linha; número e aparência dependem do modelo."},{name:"Fixação",detail:"Deve ser preservada durante higiene, mobilização e demais cuidados."},{name:"Curativo e região de inserção",detail:"Observe integridade e sinais de alteração, sem manipulação desnecessária."}],attention:"O aspecto externo, sozinho, não confirma o tipo nem a posição de um cateter. Confira a identificação e comunique alterações; não force infusão diante de resistência.",source:L(22)},{moduleId:"dispositivos",topicTitle:"Sonda vesical de demora",kind:"urinary",description:"Segmento externo de drenagem e bolsa coletora. Não mostra anatomia, inserção ou manipulação do sistema.",parts:[{name:"Segmento externo e fixação",detail:"Observe a fixação para prevenir tração do dispositivo."},{name:"Tubo de drenagem",detail:"O sistema é fechado; observe dobras, compressões e fluxo."},{name:"Bolsa coletora",detail:"Permite acompanhar o volume e as características da urina no período registrado."}],attention:"Preserve o sistema fechado e a posição orientada pelo protocolo. Ausência de drenagem, vazamento, desconexão e desconforto exigem comunicação.",source:L(23)},{moduleId:"dispositivos",topicTitle:"Sonda nasoenteral",kind:"enteral",description:"Sonda em detalhe externo, sem mostrar trajeto anatômico ou técnica para verificar o posicionamento.",parts:[{name:"Conector da via enteral",detail:"A identificação deve permitir reconhecer a finalidade da sonda."},{name:"Segmento externo e marca",detail:"A mudança da marca externa precisa ser comunicada para avaliação."},{name:"Fixação",detail:"Observe integridade, pele e sinais de deslocamento durante os cuidados."}],attention:"Fixação ou aparência externa não confirmam posição nem liberação. Diante de dúvida ou suspeita de deslocamento, esclareça com o enfermeiro antes do uso.",source:L(25)},{moduleId:"dispositivos",topicTitle:"Tubo orotraqueal",kind:"tube",description:"Tubo e elementos externos em um desenho isolado. Não mostra profundidade, inserção ou técnica de manipulação.",parts:[{name:"Conector",detail:"Região do dispositivo que se relaciona ao circuito do suporte ventilatório."},{name:"Tubo",detail:"Dispositivo de via aérea cuja identificação e posição devem ser conferidas pela equipe."},{name:"Fixação externa",detail:"Deve ser protegida de tração durante higiene e mobilização."}],attention:"Comunique deslocamento, desconexão ou falha imediatamente. Não reposicione o tubo nem manipule o balonete sem atribuição e orientação.",source:L(8)},{moduleId:"dispositivos",topicTitle:"Traqueostomia",kind:"tracheostomy",description:"Vista isolada de uma cânula de traqueostomia e sua fixação, sem anatomia ou representação da técnica de troca.",parts:[{name:"Cânula",detail:"Componente da via aérea; modelos e características precisam ser confirmados pela identificação."},{name:"Flange",detail:"Parte externa de apoio da cânula, em contato com a região ao redor do estoma."},{name:"Fixação",detail:"Observe integridade, pele e estabilidade conforme o plano de cuidados."}],attention:"Deslocamento ou suspeita de obstrução exigem resposta imediata da equipe. O desenho não orienta troca de cânula ou procedimentos de via aérea.",source:L(8)},{moduleId:"dispositivos",topicTitle:"Cateteres de oxigenoterapia",kind:"interfaces",description:"Duas interfaces alternativas: cânula nasal e máscara. Estão separadas no desenho e não representam uma montagem conjunta.",parts:[{name:"Cânula nasal",detail:"Interface com prongas nasais; observe conforto e pontos de contato com a pele."},{name:"Máscara",detail:"Outra interface de oxigenoterapia, com indicações e limitações próprias."},{name:"Extensão",detail:"Tubulação da interface; observe integridade e conexões conforme orientação."}],attention:"Confira a interface prescrita e comunique desconforto ou desconexão. As interfaces não são intercambiáveis por iniciativa do estudante.",source:L(8)}],ei={acolhimento:{"O que é uma CTI?":"o-que-e-uma-cti","Equipe multiprofissional":"equipe-multiprofissional","Ética, sigilo e humanização":"etica-sigilo-e-humanizacao","Segurança e primeiro dia":"seguranca-e-primeiro-dia"},rotinas:{"Recebimento e passagem de plantão":"recebimento-e-passagem-de-plantao","Sinais vitais e glicemia capilar":"sinais-vitais-e-glicemia-capilar","Higiene, conforto e mobilização":"higiene-conforto-e-mobilizacao","Administração segura de medicamentos":"administracao-segura-de-medicamentos","Balanço hídrico e dispositivos":"balanco-hidrico-e-dispositivos","Alterações clínicas e registros":"alteracoes-clinicas-e-registros","Bundle de prevenção da PAV":"bundle-de-prevencao-da-pav"},equipamentos:{"Monitor multiparamétrico":"monitor-multiparametrico","Ventilador mecânico":"ventilador-mecanico","Bomba de infusão":"bomba-de-infusao","Bomba de seringa":"bomba-de-seringa",Aspirador:"aspirador",Oxigenoterapia:"oxigenoterapia","Cânula nasal de alto fluxo":"canula-nasal-de-alto-fluxo","Terapia renal substitutiva":"terapia-renal-substitutiva"},escalas:{"EVA — Escala Visual Analógica":"eva-escala-visual-analogica","BPS — Behavioral Pain Scale":"bps-behavioral-pain-scale",PAINAD:"painad",RASS:"rass","Escala de Coma de Glasgow":"escala-de-coma-de-glasgow"},dispositivos:{"Cateter venoso central (CVC)":"cateter-venoso-central-cvc",PICC:"picc","Sonda vesical de demora":"sonda-vesical-de-demora","Sonda nasoenteral":"sonda-nasoenteral","Tubo orotraqueal":"tubo-orotraqueal",Traqueostomia:"traqueostomia","Cateteres de oxigenoterapia":"cateteres-de-oxigenoterapia"},registros:{"Sinais vitais e glicemia":"sinais-vitais-e-glicemia",Medicamentos:"medicamentos","Higiene, conforto e mobilização":"higiene-conforto-e-mobilizacao","Eliminações e balanço":"eliminacoes-e-balanco","Intercorrências e comunicação":"intercorrencias-e-comunicacao"}},ve={eva:"EVA — Escala Visual Analógica",bps:"BPS — Behavioral Pain Scale",painad:"PAINAD",rass:"RASS"},ai=a=>a.normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"");function We(a,o){const s=ei[a];return s&&Object.hasOwn(s,o)?s[o]:ai(o)}function oi(a){return Object.hasOwn(ve,a)?ve[a]:void 0}function Je(a){return Object.keys(ve).find(o=>ve[o]===a)}function ii(a){return Object.keys(ve).find(o=>a===o||a===We("escalas",ve[o]))}function Fa(a,o,s){return s?s===We(a,o)||a==="escalas"&&s===Je(o):!1}const ae=[{id:"tool.perfil",title:"Meu perfil de aprendizagem",description:"Escolha estagiário ou novo colaborador e troque quando quiser, sem cadastro.",href:"#perfil",aliases:["perfil","estagiário","novo colaborador","acolhimento"]},{id:"tool.integracao",title:"Checklist de integração",description:"Roteiro educativo separado para novos colaboradores, com marcações locais e itens pendentes de validação institucional.",href:"#integracao",aliases:["integração","colaborador","primeiro plantão","ambientação","checklist"]},{id:"tool.laboratorio",title:"Laboratório de anotações",description:"Pratique registros com fatos fictícios, rubrica de autorrevisão e exemplos comentados.",href:"#laboratorio",aliases:["anotação","anotações","registro","escrita","rubrica","laboratório"]},{id:"tool.cti-virtual",title:"CTI virtual",description:"Explore equipamentos em um box fictício 2D, com lista acessível e explicações educativas.",href:"#cti-virtual",aliases:["box","virtual","equipamentos","desenhos","monitor","bomba","ventilador"]},{id:"tool.avaliacao-pbl",title:"Avaliação do PBL",description:"Questionário voluntário de usabilidade e aprendizagem percebida, sem envio remoto.",href:"#avaliacao-pbl",aliases:["feedback","avaliação","PBL","opinião","usabilidade"]},{id:"tool.demonstracao",title:"Demonstração guiada",description:"Percorra os dois perfis e os recursos do projeto usando somente situações fictícias.",href:"#demonstracao",aliases:["demonstração","apresentação","tour","institucional","roteiro"]},{id:"tool.conteudos",title:"Revisão dos conteúdos",description:"Consulte referências, versões editoriais e pendências de revisão dos materiais educativos.",href:"#conteudos",aliases:["revisão","referências","validação","fontes","catálogo","conteúdos"]}],si="1.0",ri="2026-10-27",ni="Bem-vindo à CTI — Sua presença também é cuidado",ti="Material educativo sujeito à validação institucional",di="Conhecendo a CTI",ci=[{number:1,title:"Bem-vindo à CTI",subtitle:"Sua presença também é cuidado",intro:"Orientações para uma visita acolhedora e segura.",message:"A família faz parte do cuidado. Conte com a equipe para orientar sua participação, respeitando as condições de cada pessoa."},{number:2,title:"Sua presença importa",intro:"Pequenos gestos podem ajudar a manter o vínculo com quem você ama.",blocks:[{title:"Converse com tranquilidade",text:"Apresente-se e fale com calma. Conte notícias da família e assuntos do cotidiano que sejam de interesse da pessoa. Respeite suas preferências."},{title:"Demonstre carinho",text:"Pergunte à equipe como se aproximar e se o toque é permitido naquele momento. Respeite o conforto, o descanso e as orientações recebidas."},{title:"Quando há sedação",text:"Você pode conversar e manter o vínculo, conforme orientação da equipe. Não é possível garantir que a pessoa ouça ou compreenda tudo."},{title:"Compartilhe o que importa",text:"Conte à equipe hábitos, preferências e necessidades. Cuidado direto só com autorização, orientação e supervisão da equipe."}]},{number:3,title:"Cuidados e segurança",blocks:[{title:"Mãos limpas",text:"Higienize as mãos antes e depois do contato. Use preparação alcoólica quando indicada e sem sujeira visível. Com sujeira visível, use água e sabonete. Siga também as indicações da equipe."},{title:"Equipamentos e dispositivos",text:"Não mexa em bombas, ventiladores, monitores, sondas, cateteres ou conexões. Mesmo um pequeno ajuste pode trazer riscos."},{title:"Se um alarme tocar",text:"Chame a equipe. Não aperte botões, não silencie o alarme e não tente resolver a causa por conta própria."},{title:"Peça ajuda",text:"Se perceber algo diferente ou tiver dúvida, avise a equipe. Siga as precauções e as orientações sobre equipamentos de proteção."}]},{number:4,title:"Estamos aqui para orientar",blocks:[{title:"Dúvidas são bem-vindas",text:"Procure a equipe. Cada profissional orienta conforme suas atribuições e encaminha dúvidas clínicas ao responsável."},{title:"Visitação e privacidade",text:"Confirme as orientações de visita do setor. Respeite o descanso e a privacidade de todas as pessoas. Não fotografe nem compartilhe informações sem autorização."}],message:"Acolher a família também é cuidar do paciente. Sua presença, seu carinho e sua parceria com a equipe fazem parte de uma assistência mais humana e segura."}],li=[{id:"familia-a4",title:"Folheto para familiares — A4 frente e verso",href:"/materiais/acolher-familia/folheto-familia-a4.pdf",pages:2,layout:"booklet-a4"},{id:"familia-a5",title:"Folheto para familiares — leitura em A5",href:"/materiais/acolher-familia/folheto-familia-a5.pdf",pages:4,layout:"reading-a5"}],ui={sheets:[[4,1],[2,3]],instructions:["Use uma folha A4, em paisagem, tamanho real / 100%, sem a opção de várias páginas por folha.","Imprima frente e verso, virando pela borda curta. Desative cabeçalhos e rodapés do navegador.","O arquivo já está montado: frente com páginas 4 | 1 e verso com páginas 2 | 3. Não ative novamente o modo livreto da impressora.","Faça primeiro uma cópia de teste, confira a orientação do verso e dobre a folha ao meio. Os ajustes de frente e verso podem variar conforme a impressora."]},Ee={version:si,updatedAt:ri,fullTitle:ni,statusNotice:ti,projectName:di,pages:ci,pdfs:li,print:ui},Ze=Ee.pdfs.map(a=>({...a,filename:a.href.split("/").at(-1),description:a.layout==="booklet-a4"?"Folheto para familiares: duas faces A4 em paisagem, com quatro páginas A5 organizadas para dobra central.":"Folheto para familiares: quatro páginas A5 em ordem de leitura, com o mesmo conteúdo da versão para imprimir."})),se=a=>`#acolher-familia/${a}`,Pa=a=>`#acolher-familia/simulador?caso=${a}`;function De(a){const o=[...new Set(a)].filter(s=>!Be.some(n=>n.id===s));if(o.length)throw new Error(`Referência familiar não cadastrada: ${o.join(", ")}`);return Be.filter(s=>a.includes(s.id)).map(s=>({label:s.title,href:s.href}))}function Ye(a,o){const s=a==="escalas"?Je(o):void 0;return`#${a}/${s??We(a,o)}`}function ce(a,o){return`topic.${a}.${We(a,o)}`}const ze=[...k.map(a=>({id:`module.${a.id}`,title:a.title,href:`#${a.id}`,kind:"Módulo"})),...k.flatMap(a=>a.topics.map(o=>({id:ce(a.id,o.title),title:o.title,href:Ye(a.id,o.title),kind:a.title}))),...ee.map(a=>({id:`term.${a.id}`,title:`${a.term} — ${a.definition}`,href:`#glossario/${a.id}`,kind:"Siglário"})),{id:"tool.glossario",title:"Siglário",href:"#glossario",kind:"Siglário"},{id:"tool.primeiro-dia",title:"Checklist do primeiro dia",href:"#primeiro-dia",kind:"Roteiro"},{id:"tool.caderno",title:"Caderno CTI Adulto",href:"#caderno",kind:"Leitura"},...ae.map(a=>({id:a.id,title:a.title,href:a.href,kind:"Ferramenta"})),...Ke.map(a=>({id:`family.section.${a.id}`,title:a.title,href:se(a.id),kind:"Acolhimento familiar"})),...be.map(a=>({id:`family.case.${a.id}`,title:a.title,href:Pa(a.id),kind:"Simulação de comunicação"}))],mi=[...ze.map(a=>a.id),...Object.keys(ye)];function co(a){return[...new Set(a.map(o=>Object.hasOwn(ye,o)?ye[o]:o).filter(o=>ze.some(s=>s.id===o)))]}function pi(a){return co(a).flatMap(o=>{const s=ze.find(n=>n.id===o);return s?[s]:[]})}const je=(a,o)=>({label:`Caderno CTI Adulto — ${o}, página ${a}`,href:`/materiais/caderno-cti-adulto-digital.pdf#page=${a}`,page:a});function ta(a){return{...a,example:a.facts.map(o=>o.text).join(" ")}}const re=[ta({id:"higiene-supervisionada",title:"Higiene supervisionada",goal:"Descrever o desconforto, a comunicação e o cuidado executado, sem presumir a resposta ao cuidado.",facts:[{id:"desconforto",text:"Durante uma higiene supervisionada, houve desconforto."},{id:"comunicacao",text:"A equipe foi informada."},{id:"posicao",text:"A posição foi ajustada conforme orientação da equipe."}],missingData:["O horário e os sinais específicos do desconforto não foram fornecidos.","Não foi informado qual profissional recebeu a comunicação.","A resposta após o ajuste de posição não foi informada."],exampleComment:"O exemplo conserva os três fatos e a sequência fornecida. Não afirma que o desconforto melhorou. A comunicação permanece genérica porque o cenário não identifica quem foi informado; essa lacuna deve ser reconhecida, sem inventar um profissional.",problematicExample:"Higiene realizada, tudo normal e pessoa confortável.",problematicComment:"“Tudo normal” é vago e omite o desconforto e a comunicação. “Confortável” acrescenta uma resposta que não foi fornecida.",sourceRefs:[{label:"Caso fictício existente — Uma anotação que conta o que aconteceu",href:"#quiz/registro-do-cuidado"},je(38,"anotação de enfermagem")],relatedHref:"#registros"}),ta({id:"volume-nao-medido",title:"Eliminação sem volume medido",goal:"Registrar uma ocorrência sem transformar uma estimativa ou um dado ausente em medida.",facts:[{id:"ocorrencia",text:"Ocorreu uma eliminação durante o cuidado simulado."},{id:"nao-medido",text:"O volume não pôde ser medido."}],missingData:["O tipo de eliminação, o horário e suas características não foram fornecidos.","Não há volume medido nem informação de uma comunicação já realizada."],exampleComment:"O exemplo informa a ocorrência e a limitação da medida. Não chama a eliminação de diurese, não copia um volume anterior e não afirma que alguém foi avisado, pois esses dados não constam do cenário.",problematicExample:"Diurese boa; volume igual ao do turno anterior.",problematicComment:"O cenário não informa que se tratava de diurese nem fornece um volume anterior. “Boa” não descreve um achado objetivo. Nenhum valor pode ser preenchido por suposição.",sourceRefs:[{label:"Caso fictício existente — Uma anotação que conta o que aconteceu",href:"#quiz/registro-do-cuidado"},je(24,"balanço e função renal"),je(38,"anotação de enfermagem")],relatedHref:"#registros"}),ta({id:"dieta-nao-iniciada",title:"Dieta não iniciada",goal:"Distinguir uma ação não realizada de uma ação concluída e documentar a orientação efetivamente recebida.",facts:[{id:"duvida",text:"Antes de administrar a dieta prescrita, não foi possível confirmar a liberação da sonda nasoenteral."},{id:"nao-iniciada",text:"A administração da dieta não foi iniciada."},{id:"orientacao",text:"O enfermeiro orientou aguardar a avaliação antes de iniciar a dieta."}],missingData:["O horário e a identificação do enfermeiro não foram fornecidos.","Não há resultado da avaliação nem confirmação posterior de liberação para uso."],exampleComment:"O exemplo registra a dúvida, a administração não iniciada e a orientação recebida. Não declara a sonda liberada e não acrescenta uma avaliação ou conduta posterior.",problematicExample:"Dieta administrada, sonda funcionando normalmente.",problematicComment:"A frase contradiz a administração não iniciada e afirma um funcionamento que não foi avaliado no cenário. O registro deve refletir somente os fatos apresentados.",sourceRefs:[{label:"Caso fictício existente — A sonda está liberada para uso?",href:"#quiz/duvida-sobre-sonda"},je(25,"sondas e dieta enteral"),je(38,"anotação de enfermagem")],relatedHref:"#registros"})],La=[{id:"fidelidade",label:"Conservei os fatos fornecidos.",explanation:"Compare sua anotação com cada fato do cenário. Mantenha inclusive o que não foi realizado ou não pôde ser medido."},{id:"clareza",label:"Usei linguagem clara e objetiva.",explanation:"Prefira descrições dos acontecimentos e evite julgamentos ou expressões vagas, como “tudo normal”."},{id:"sequencia",label:"Respeitei a sequência que foi informada.",explanation:"Use a ordem dos fatos quando ela estiver indicada. Nenhum destes cenários fornece horário: reconheça a lacuna, sem inventar uma hora."},{id:"cuidado-comunicacao",label:"Descrevi cuidados e comunicação apenas quando fornecidos.",explanation:"Inclua as ações realizadas e as orientações recebidas que constam do cenário. Não afirme que houve uma comunicação ou uma resposta ao cuidado quando isso não foi informado."},{id:"sem-inferencias",label:"Não acrescentei dados ou conclusões por suposição.",explanation:"Não complete horários, medidas, respostas ao cuidado ou identificação profissional ausentes. Este exercício não deve receber dados de pessoas reais."}],fi=re.map(a=>[a.title,a.goal,...a.facts.map(o=>o.text),...a.missingData].join(" ")).join(" ");function X(a,o,s,n,r){const i=Xe.find(t=>t.moduleId===o&&t.topicTitle===s);if(!i)throw new Error(`O item do box precisa de um desenho existente: ${o}/${s}`);return{id:a,title:s,moduleId:o,topicTitle:s,description:i.description,x:n,y:r,source:i.source}}const ne=[X("monitor","equipamentos","Monitor multiparamétrico",16,21),X("ventilador","equipamentos","Ventilador mecânico",81,21),X("bomba","equipamentos","Bomba de infusão",16,45),X("oxigenio","equipamentos","Oxigenoterapia",81,45),X("cvc","dispositivos","Cateter venoso central (CVC)",16,69),X("sonda-vesical","dispositivos","Sonda vesical de demora",81,69),X("sonda-enteral","dispositivos","Sonda nasoenteral",37,87),X("tubo","dispositivos","Tubo orotraqueal",63,87)],qe="cti-integration-v1",Z=[{id:"referencia-equipe",title:"Identificar as pessoas de referência no setor",detail:"Converse com a equipe sobre quem acompanha sua ambientação, quem é o enfermeiro responsável e a quem levar dúvidas sobre os cuidados e as atribuições.",href:"#acolhimento",sourceLabel:"Módulo Bem-vindo à CTI · Equipe multiprofissional"},{id:"comunicacao-setor",title:"Conhecer os canais autorizados de comunicação",detail:"Peça que a equipe apresente como comunicar mudanças, pendências e pedidos de ajuda, preservando o sigilo. Este roteiro não informa ramais nem fluxos internos.",href:"#rotinas",sourceLabel:"Módulo Rotinas da CTI · Recebimento e passagem de plantão; Alterações clínicas e registros"},{id:"passagem-plantao",title:"Acompanhar a organização e a passagem de plantão",detail:"Reconheça com a equipe o instrumento de passagem de plantão e como são conferidas as informações e pendências. Confirme a rotina local antes de assumir que ela é igual à de outra instituição.",href:"#rotinas",sourceLabel:"Módulo Rotinas da CTI · Recebimento e passagem de plantão"},{id:"recursos-autorizados",title:"Reconhecer materiais e recursos com acompanhamento",detail:"Solicite um reconhecimento acompanhado dos recursos que a instituição autoriza apresentar. A localização real e o acesso aos materiais precisam ser informados pela equipe responsável.",href:"#acolhimento",sourceLabel:"Módulo Bem-vindo à CTI · Segurança e primeiro dia"},{id:"seguranca-precaucoes",title:"Revisar identificação, higiene das mãos e precauções",detail:"Confirme com a equipe os recursos e orientações vigentes de identificação, higiene das mãos, EPIs, descarte e precauções. Siga os documentos autorizados e esclareça diferenças em relação a experiências anteriores.",href:"#acolhimento",sourceLabel:"Módulo Bem-vindo à CTI · Segurança e primeiro dia"},{id:"equipamentos-capacitacao",title:"Reconhecer equipamentos e confirmar a capacitação aplicável",detail:"Identifique os equipamentos e dispositivos utilizados e com quem esclarecer seu funcionamento. A leitura do aplicativo não substitui capacitação, supervisão ou autorização para operar e ajustar recursos.",href:"#equipamentos",sourceLabel:"Módulos Equipamentos hospitalares e Dispositivos"},{id:"registro-local",title:"Conhecer as orientações de registro e privacidade",detail:"Pergunte quais orientações e canais de registro são adotados e autorizados pela instituição. Não copie dados de pacientes, prontuários ou imagens para este aplicativo.",href:"#registros",sourceLabel:"Módulo Anotações de enfermagem; Módulo Bem-vindo à CTI · Ética, sigilo e humanização"},{id:"documentos-validos",title:"Confirmar onde consultar os documentos autorizados",detail:"Peça à equipe que apresente o acesso autorizado aos documentos vigentes e a forma de reconhecer sua versão. Não envie protocolos internos restritos para o aplicativo público.",href:"#biblioteca",sourceLabel:"Biblioteca científica · Controle de revisão e fontes de consulta"},{id:"duvidas-integracao",title:"Revisar dúvidas e combinar a continuidade da integração",detail:"Converse com a pessoa de referência sobre pontos ainda não apresentados e necessidades de acompanhamento. As marcações deste roteiro não comprovam treinamento obrigatório, competência ou liberação para executar procedimentos.",href:"#acolhimento",sourceLabel:"Módulo Bem-vindo à CTI · Equipe multiprofissional; Segurança e primeiro dia"}],He="1.0.0",Se=[{id:"localizar",text:"Consegui localizar os conteúdos que procurava."},{id:"clareza",text:"Os textos e as instruções foram claros para mim."},{id:"navegacao",text:"Consegui navegar e retornar entre as telas com facilidade."},{id:"ambientacao",text:"Os roteiros me ajudaram a organizar dúvidas sobre a ambientação na CTI."},{id:"equipamentos",text:"Os desenhos me ajudaram a reconhecer equipamentos e dispositivos."},{id:"discussao",text:"Os casos e exercícios estimularam minha reflexão e a discussão com a equipe."},{id:"limites",text:"Ficou claro que o aplicativo é educativo e não substitui supervisão ou protocolos aplicáveis."}],ya=[{value:"1",label:"1 — Discordo totalmente"},{value:"2",label:"2 — Discordo"},{value:"3",label:"3 — Nem concordo nem discordo"},{value:"4",label:"4 — Concordo"},{value:"5",label:"5 — Concordo totalmente"},{value:"na",label:"Não avaliei"}],hi=new Set(ya.map(a=>a.value));function Ea(a){return typeof a=="string"&&hi.has(a)}function vi(a){return Se.filter(o=>Ea(a[o.id])).length}function Va(a,o){if(!o||!a||typeof a!="object"||Array.isArray(a))return null;const s=a,n=[];for(const r of Se){const i=Object.hasOwn(s,r.id)?s[r.id]:void 0;if(!Ea(i))return null;n.push({item:r.id,answer:i})}return{instrumentVersion:He,answers:n}}function xi(a){return ya.find(o=>o.value===a).label}const G=[{id:"origem",title:"Apresente o projeto e seu status",purpose:"Comece pelo problema de acolhimento e ambientação que motivou o PBL.",actions:["Explique a origem acadêmica e os dois públicos.","Mostre que esta é uma demonstração educacional em avaliação, com revisão profissional e institucional pendentes."],links:[{href:"#projeto",label:"Sobre o Projeto"},{href:"#conteudos",label:"Ver conteúdos e revisão"}]},{id:"perfis",title:"Mostre os dois percursos de entrada",purpose:"A escolha organiza prioridades de aprendizagem, sem cadastro ou identificação.",actions:["Escolha “Sou estagiário” e observe os atalhos recomendados.","Troque para “Sou novo colaborador” e mostre que os conteúdos gerais continuam disponíveis."],links:[{href:"#perfil",label:"Escolher ou trocar perfil"},{href:"#inicio",label:"Ver a tela inicial"}]},{id:"checklists",title:"Explore a ambientação com checklists",purpose:"Roteiros distintos ajudam a organizar o primeiro dia e a integração.",actions:["Mostre uma marcação e o progresso local em cada roteiro.","Explique que os itens de integração local dependem da instituição e que a conclusão não certifica competência nem autoriza procedimentos."],links:[{href:"#primeiro-dia",label:"Primeiro dia do estagiário"},{href:"#integracao",label:"Integração do colaborador"}]},{id:"pesquisa",title:"Encontre um assunto pelo nome",purpose:"A pesquisa e o Siglário permitem consultar a base compartilhada.",actions:["Pesquise um assunto, como RASS ou equipamentos, na tela inicial.","Abra o Siglário e use uma sigla ou uma palavra da definição; mostre as notas de conferência quando presentes."],links:[{href:"#inicio",label:"Pesquisar no app"},{href:"#glossario",label:"Consultar o Siglário"}]},{id:"box",title:"Visite o box fictício",purpose:"Reconheça equipamentos em uma apresentação educativa sem representar o setor real.",actions:["Selecione um equipamento na cena e leia a explicação.","Mostre a alternativa textual e a navegação por teclado. Não demonstre ajustes de tratamento."],links:[{href:"#cti-virtual",label:"Explorar a CTI virtual"},{href:"#equipamentos",label:"Rever equipamentos"}]},{id:"escalas",title:"Consulte escalas pela finalidade",purpose:"Distinga estudo de dor, sedação/agitação e nível de consciência.",actions:["Escolha uma finalidade e consulte o instrumento relacionado.","Mostre referências, limitações e status de revisão, sem inserir dados reais de pacientes ou recomendar condutas."],links:[{href:"#escalas",label:"Abrir escalas educativas"}]},{id:"problemas",title:"Aprenda com situações fictícias",purpose:"O PBL estimula reconhecimento de problemas, comunicação e reflexão com a equipe.",actions:["Percorra uma decisão de um caso e leia a explicação.","No laboratório, use somente os fatos do cenário para comparar uma anotação com a rubrica de autorrevisão."],links:[{href:"#quiz",label:"Praticar com casos e quiz"},{href:"#laboratorio",label:"Laboratório de anotações"}]},{id:"materiais",title:"Retome o caderno e os materiais",purpose:"Os documentos e seus créditos fazem parte da continuidade do projeto.",actions:["Abra um PDF original e mostre como retornar à aba do aplicativo.","No caderno, mostre a leitura de uma página por vez, favoritos e retomada local. O primeiro carregamento e os links externos precisam de conexão."],links:[{href:"#biblioteca",label:"Consultar a Biblioteca"},{href:"#caderno",label:"Ler o caderno"}]},{id:"avaliacao",title:"Encerre com avaliação e pendências",purpose:"Separe percepção de uso, revisão de conteúdo e autorização institucional.",actions:["Mostre o questionário voluntário de demonstração local, sem envio remoto.","Apresente as pendências de revisão, créditos e homologação. Não declare adoção oficial pela instituição."],links:[{href:"#avaliacao-pbl",label:"Avaliação local do PBL"},{href:"#conteudos",label:"Conferir revisão dos conteúdos"}]}],Ge=(a,o=`Caderno CTI Adulto — página ${a}`)=>({label:o,page:a,href:`/materiais/caderno-cti-adulto-digital.pdf#page=${a}`}),ie=a=>[...new Map(a.map(o=>[o.href,o])).values()],O=a=>({recommendedAudiences:["estagiario","colaborador"],references:[],referenceStatus:"specific_reference_pending",lastReviewedAt:null,reviewedBy:null,status:"pending_review",version:"1",publicationScope:"educational_public",authorizationReference:null,notes:[],...a});function gi(a){if(a==="acolher-familia")return Be.map(i=>({label:i.title,href:i.href}));const o=Aa.filter(i=>i.moduleId===a&&i.page).map(i=>Ge(i.page,i.label)),s=Q.filter(i=>i.relatedModule.href.split("/")[0]===`#${a}`).flatMap(i=>i.sources),n=Xe.filter(i=>i.moduleId===a).map(i=>i.source),r=a==="escalas"?de.flatMap(i=>i.references):[];return ie([...o,...s,...n,...r])}const bi=[{id:"primeiro-dia",title:"Checklist do primeiro dia",description:"Roteiro educativo para ambientação, com marcações locais.",references:W.filter(a=>a.sourcePage).map(a=>Ge(a.sourcePage,a.sourceLabel))},{id:"glossario",title:"Siglário",description:"Transcrição e atualizações fornecidas pelo responsável pelo projeto.",references:[{label:"Relatório indicado pelo responsável; transcrição fornecida, sem conferência online independente.",href:Qe.href}]},{id:"caderno",title:"Caderno digital",description:"Livro educativo com leitura horizontal e retomada local.",references:[{label:"PDF de origem do caderno",href:te[0].href}]},{id:"favoritos",title:"Meus favoritos",description:"Atalhos de leitura guardados somente neste navegador.",references:[]}],$a={acolhimento:Na.flatMap(a=>a.referenceIds),visitante:Sa.flatMap(a=>a.referenceIds),falas:Re.flatMap(a=>a.referenceIds),simulador:be.flatMap(a=>a.referenceIds),material:Be.map(a=>a.id)};function ji(a){return a==="tool.laboratorio"?{references:ie(re.flatMap(o=>o.sourceRefs)),referenceStatus:"provided_materials",notes:["Exercícios fictícios baseados nos casos e nas páginas do caderno indicados. Rubrica de autorrevisão educativa, sem pontuação automática, certificação ou validação de competência. A revisão profissional permanece pendente."]}:a==="tool.cti-virtual"?{references:ie(ne.map(o=>o.source)),referenceStatus:"provided_materials",notes:["Box fictício construído com desenhos educativos existentes. As posições não representam planta, localização de materiais ou instalação de equipamentos da instituição. Não ensina ajustes de tratamento."]}:a==="tool.integracao"?{recommendedAudiences:["colaborador"],references:ie(Z.map(o=>({label:o.sourceLabel,href:o.href}))),notes:["Base educativa local indicada nos módulos. Referências profissionais específicas e cada item de ambientação ainda precisam de revisão institucional. As marcações não registram treinamento obrigatório ou autorização para procedimentos."]}:a==="tool.avaliacao-pbl"?{version:He,references:[{label:"Sobre o Projeto — privacidade e limites da demonstração educacional",href:"#projeto"}],notes:[`Questionário próprio desta demonstração, versão ${He}. Não foi apresentado como instrumento validado de usabilidade, aprendizagem ou competência. Respostas ficam na sessão; a exportação é manual e depende de consentimento. Coleta remota e validação do instrumento permanecem pendentes de proposta e autorização.`]}:a==="tool.demonstracao"?{references:ie(G.flatMap(o=>o.links.map(s=>({label:`Percurso da demonstração — ${s.label}`,href:s.href})))),notes:["Roteiro funcional de apresentação dos recursos existentes, sem dados reais. Os vínculos demonstram as telas do projeto e não constituem referências clínicas nem aprovação institucional."]}:{}}const Ue=[...k.map(a=>O({id:`module.${a.id}`,title:a.title,description:a.description,category:"Módulo",href:`#${a.id}`,references:gi(a.id),notes:["Materiais relacionados já presentes no projeto. A revisão e o vínculo de cada afirmação à fonte específica permanecem pendentes."]})),...k.flatMap(a=>a.topics.map(o=>{const s=a.id==="escalas"?de.find(t=>t.id===Je(o.title)):void 0,n=Xe.find(t=>t.moduleId===a.id&&t.topicTitle===o.title),r=Aa.filter(t=>t.moduleId===a.id&&t.page&&t.label.includes(o.title)).map(t=>Ge(t.page,t.label)),i=ie(o.title===J.title?ro:s?s.references:[...n?[n.source]:[],...r]);return O({id:ce(a.id,o.title),title:o.title,category:a.id==="escalas"?"Escala":"Assunto",description:o.purpose,href:Ye(a.id,o.title),references:i,referenceStatus:i.length?"provided_materials":"specific_reference_pending",notes:i.length?["Fontes fornecidas no projeto; confirmar versão, adequação profissional e vigência antes de validação clínica."]:["Referência específica deste assunto ainda precisa ser documentada. A lista geral de portais não valida o texto."]})})),...Ke.map(a=>O({id:`family.section.${a.id}`,title:a.title,category:"Acolhimento familiar",description:a.description,href:se(a.id),references:De($a[a.id]??[]),referenceStatus:"specific_reference_pending",notes:["Orientações gerais de acolhimento e segurança. Aplicação, atribuições, condições clínicas e participação em cuidados dependem de supervisão e normas aplicáveis. A regra relatada para a CTI Cardio é local e ainda precisa de confirmação institucional."]})),...Re.map(a=>O({id:`family.speech.${a.id}`,title:a.title,category:"Comunicação com familiares",description:a.recommended,href:se("falas"),references:De(a.referenceIds),referenceStatus:"specific_reference_pending",notes:["Exemplos de comunicação educativa, sem previsão de recuperação, promessa de prognóstico ou garantia de percepção durante sedação. Revisão pela enfermeira responsável pendente."]})),...be.map(a=>O({id:`family.case.${a.id}`,title:a.title,category:"Simulação de comunicação",description:a.situation,href:Pa(a.id),references:De(a.referenceIds),referenceStatus:"specific_reference_pending",notes:["Situação inteiramente fictícia. As alternativas e explicações orientam a reflexão; não substituem supervisão ou protocolo institucional e não certificam competência."]})),...Ze.map(a=>O({id:`pdf.${a.id}`,title:a.title,category:"PDF",description:a.description,href:se("material"),version:Ee.version,references:[{label:`${Ee.fullTitle} — ${a.layout==="booklet-a4"?"duas faces A4 impostas para dobra central":"quatro páginas A5 em ordem de leitura"}`,href:a.href},...De($a.material)],referenceStatus:"provided_materials",notes:["Material educativo sujeito à validação institucional. Atualização editorial e geração de PDF não equivalem a revisão clínica. Confirmar o conteúdo com a enfermeira responsável antes de entregar aos familiares."]})),...de.map(a=>O({id:`scale.${a.id}`,title:a.name,category:"Escala",description:a.purpose,href:`#escalas/${a.id}`,references:a.references,referenceStatus:"provided_materials",notes:["Guia de leitura educativo, sem avaliação de paciente ou decisão clínica autônoma."]})),...Q.map(a=>O({id:`case.${a.id}`,title:a.title,category:"Caso simulado",description:a.summary,href:`#quiz/${a.id}`,references:a.sources,referenceStatus:"provided_materials",notes:["Cenário fictício. Não representa caso real nem certificação de competência."]})),...re.map(a=>O({id:`annotation.${a.id}`,title:a.title,category:"Exercício de anotação",description:a.goal,href:`#laboratorio/${a.id}`,references:a.sourceRefs,referenceStatus:"provided_materials",notes:["Cenário inteiramente fictício. Os exemplos conservam somente os fatos fornecidos, sem completar dados ausentes. A rubrica é educativa e depende de revisão profissional."]})),...ne.map(a=>O({id:`virtual.${a.id}`,title:a.title,category:"CTI virtual",description:a.description,href:"#cti-virtual",references:[a.source],referenceStatus:"provided_materials",notes:["Representação educativa de um box fictício; não descreve equipamentos instalados, localização real ou operação autorizada de uma instituição."]})),...W.map(a=>O({id:`checklist.${a.id}`,title:a.title,category:"Checklist do primeiro dia",description:a.detail,href:"#primeiro-dia",recommendedAudiences:["estagiario"],references:[{label:a.sourceLabel,href:a.href},...a.sourcePage?[Ge(a.sourcePage)]:[]],referenceStatus:a.sourcePage?"provided_materials":"specific_reference_pending",notes:["Orientação geral para conversar com o preceptor. A organização e os fluxos reais devem ser apresentados pela equipe autorizada. Marcar este item não equivale a treinamento ou certificação."]})),...Z.map(a=>O({id:`integration.${a.id}`,title:a.title,category:"Checklist de integração",description:a.detail,href:"#integracao",recommendedAudiences:["colaborador"],references:[{label:a.sourceLabel,href:a.href}],notes:["Origem educativa indicada no módulo local; referência profissional específica e aplicação ao setor ainda pendentes de validação institucional. Não apresenta fluxo interno autorizado nem comprova competência."]})),...[...te,...ge].map(a=>O({id:`pdf.${a.id}`,title:a.title,category:"PDF",description:a.description,href:`#biblioteca/${a.id}`,references:[{label:`${a.title} — arquivo fornecido; referências e créditos preservados no documento.`,href:a.href}],referenceStatus:"provided_materials",notes:["Integridade do arquivo não equivale a revisão clínica. Confirmar direitos de divulgação e autorização de materiais de terceiros."]})),...ee.map(a=>O({id:`term.${a.id}`,title:a.term,category:"Siglário",description:a.definition,href:`#glossario/${a.id}`,references:[{label:"Fonte indicada para a transcrição fornecida; não verificada diretamente neste ambiente.",href:Qe.href},...a.reference?[a.reference]:[]],referenceStatus:"provided_materials",notes:[a.sourceLabel,...a.reviewNote?[a.reviewNote]:[]]})),...bi.map(a=>O({id:`tool.${a.id}`,title:a.title,category:"Ferramenta",description:a.description,href:`#${a.id}`,references:ie(a.references),referenceStatus:a.references.length?"provided_materials":"specific_reference_pending",...a.id==="primeiro-dia"?{recommendedAudiences:["estagiario"]}:{}})),...ae.map(a=>O({id:a.id,title:a.title,category:"Ferramenta",description:a.description,href:a.href,notes:["Recurso de demonstração e aprendizagem. As orientações e eventuais fluxos do setor dependem de validação profissional e institucional."],...ji(a.id)}))];function Ci(a){var s,n,r;const o=new Set;for(const i of a){if(!i.id||o.has(i.id))throw new Error(`Identificador de conteúdo ausente ou repetido: ${i.id}`);if(o.add(i.id),!i.title||!i.description||!i.version||!i.category||!i.recommendedAudiences.length)throw new Error(`Metadados incompletos: ${i.id}`);if(!["pending_review","educational_reviewed","institutional_validated"].includes(i.status)||!["educational_public","institutional_public","restricted"].includes(i.publicationScope)||i.recommendedAudiences.some(t=>!["estagiario","colaborador"].includes(t)))throw new Error(`Classificação de conteúdo inválida: ${i.id}`);if(i.publicationScope==="restricted")throw new Error(`Material restrito não pode integrar o aplicativo público: ${i.id}`);if(i.status==="institutional_validated"&&(!((s=i.reviewedBy)!=null&&s.trim())||!i.lastReviewedAt||!((n=i.authorizationReference)!=null&&n.trim())||!i.references.length))throw new Error(`Validação institucional sem evidência suficiente: ${i.id}`);if(i.status==="educational_reviewed"&&(!((r=i.reviewedBy)!=null&&r.trim())||!i.lastReviewedAt||!i.references.length))throw new Error(`Revisão educativa sem registro suficiente: ${i.id}`);if(i.publicationScope==="institutional_public"&&i.status!=="institutional_validated")throw new Error(`Publicação institucional sem validação: ${i.id}`);if(i.lastReviewedAt&&(!/^\d{4}-\d{2}-\d{2}$/.test(i.lastReviewedAt)||Number.isNaN(Date.parse(`${i.lastReviewedAt}T00:00:00Z`))||new Date(`${i.lastReviewedAt}T00:00:00Z`).toISOString().slice(0,10)!==i.lastReviewedAt))throw new Error(`Data de revisão inválida: ${i.id}`);for(const t of i.references)if(!t.label||!/^(?:https:\/\/|#[a-z]|\/materiais\/)/.test(t.href))throw new Error(`Referência inválida: ${i.id}`)}}Ci(Ue);function qi(a){return Ue.find(o=>o.id===a||a.startsWith("material.")&&o.id===a.replace(/^material\./,"pdf."))}const lo=[...te.map(a=>({id:a.id,title:a.title,href:a.href,pages:a.pages,filename:a.originalFilename})),...ge.map(a=>({id:a.id,title:a.title,href:a.href,pages:a.pages,filename:a.downloadFilename})),...Ze.map(a=>({id:a.id,title:a.title,href:a.href,pages:a.pages,filename:a.filename}))];function Ai(a){return lo.find(o=>o.id===a)}function Ni(a,o){const s=Number(a);return Number.isSafeInteger(s)&&s>=1&&s<=o?s:1}function K(a){const[o,s]=a.split("#"),n=lo.find(i=>i.href===o);if(!n)return{href:a,target:"_blank",rel:"noopener noreferrer"};const r=Ni(new URLSearchParams(s).get("page"),n.pages);return{href:`${n.href}#page=${r}`,target:"_blank",rel:"noopener noreferrer"}}function V({contentId:a,compact:o=!1}){const s=qi(a),n=d.useId();return s?e.jsxs("aside",{className:`content-review${o?" content-review-compact":""}`,"aria-label":"Situação da revisão",children:[e.jsxs("p",{className:"content-review-status",children:[e.jsx(Y,{size:18,"aria-hidden":"true"}),e.jsx("strong",{children:s.status==="institutional_validated"?"Validação institucional documentada":s.status==="educational_reviewed"?"Revisão educativa documentada":"Revisão profissional pendente"})]}),e.jsxs("p",{children:["Última revisão clínica: ",s.lastReviewedAt??"não realizada",". Responsável: ",s.reviewedBy??"a definir",". Versão do conteúdo: ",s.version,"."]}),!o&&e.jsxs("details",{children:[e.jsxs("summary",{children:[e.jsx(D,{size:17,"aria-hidden":"true"})," Referências e origem deste conteúdo"]}),e.jsxs("div",{id:`${n}-references`,children:[s.referenceStatus==="specific_reference_pending"&&e.jsx("p",{className:"content-review-gap",children:"Referência específica pendente de conferência. Materiais relacionados não equivalem à validação de cada afirmação."}),s.references.length?e.jsx("ul",{children:s.references.map(r=>e.jsx("li",{children:e.jsxs("a",{...r.href.startsWith("/materiais/")?K(r.href):{href:r.href,...r.href.startsWith("https://")?{target:"_blank",rel:"noopener noreferrer"}:{}},children:[r.label,e.jsx(T,{size:15,"aria-hidden":"true"}),r.href.startsWith("/")||r.href.startsWith("https://")?e.jsx("span",{className:"sr-only",children:" (abre em outra aba)"}):null]})},`${r.href}-${r.label}`))}):e.jsx("p",{children:"Referências específicas ainda não foram vinculadas a este item."}),s.notes.map(r=>e.jsx("p",{children:r},r)),e.jsx("p",{children:"Conteúdo educativo. Não representa protocolo institucional oficialmente aprovado. A data de atualização do aplicativo não é data de revisão clínica."})]})]})]}):e.jsxs("aside",{className:"content-review","aria-label":"Situação da revisão",children:[e.jsx("p",{children:e.jsx("strong",{children:"Revisão profissional pendente"})}),e.jsx("p",{children:"Data e responsável pela revisão: a definir. Referências específicas ainda precisam ser documentadas."})]})}const Ba=a=>a.normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase(),da=30;function Si(){const[a,o]=d.useState(""),[s,n]=d.useState(""),[r,i]=d.useState(""),[t,u]=d.useState(da),m=d.useRef(null),h=d.useRef(null),f=d.useId(),C=Ue.filter(j=>(!s||j.category===s)&&(!r||j.status===r)&&Ba(`${j.title} ${j.description}`).includes(Ba(a.trim()))),b=[...new Set(Ue.map(j=>j.category))];function A(){h.current=null,u(da)}d.useEffect(()=>{var q,E;const j=h.current;j!==null&&(h.current=null,(E=(q=m.current)==null?void 0:q.querySelectorAll("h3 a")[j])==null||E.focus())},[t]);const y=j=>j.status==="pending_review"?"Pendente de revisão":j.status==="educational_reviewed"?"Revisão educativa":"Validação institucional";return e.jsxs("section",{className:"content-catalog","aria-labelledby":`${f}-heading`,children:[e.jsx("h2",{id:`${f}-heading`,children:"Conteúdos, referências e revisão"}),e.jsx("p",{children:"Este catálogo registra a origem e as pendências de cada conteúdo. A presença de uma referência ou de uma transcrição conferida pelo autor não representa aprovação institucional do aplicativo."}),e.jsxs("div",{className:"content-catalog-filters",children:[e.jsxs("label",{children:["Pesquisar conteúdo",e.jsx("input",{type:"search",value:a,onChange:j=>{o(j.target.value),A()},autoComplete:"off"})]}),e.jsxs("label",{children:["Categoria",e.jsxs("select",{value:s,onChange:j=>{n(j.target.value),A()},children:[e.jsx("option",{value:"",children:"Todas as categorias"}),b.map(j=>e.jsx("option",{children:j},j))]})]}),e.jsxs("label",{children:["Situação",e.jsxs("select",{value:r,onChange:j=>{i(j.target.value),A()},children:[e.jsx("option",{value:"",children:"Todas as situações"}),e.jsx("option",{value:"pending_review",children:"Pendente de revisão"}),e.jsx("option",{value:"educational_reviewed",children:"Revisão educativa"}),e.jsx("option",{value:"institutional_validated",children:"Validação institucional"})]})]})]}),e.jsxs("p",{role:"status",children:[C.length," conteúdos encontrados. Mostrando ",Math.min(t,C.length),"."]}),e.jsx("ul",{ref:m,id:`${f}-results`,className:"content-catalog-list",children:C.slice(0,t).map(j=>e.jsxs("li",{children:[e.jsxs("div",{children:[e.jsxs("span",{children:[j.category," · ",y(j)]}),e.jsx("h3",{children:e.jsxs("a",{href:j.href,children:[j.title,e.jsx(R,{size:16,"aria-hidden":"true"})]})}),e.jsx("p",{children:j.description})]}),e.jsx(V,{contentId:j.id})]},j.id))}),!C.length&&e.jsx("p",{children:"Nenhum conteúdo corresponde aos filtros. Tente outra categoria ou situação."}),C.length>t&&e.jsx("button",{className:"button","aria-controls":`${f}-results`,onClick:()=>{h.current=t,u(j=>j+da)},children:"Mostrar mais conteúdos"})]})}function Pi(){return e.jsxs("section",{className:"pdf-materials","aria-labelledby":"pdf-materials-heading",children:[e.jsx("div",{className:"eyebrow",children:"MATERIAIS DO PROJETO"}),e.jsx("h2",{id:"pdf-materials-heading",children:"Seu caderno, do seu jeito."}),e.jsx("p",{className:"pdf-intro",children:"Leia a versão digital ou baixe o caderno de bolso para imprimir, se preferir. Os textos, as referências e os links dos cadernos do autor foram preservados."}),e.jsx(to,{}),e.jsx("div",{className:"pdf-grid",children:te.map(a=>{const o=a.use==="print",s=o?To:D;return e.jsxs("article",{className:"pdf-card",id:`material-${a.id}`,tabIndex:-1,"aria-label":a.title,children:[e.jsxs("div",{className:"pdf-card-top",children:[e.jsx("span",{className:`pdf-icon ${o?"print":""}`,children:e.jsx(s,{size:25})}),e.jsx("span",{className:"pdf-tag",children:o?"IMPRESSÃO OPCIONAL":"LEITURA DIGITAL"})]}),e.jsx("h3",{children:a.title}),e.jsx("p",{children:a.description}),e.jsxs("div",{className:"pdf-meta",children:[e.jsx(qa,{size:14})," PDF · ",a.pages," ",o?"folhas A4":"páginas"," · ",(a.bytes/1024/1024).toLocaleString("pt-BR",{maximumFractionDigits:2})," MB"]}),e.jsx("div",{className:"pdf-actions",children:o?e.jsxs(e.Fragment,{children:[e.jsxs("a",{className:"button",href:a.href,download:a.originalFilename,children:[e.jsx(pe,{size:16})," Baixar para imprimir"]}),e.jsxs("a",{className:"pdf-open",href:a.href,target:"_blank",rel:"noopener noreferrer","aria-label":"Abrir PDF de impressão em outra aba ou no visualizador do aparelho",children:["Abrir PDF ",e.jsx(T,{size:15})]})]}):e.jsxs(e.Fragment,{children:[e.jsxs("a",{className:"button",href:"#caderno","aria-label":"Ler caderno digital como livro",children:[e.jsx(D,{size:16})," Ler caderno"]}),e.jsxs("a",{className:"pdf-open",href:a.href,target:"_blank",rel:"noopener noreferrer","aria-label":"Abrir PDF do caderno em outra aba ou no visualizador do aparelho",children:["Abrir PDF ",e.jsx(T,{size:15})]}),e.jsxs("a",{className:"pdf-open",href:a.href,download:a.originalFilename,children:[e.jsx(pe,{size:15})," Baixar PDF"]})]})}),o&&e.jsxs("details",{className:"pdf-instructions",children:[e.jsx("summary",{children:"Como imprimir o caderno de bolso"}),e.jsxs("ol",{children:[e.jsxs("li",{children:["Selecione papel ",e.jsx("strong",{children:"A4"}),", ",e.jsx("strong",{children:"tamanho real / 100%"})," e frente única."]}),e.jsxs("li",{children:["Imprima ",e.jsx("strong",{children:"uma página do PDF por folha"}),". O arquivo já traz quatro páginas de bolso em cada A4."]}),e.jsx("li",{children:"Recorte e organize pela numeração de 01 a 96."})]})]}),e.jsx(V,{contentId:`pdf.${a.id}`,compact:!0})]},a.id)})}),e.jsx(Zo,{})]})}function yi(){return e.jsxs("a",{className:"materials-shortcut",href:"#biblioteca",children:[e.jsx("span",{className:"pdf-icon",children:e.jsx(D,{size:23})}),e.jsxs("span",{children:[e.jsx("strong",{children:"Cadernos e apostilas de estudo"}),e.jsx("span",{children:"Leia, baixe as apostilas ou imprima o caderno de bolso."})]}),e.jsx(R,{size:20})]})}function Ei(){return e.jsxs("section",{className:"apostila-materials pdf-materials","aria-labelledby":"apostila-heading",children:[e.jsx("div",{className:"eyebrow",children:"APROFUNDE SEUS ESTUDOS"}),e.jsx("h2",{id:"apostila-heading",children:"Apostilas de estudo"}),e.jsx("p",{className:"pdf-intro",children:"Abra o PDF original para ampliar e ler, ou baixe uma cópia. As apostilas seguem as cores do aplicativo e preservam os textos, as ilustrações, as referências e os créditos dos documentos enviados pelo autor."}),e.jsx(to,{}),e.jsx("div",{className:"pdf-grid",children:ge.map(a=>e.jsxs("article",{className:"pdf-card apostila-card",id:`material-${a.id}`,tabIndex:-1,"aria-label":a.title,children:[e.jsxs("div",{className:"pdf-card-top",children:[e.jsx("span",{className:"pdf-icon",children:e.jsx(D,{size:25})}),e.jsx("span",{className:"pdf-tag",children:"APOSTILA DE ESTUDO"})]}),e.jsx("h3",{children:a.title}),e.jsx("p",{children:a.description}),e.jsxs("div",{className:"pdf-meta",children:[e.jsx(qa,{size:14})," PDF · ",a.pages," páginas · ",(a.bytes/1024/1024).toLocaleString("pt-BR",{maximumFractionDigits:1})," MB"]}),e.jsxs("div",{className:"pdf-actions",children:[e.jsxs("a",{className:"button",href:a.href,target:"_blank",rel:"noopener noreferrer","aria-label":`Abrir PDF: ${a.title} (outra aba ou visualizador do aparelho)`,children:[e.jsx(D,{size:16})," Abrir PDF ",e.jsx(T,{size:15})]}),e.jsxs("a",{className:"pdf-open",href:a.href,download:a.downloadFilename,"aria-label":`Baixar apostila: ${a.title}`,children:[e.jsx(pe,{size:15})," Baixar PDF"]})]}),e.jsx(V,{contentId:`pdf.${a.id}`,compact:!0})]},a.id))}),e.jsx("p",{className:"apostila-offline",children:"Para ler sem internet, use “Baixar PDF” e abra o arquivo salvo em Arquivos no iPhone ou na pasta Downloads no Android."})]})}function Mi({moduleId:a}){const o=ge.filter(s=>s.moduleIds.includes(a));return o.length?e.jsxs("section",{className:"apostila-related","aria-label":"Apostilas relacionadas ao módulo",children:[e.jsx("h2",{children:"Aprofunde com as apostilas"}),e.jsx("ul",{children:o.map(s=>e.jsx("li",{children:e.jsxs("a",{href:s.href,target:"_blank",rel:"noopener noreferrer",children:[e.jsx(qa,{size:20}),e.jsxs("span",{children:[e.jsx("strong",{children:s.title}),e.jsxs("span",{children:["PDF · ",s.pages," páginas"]})]}),e.jsx(T,{size:17}),e.jsx("span",{className:"sr-only",children:"Abrir PDF em outra aba ou no visualizador do aparelho"})]})},s.id))}),e.jsxs("a",{className:"apostila-library-link",href:"#biblioteca",children:["Ver todas as apostilas na Biblioteca ",e.jsx(T,{size:14})]})]}):null}function Ii(){return e.jsxs("section",{className:"pdf-materials family-library","aria-labelledby":"family-library-title",children:[e.jsx("div",{className:"eyebrow",children:"ACOLHER TAMBÉM É CUIDAR"}),e.jsx("h2",{id:"family-library-title",children:"Folheto para familiares"}),e.jsx("p",{className:"pdf-intro",children:"Material próprio para entregar à família após validação da enfermeira responsável e da instituição. Os familiares não precisam instalar o aplicativo."}),e.jsx("div",{className:"pdf-grid",children:Ze.map(a=>e.jsxs("article",{className:"pdf-card",id:`material-${a.id}`,tabIndex:-1,"aria-label":a.title,children:[e.jsxs("div",{className:"pdf-card-top",children:[e.jsx("span",{className:"pdf-icon",children:e.jsx(Ya,{size:25,"aria-hidden":"true"})}),e.jsx("span",{className:"pdf-tag",children:"VALIDAÇÃO INSTITUCIONAL PENDENTE"})]}),e.jsx("h3",{children:a.title}),e.jsx("p",{children:a.description}),e.jsxs("div",{className:"pdf-actions",children:[e.jsxs("a",{className:"button",href:a.href,target:"_blank",rel:"noopener noreferrer","aria-label":`Abrir PDF: ${a.title} (outra aba ou visualizador do aparelho)`,children:["Abrir PDF ",e.jsx(T,{size:16,"aria-hidden":"true"})]}),e.jsxs("a",{className:"pdf-open",href:a.href,download:a.filename,children:[e.jsx(pe,{size:16,"aria-hidden":"true"}),"Baixar PDF"]})]}),e.jsxs("a",{className:"institutional-link",href:"#acolher-familia/material",children:["Ver prévia e orientações de impressão ",e.jsx(R,{size:16,"aria-hidden":"true"})]}),e.jsx(V,{contentId:`pdf.${a.id}`,compact:!0})]},a.id))})]})}const Ri={eva:eo,bps:me,painad:Ca,rass:Ja},Ha="/materiais/caderno-cti-adulto-digital.pdf";function zi({initialScale:a,renderFavorite:o,scaleIds:s,onRequestScale:n}={}){var E;const r=de.filter(c=>!s||s.includes(c.id)),i=r.length?r:de,t=i.map(c=>c.id).join(","),[u,m]=d.useState(((E=i.find(c=>c.id===a))==null?void 0:E.id)??i[0].id),h=d.useRef([]),f=d.useId(),C=i.find(c=>c.id===u)??i[0],b=c=>`${f}-tab-${c}`,A=c=>`${f}-panel-${c}`;d.useEffect(()=>{var c;m(((c=i.find(l=>l.id===a))==null?void 0:c.id)??i[0].id)},[a,t]);function y(c,l=!1){var N;const p=i[c];p&&(m(p.id),l&&((N=h.current[c])==null||N.focus()))}function j(c,l){let p;switch(c.key){case"ArrowRight":p=(l+1)%i.length;break;case"ArrowLeft":p=(l+i.length-1)%i.length;break;case"Home":p=0;break;case"End":p=i.length-1;break;default:return}c.preventDefault(),y(p,!0)}function q(c){var p;const l=i.findIndex(N=>N.id===c);if(l<0){n?n(c):window.location.hash=`escalas/${c}`;return}y(l,!0),(p=h.current[l])==null||p.scrollIntoView({block:"nearest",inline:"nearest",behavior:"instant"})}return e.jsxs("div",{className:"scales-guide",children:[e.jsx("p",{className:"scales-intro",children:"EVA, BPS e PAINAD avaliam dor em perfis diferentes de pacientes. A RASS descreve agitação e sedação. Selecione uma aba para conhecer cada instrumento."}),e.jsx("div",{className:"scales-tabs",role:"tablist","aria-label":"Escolha uma escala",children:i.map((c,l)=>{const p=Ri[c.id]??me;return e.jsxs("button",{type:"button",role:"tab",id:b(c.id),"aria-controls":A(c.id),"aria-selected":C.id===c.id,tabIndex:C.id===c.id?0:-1,ref:N=>{h.current[l]=N},onClick:()=>y(l),onKeyDown:N=>j(N,l),children:[e.jsx(p,{size:21,"aria-hidden":"true"}),e.jsxs("span",{children:[e.jsx("strong",{children:c.label}),e.jsx("span",{children:c.category})]})]},c.id)})}),i.map(c=>e.jsx("div",{role:"tabpanel",id:A(c.id),"aria-labelledby":b(c.id),hidden:C.id!==c.id,tabIndex:0,className:"scales-tabpanel",children:C.id===c.id&&e.jsxs(e.Fragment,{children:[e.jsxs("section",{className:"scales-overview","aria-labelledby":`${f}-name-${c.id}`,children:[e.jsxs("div",{className:"scales-overview-heading",children:[e.jsxs("div",{children:[e.jsx("span",{className:"scales-category",children:c.category}),e.jsx("h2",{id:`${f}-name-${c.id}`,children:c.name})]}),c.range&&e.jsxs("div",{className:"scales-range",children:[e.jsx("span",{children:c.range.label}),e.jsxs("strong",{children:[c.range.min," a ",c.range.max]})]})]}),e.jsx("p",{children:c.purpose}),o==null?void 0:o(c.id),e.jsx(V,{contentId:`scale.${c.id}`,compact:!0}),c.id.toLowerCase()==="eva"&&e.jsxs("figure",{className:"scales-eva-example",children:[e.jsxs("div",{role:"img","aria-label":"Linha ilustrativa da EVA: de sem dor a pior dor imaginável, sem medida real na tela.",children:[e.jsx("div",{className:"scales-eva-line","aria-hidden":"true"}),e.jsxs("div",{className:"scales-eva-labels","aria-hidden":"true",children:[e.jsx("span",{children:"Sem dor"}),e.jsx("span",{children:"Pior dor imaginável"})]})]}),e.jsx("figcaption",{children:"Ilustração sem medida real na tela"})]})]}),c.criteria&&e.jsxs("section",{className:"scales-card scales-criteria","aria-labelledby":`${f}-criteria-${c.id}`,children:[e.jsx("h3",{id:`${f}-criteria-${c.id}`,children:"Itens e critérios da escala"}),e.jsx("p",{className:"scales-criteria-intro",children:c.criteria.intro}),e.jsxs("p",{className:"scales-criteria-method",children:[e.jsx("strong",{children:"Como a leitura é formada:"})," ",c.criteria.method]}),c.criteria.steps&&e.jsx("ol",{className:"scales-criteria-steps",children:c.criteria.steps.map((l,p)=>e.jsxs("li",{children:[e.jsx("strong",{children:l.title}),e.jsx("p",{children:l.detail})]},p))}),c.criteria.domains&&e.jsx("div",{className:"scales-domains",children:c.criteria.domains.map((l,p)=>{const N=l.levels.map(x=>x.points);return e.jsxs("details",{className:"scales-domain",open:p===0,children:[e.jsxs("summary",{children:[e.jsxs("span",{children:[e.jsx("strong",{children:l.title}),e.jsxs("span",{children:[Math.min(...N)," a ",Math.max(...N)," pontos"]})]}),e.jsx(Za,{size:20,"aria-hidden":"true"})]}),e.jsxs("div",{className:"scales-domain-content",children:[e.jsxs("table",{className:"scales-domain-table",children:[e.jsxs("caption",{className:"sr-only",children:[c.label,": pontos e critérios de ",l.title]}),e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{scope:"col",children:"Pontos"}),e.jsx("th",{scope:"col",children:"Critério"})]})}),e.jsx("tbody",{children:l.levels.map(x=>e.jsxs("tr",{children:[e.jsx("th",{scope:"row",children:e.jsx("span",{className:"scales-domain-points",children:x.points})}),e.jsx("td",{children:x.criterion})]},x.points))})]}),e.jsxs("a",{className:"scales-domain-source",href:`${Ha}#page=${l.page}`,target:"_blank",rel:"noopener noreferrer",children:["Conferir na página ",l.page," do caderno ",e.jsx(T,{size:16,"aria-hidden":"true"})]})]})]},l.id)})}),c.criteria.example&&e.jsxs("div",{className:"scales-criteria-example",children:[e.jsx("h4",{children:"Exemplo para estudo"}),e.jsx("p",{children:c.criteria.example})]})]}),c.levelGuide&&e.jsxs("section",{className:"scales-card scales-levels","aria-labelledby":`${f}-levels-${c.id}`,children:[e.jsx("h3",{id:`${f}-levels-${c.id}`,children:"Pontuações descritas na escala"}),e.jsx("dl",{children:c.levelGuide.map(l=>e.jsxs("div",{className:"scales-level",children:[e.jsxs("dt",{children:[e.jsx("span",{className:"scales-score",children:l.score}),e.jsx("strong",{children:l.label})]}),e.jsx("dd",{children:l.description})]},l.score))})]}),e.jsxs("div",{className:"scales-content-grid",children:[e.jsxs("section",{className:"scales-card","aria-labelledby":`${f}-when-${c.id}`,children:[e.jsx("span",{className:"scales-section-index","aria-hidden":"true",children:"01"}),e.jsx("h3",{id:`${f}-when-${c.id}`,children:"Quando utilizar"}),e.jsx("ul",{children:c.when.map((l,p)=>e.jsx("li",{children:l},p))})]}),e.jsxs("section",{className:"scales-card","aria-labelledby":`${f}-measures-${c.id}`,children:[e.jsx("span",{className:"scales-section-index","aria-hidden":"true",children:"02"}),e.jsx("h3",{id:`${f}-measures-${c.id}`,children:"O que a escala avalia"}),e.jsx("dl",{className:"scales-measures",children:c.measures.map((l,p)=>e.jsxs("div",{children:[e.jsx("dt",{children:l.title}),e.jsx("dd",{children:l.detail})]},p))})]}),e.jsxs("section",{className:"scales-card","aria-labelledby":`${f}-read-${c.id}`,children:[e.jsx("span",{className:"scales-section-index","aria-hidden":"true",children:"03"}),e.jsx("h3",{id:`${f}-read-${c.id}`,children:"Como interpretar a leitura"}),e.jsx("ul",{children:c.howToRead.map((l,p)=>e.jsx("li",{children:l},p))})]}),e.jsxs("section",{className:"scales-card scales-care","aria-labelledby":`${f}-care-${c.id}`,children:[e.jsx("span",{className:"scales-section-index","aria-hidden":"true",children:"04"}),e.jsx("h3",{id:`${f}-care-${c.id}`,children:"Cuidados na avaliação"}),e.jsx("ul",{children:c.care.map((l,p)=>e.jsx("li",{children:l},p))})]})]}),e.jsxs("section",{className:"scales-card scales-sources","aria-labelledby":`${f}-sources-${c.id}`,children:[e.jsxs("div",{className:"scales-sources-title",children:[e.jsx(D,{size:23,"aria-hidden":"true"}),e.jsx("h3",{id:`${f}-sources-${c.id}`,children:"Fontes e leitura complementar"})]}),e.jsx("ul",{children:c.references.map(l=>e.jsx("li",{children:e.jsxs("a",{...K(l.href),children:[e.jsx("span",{children:l.label}),e.jsx(T,{size:18,"aria-hidden":"true"}),K(l.href).target&&e.jsx("span",{className:"sr-only",children:" (abre em nova aba)"})]})},l.id))}),c.sourcePages.length>0&&e.jsxs("div",{className:"scales-caderno-links",children:[e.jsx("span",{children:"No caderno do projeto:"}),c.sourcePages.map(l=>e.jsxs("a",{href:`${Ha}#page=${l}`,target:"_blank",rel:"noopener noreferrer",children:["Página ",l,e.jsx(T,{size:16,"aria-hidden":"true"}),e.jsx("span",{className:"sr-only",children:" do PDF (abre em outra aba)"})]},l))]})]})]})},c.id)),e.jsxs("section",{className:"scales-comparison","aria-labelledby":`${f}-compare`,children:[e.jsxs("div",{className:"scales-comparison-heading",children:[e.jsx("span",{className:"scales-category",children:"PARA COMPARAR"}),e.jsx("h2",{id:`${f}-compare`,children:"O que muda entre as escalas?"})]}),e.jsx("div",{className:"scales-comparison-grid",children:Bo.map(c=>e.jsxs("article",{className:"scales-comparison-card",children:[e.jsx("h3",{children:c.label}),e.jsxs("dl",{children:[e.jsxs("div",{children:[e.jsx("dt",{children:"Avalia"}),e.jsx("dd",{children:c.assesses})]}),e.jsxs("div",{children:[e.jsx("dt",{children:"Para quem"}),e.jsx("dd",{children:c.population})]}),e.jsxs("div",{children:[e.jsx("dt",{children:"Como observar"}),e.jsx("dd",{children:c.report})]})]}),e.jsxs("button",{type:"button",onClick:()=>q(c.id),"aria-label":`Consultar ${c.label}`,children:["Consultar ",c.label,e.jsx(R,{size:17,"aria-hidden":"true"})]})]},c.id))}),e.jsx("p",{className:"scales-study-note",children:"Escolha uma aba para conhecer a finalidade, a leitura e os cuidados de cada instrumento."})]}),e.jsxs("span",{className:"sr-only",role:"status","aria-live":"polite","aria-atomic":"true",children:["Escala selecionada: ",C.label,"."]})]})}const ca=a=>a==="rass"?"sedacao":["eva","bps","painad"].includes(a??"")?"dor":["consciencia","escala-de-coma-de-glasgow"].includes(a??"")?"consciencia":"todas",Ga=[{id:"todas",label:"Todas as finalidades",icon:Eo},{id:"dor",label:"Dor",icon:Ne},{id:"sedacao",label:"Sedação e agitação",icon:me},{id:"consciencia",label:"Nível de consciência",icon:Ja}],ki=["eva","bps","painad"],Ti=["rass"];function wi({initialScale:a,renderFavorite:o,onOpenGlasgow:s}){var C,b;const n=ii(a)??a,[r,i]=d.useState(()=>ca(n)),[t,u]=d.useState(n),m=d.useId();d.useEffect(()=>{i(ca(n)),u(n)},[n]);function h(A){i(ca(A)),u(A)}const f=(C=k.find(A=>A.id==="escalas"))==null?void 0:C.topics.find(A=>A.title.includes("Glasgow"));return e.jsxs("section",{className:"scale-purpose-guide","aria-labelledby":`${m}-title`,children:[e.jsx("h2",{id:`${m}-title`,children:"Estudar escalas por finalidade"}),e.jsx("p",{className:"institutional-description",children:"Escolha o assunto que deseja estudar. Este seletor organiza materiais educativos; não avalia pacientes nem decide condutas."}),e.jsx("div",{className:"scale-purpose-options",role:"group","aria-label":"Finalidade da escala",children:Ga.map(A=>{const y=A.icon;return e.jsxs("button",{type:"button","aria-pressed":r===A.id,onClick:()=>i(A.id),children:[e.jsx(y,{size:19,"aria-hidden":"true"}),A.label]},A.id)})}),e.jsxs("p",{className:"institutional-selection",role:"status",children:["Finalidade selecionada: ",(b=Ga.find(A=>A.id===r))==null?void 0:b.label,"."]}),r!=="consciencia"&&e.jsx(zi,{initialScale:t,onRequestScale:h,renderFavorite:o,scaleIds:r==="dor"?ki:r==="sedacao"?Ti:void 0}),(r==="consciencia"||r==="todas")&&f&&e.jsxs("article",{className:"institutional-card glasgow-introduction",children:[e.jsx("span",{className:"institutional-eyebrow",children:"NÍVEL DE CONSCIÊNCIA · INTRODUÇÃO"}),e.jsx("h2",{children:f.title}),e.jsx("p",{children:f.purpose}),e.jsx("p",{children:f.care}),e.jsx("p",{className:"institutional-review-note",children:f.risk}),e.jsx("p",{children:"O tópico existente é introdutório. A versão completa do instrumento e seus critérios precisam de revisão profissional antes de uso assistencial. Não há cálculo de pontuação nesta tela."}),s?e.jsxs("button",{type:"button",className:"institutional-link institutional-topic-button",onClick:s,children:["Explorar o conteúdo de Glasgow ",e.jsx(R,{size:17,"aria-hidden":"true"})]}):e.jsxs("a",{className:"institutional-link",href:"#escalas/escala-de-coma-de-glasgow",children:["Explorar o conteúdo de Glasgow ",e.jsx(R,{size:17,"aria-hidden":"true"})]})]})]})}const Me="cti-learning-profile-v1";function ea(a){return a==="estagiario"||a==="colaborador"}function Ua(){try{const a=JSON.parse(localStorage.getItem(Me)??"null");return ea(a)?a:null}catch{return null}}function Oi(a){if(a!==null&&!ea(a))return!1;try{return a===null?localStorage.removeItem(Me):localStorage.setItem(Me,JSON.stringify(a)),!0}catch{return!1}}const Di={estagiario:"Sou estagiário",colaborador:"Sou novo colaborador"},Fi={estagiario:[{title:"Meu primeiro dia",description:"Conheça a equipe e acompanhe sua ambientação com o preceptor.",href:"#primeiro-dia"},{title:"Equipamentos e dispositivos",description:"Reconheça as partes e leve suas dúvidas à equipe.",href:"#equipamentos"},{title:"Siglário",description:"Consulte as siglas e os termos dos materiais do projeto.",href:"#glossario"},{title:"Casos simulados",description:"Pratique segurança, comunicação e registros com situações fictícias.",href:"#quiz"}],colaborador:[{title:"Minha integração",description:"Organize os pontos a conhecer com a equipe do setor.",href:"#integracao"},{title:"Rotina e passagem de plantão",description:"Revise comunicação e continuidade do cuidado.",href:"#rotinas"},{title:"Equipamentos do cuidado",description:"Reconheça recursos e confirme o treinamento aplicável com a equipe.",href:"#equipamentos"},{title:"Registros de enfermagem",description:"Reveja os exemplos educativos e as orientações de registro.",href:"#registros"}]},uo=d.createContext(void 0);function Li({children:a}){const[o,s]=d.useState(Ua),[n,r]=d.useState(!0),i=d.useCallback(u=>{u!==null&&!ea(u)||(s(u),r(Oi(u)))},[]),t=d.useCallback(()=>i(null),[i]);return d.useEffect(()=>{const u=m=>{(m.key===Me||m.key===null)&&s(Ua())};return window.addEventListener("storage",u),()=>window.removeEventListener("storage",u)},[]),e.jsx(uo.Provider,{value:{profile:o,chooseProfile:i,saved:n,resetProfile:t},children:a})}function Ma(){const a=d.useContext(uo);if(!a)throw new Error("O perfil precisa de LearningProfileProvider.");return a}function ba({compact:a=!1}){const{profile:o,chooseProfile:s,saved:n}=Ma(),r=d.useId(),i=n?"A escolha fica apenas neste navegador. Não exige cadastro e pode ser alterada a qualquer momento.":"O navegador não permitiu guardar a escolha. O perfil funciona nesta sessão; você pode escolher novamente ao retornar.";return a?e.jsxs("div",{className:"profile-compact",children:[e.jsx("label",{htmlFor:`${r}-compact`,className:"profile-sr-only",children:"Perfil de aprendizagem"}),e.jsxs("select",{id:`${r}-compact`,value:o??"","aria-label":"Perfil de aprendizagem",onChange:t=>s(ea(t.target.value)?t.target.value:null),children:[e.jsx("option",{value:"",children:"Explorar os dois perfis"}),e.jsx("option",{value:"estagiario",children:"Sou estagiário"}),e.jsx("option",{value:"colaborador",children:"Sou novo colaborador"})]}),!n&&e.jsx("span",{className:"profile-compact-warning",role:"status",children:"Somente nesta sessão: não foi possível salvar."})]}):e.jsxs("section",{className:"profile-chooser","aria-labelledby":`${r}-title`,children:[e.jsx("h2",{id:`${r}-title`,children:"Como você está chegando à CTI?"}),e.jsx("p",{children:"Escolha seu ponto de partida. Os conteúdos gerais continuam disponíveis para os dois públicos."}),e.jsxs("div",{className:"profile-options",role:"group","aria-label":"Escolher perfil de aprendizagem",children:[e.jsxs("button",{type:"button",className:`profile-option${o==="estagiario"?" is-selected":""}`,"aria-pressed":o==="estagiario",onClick:()=>s("estagiario"),children:[e.jsx(fe,{size:25,"aria-hidden":"true"}),e.jsxs("span",{children:[e.jsx("strong",{children:"Sou estagiário"}),e.jsx("span",{children:"Primeiro dia, orientação com o preceptor e bases para o estágio."})]})]}),e.jsxs("button",{type:"button",className:`profile-option${o==="colaborador"?" is-selected":""}`,"aria-pressed":o==="colaborador",onClick:()=>s("colaborador"),children:[e.jsx(ao,{size:25,"aria-hidden":"true"}),e.jsxs("span",{children:[e.jsx("strong",{children:"Sou novo colaborador"}),e.jsx("span",{children:"Ambientação, comunicação e organização da integração ao setor."})]})]})]}),e.jsxs("div",{className:"profile-chooser-bottom",children:[e.jsx("button",{type:"button",className:"profile-explore",onClick:()=>s(null),"aria-pressed":o===null,children:"Explorar sem escolher perfil"}),e.jsx("p",{role:"status",children:i})]})]})}function Vi(){const{profile:a}=Ma(),o=d.useId(),s=d.useRef(a),n=d.useRef(null);return d.useEffect(()=>{var r;a&&a!==s.current&&((r=n.current)==null||r.focus()),s.current=a},[a]),a?e.jsxs("section",{className:"profile-welcome","aria-labelledby":`${o}-welcome`,children:[e.jsxs("div",{className:"profile-welcome-heading",children:[e.jsxs("div",{children:[e.jsx("span",{className:"profile-eyebrow",children:"SEU PONTO DE PARTIDA"}),e.jsx("h2",{ref:n,tabIndex:-1,id:`${o}-welcome`,children:Di[a]}),e.jsx("p",{children:"Estes atalhos priorizam sua chegada. Todos os módulos abaixo continuam disponíveis."})]}),e.jsxs("a",{className:"profile-change-link",href:"#perfil",children:["Trocar perfil ",e.jsx(R,{size:17,"aria-hidden":"true"})]})]}),e.jsx("ul",{className:"profile-recommendations",children:Fi[a].map(r=>e.jsx("li",{children:e.jsxs("a",{href:r.href,children:[e.jsx("strong",{children:r.title}),e.jsx("span",{children:r.description}),e.jsx(R,{size:17,"aria-hidden":"true"})]})},r.href))})]}):e.jsx(ba,{})}const Ia="cti-book-page-v1",$i=["cti-first-day-v1","cti-favorites-v1",Ia,"cti-visited",Me,qe];function Ie(a,o){try{const s=JSON.parse(localStorage.getItem(a)??"[]");if(!Array.isArray(s))return[];const n=new Set(o);return[...new Set(s.filter(r=>typeof r=="string"&&n.has(r)))]}catch{return[]}}function Ra(a,o){try{const s=[...new Set(o.filter(n=>typeof n=="string"&&n.length>0))];return localStorage.setItem(a,JSON.stringify(s)),!0}catch{return!1}}function Bi(a){if(!Number.isSafeInteger(a)||a<1)return 1;try{const o=JSON.parse(localStorage.getItem(Ia)??"null");return typeof o=="number"&&Number.isSafeInteger(o)&&o>=1&&o<=a?o:1}catch{return 1}}function Rs(a){if(!Number.isSafeInteger(a)||a<1)return!1;try{return localStorage.setItem(Ia,JSON.stringify(a)),!0}catch{return!1}}function Hi(){let a=!0;for(const o of $i)try{localStorage.removeItem(o)}catch{a=!1}return a}const _a=Z.map(a=>a.id);function Gi(){const[a,o]=d.useState(()=>Ie(qe,_a)),[s,n]=d.useState(!1),r=d.useId(),i=d.useRef(null);d.useEffect(()=>{const u=m=>{(m.key===qe||m.key===null)&&o(Ie(qe,_a))};return window.addEventListener("storage",u),()=>window.removeEventListener("storage",u)},[]);const t=u=>{o(u),n(!Ra(qe,u))};return e.jsxs("section",{className:"integration-checklist","aria-labelledby":`${r}-title`,children:[e.jsxs("div",{className:"integration-intro",children:[e.jsx(Y,{size:26,"aria-hidden":"true"}),e.jsxs("div",{children:[e.jsx("h2",{id:`${r}-title`,children:"Minha ambientação no setor"}),e.jsx("p",{children:"Um roteiro educativo para organizar sua chegada com a equipe, incluindo quem já tem experiência em outra instituição."})]})]}),e.jsxs("div",{className:"integration-review",children:[e.jsx("strong",{children:"Pendente de validação institucional"}),e.jsx("p",{children:"Os itens são sugestões genéricas de ambientação. A equipe deve validar o roteiro e apresentar os fluxos locais autorizados. Concluir as marcações não representa treinamento obrigatório, certificação ou autorização para executar procedimentos."})]}),e.jsxs("div",{className:"integration-progress",children:[e.jsxs("div",{children:[e.jsxs("strong",{children:[a.length," de ",Z.length," itens marcados"]}),e.jsx("span",{children:"Progresso pessoal neste navegador."})]}),e.jsx("progress",{max:Z.length,value:a.length,"aria-label":"Itens marcados no roteiro de integração"})]}),e.jsx("p",{className:"integration-storage",role:"status",children:s?"Não foi possível guardar as marcações neste navegador. Elas funcionam nesta sessão, mas podem desaparecer ao sair.":"As marcações ficam somente neste navegador. Não são enviadas à instituição. Não informe dados de pacientes; o navegador pode apagar os dados locais."}),e.jsx("ol",{className:"integration-items",children:Z.map((u,m)=>{const h=a.includes(u.id);return e.jsxs("li",{className:h?"is-complete":"",children:[e.jsxs("label",{htmlFor:`${r}-${u.id}`,children:[e.jsx("input",{ref:m===0?i:void 0,id:`${r}-${u.id}`,type:"checkbox",checked:h,onChange:()=>t(h?a.filter(f=>f!==u.id):[...a,u.id])}),e.jsx("span",{className:"integration-number","aria-hidden":"true",children:String(m+1).padStart(2,"0")}),e.jsx("strong",{children:u.title}),h&&e.jsx(xe,{size:18,"aria-hidden":"true"})]}),e.jsxs("div",{className:"integration-item-content",children:[e.jsx("p",{children:u.detail}),e.jsxs("a",{href:u.href,children:["Revisar conteúdo relacionado ",e.jsx(R,{size:17,"aria-hidden":"true"})]}),e.jsxs("p",{className:"integration-source",children:["Base educativa: ",u.sourceLabel,"."]})]})]},u.id)})}),e.jsxs("div",{className:"integration-bottom",children:[a.length===Z.length&&e.jsx("p",{role:"status",children:"Roteiro marcado. Revise as dúvidas com a equipe e siga o processo de integração autorizado pela instituição."}),e.jsxs("button",{type:"button",onClick:()=>{var u;t([]),(u=i.current)==null||u.focus()},disabled:a.length===0,children:[e.jsx(he,{size:17,"aria-hidden":"true"})," Reiniciar checklist de integração"]})]}),e.jsxs("a",{className:"integration-student-link",href:"#primeiro-dia",children:["Consultar também o checklist do estagiário ",e.jsx(R,{size:17,"aria-hidden":"true"})]})]})}function Ui({initialScenario:a}){const o=v=>re.find(z=>z.id===v)??re[0],[s,n]=d.useState(()=>o(a).id),[r,i]=d.useState(""),[t,u]=d.useState(!1),[m,h]=d.useState([]),[f,C]=d.useState(0),b=d.useRef(null),A=d.useRef(null),y=d.useRef(null),j=d.useRef(null),q=d.useRef(a),E=d.useId(),c=o(s);d.useEffect(()=>{a!==q.current&&(q.current=a,n(o(a).id),i(""),h([]),u(!1),b.current="scenario",C(v=>v+1))},[a]),d.useEffect(()=>{const v=b.current;if(!v)return;b.current=null;const z=v==="scenario"?A.current:v==="review"?y.current:j.current;z==null||z.focus()},[f]);function l(v){n(o(v).id),i(""),h([]),u(!1),b.current="scenario",C(z=>z+1)}function p(){i(""),h([]),u(!1),b.current="editor",C(v=>v+1)}function N(){r.trim()&&(u(!0),b.current="review",C(v=>v+1))}function x(v){h(z=>z.includes(v)?z.filter(le=>le!==v):[...z,v])}return e.jsxs("section",{className:"annotation-lab","aria-label":"Laboratório de anotações de enfermagem",children:[e.jsxs("div",{className:"lab-intro",children:[e.jsx("span",{className:"lab-icon",children:e.jsx(Po,{size:27,"aria-hidden":"true"})}),e.jsxs("div",{children:[e.jsx("h2",{children:"Pratique uma anotação com dados fictícios"}),e.jsx("p",{children:"Leia os fatos, escreva e compare seu texto com uma rubrica de autorrevisão. Não há correção clínica automática nem certificação."})]})]}),e.jsxs("div",{className:"lab-privacy",id:`${E}-privacy`,children:[e.jsx("strong",{children:"Use somente os fatos do exercício."}),e.jsx("p",{children:"Não digite dados reais de pacientes, prontuários ou profissionais. O texto fica apenas nesta tela, não é salvo nem enviado e é apagado ao sair do laboratório ou trocar de cenário."})]}),e.jsxs("div",{className:"lab-panel",children:[e.jsxs("label",{className:"lab-selector",htmlFor:`${E}-scenario`,children:["Escolha um cenário fictício",e.jsx("select",{className:"lab-scenario-select",id:`${E}-scenario`,value:c.id,onChange:v=>l(v.target.value),"aria-describedby":`${E}-change-note`,children:re.map(v=>e.jsx("option",{value:v.id,children:v.title},v.id))})]}),e.jsx("p",{className:"lab-hint",id:`${E}-change-note`,children:"Trocar de cenário apaga a anotação e a autorrevisão atuais."}),e.jsxs("div",{className:"lab-scenario",children:[e.jsx("span",{className:"lab-tag",children:"SITUAÇÃO INTEIRAMENTE FICTÍCIA"}),e.jsx("h3",{ref:A,tabIndex:-1,children:c.title}),e.jsx("p",{children:c.goal}),e.jsx("h4",{children:"Fatos disponíveis"}),e.jsx("ol",{className:"lab-facts",children:c.facts.map(v=>e.jsx("li",{children:v.text},v.id))}),e.jsxs("div",{className:"lab-missing",children:[e.jsx("h4",{children:"O que o cenário não informa"}),e.jsx("ul",{children:c.missingData.map(v=>e.jsx("li",{children:v},v))}),e.jsx("p",{children:"Reconheça essas lacunas. Em um registro real, horários, identificação profissional e demais informações exigidas devem seguir a avaliação, a supervisão e as normas aplicáveis; aqui, não preencha dados que não foram fornecidos."})]})]}),e.jsx("label",{className:"lab-editor-label",htmlFor:`${E}-draft`,children:"Sua anotação do cenário fictício"}),e.jsx("p",{className:"lab-hint",id:`${E}-editor-help`,children:"Escreva apenas com base nos fatos acima. Limite de 2.500 caracteres. Não use este campo para uma anotação real."}),e.jsx("textarea",{className:"lab-editor",id:`${E}-draft`,ref:j,rows:7,maxLength:2500,value:r,"aria-describedby":`${E}-editor-help ${E}-privacy`,spellCheck:!0,onChange:v=>{i(v.target.value),h([]),u(!1)}}),e.jsxs("div",{className:"lab-actions",children:[e.jsx("button",{type:"button",className:"lab-button",disabled:!r.trim(),onClick:N,children:"Conferir meu texto"}),e.jsxs("button",{type:"button",className:"lab-button lab-reset",onClick:p,children:[e.jsx(he,{size:17,"aria-hidden":"true"}),"Limpar exercício"]})]}),e.jsx("p",{className:"lab-hint",children:"“Conferir meu texto” abre critérios para você revisar e um exemplo comentado. O aplicativo não analisa sua anotação."}),t&&e.jsxs("div",{className:"lab-review",children:[e.jsx("h3",{ref:y,tabIndex:-1,children:"Autorrevisão do seu texto"}),e.jsx("p",{children:"Compare seu texto com os fatos do cenário e marque manualmente os critérios que você considera atendidos. Se editar a anotação, a autorrevisão será reiniciada."}),e.jsxs("fieldset",{className:"lab-rubric",children:[e.jsx("legend",{children:"Rubrica de autoavaliação — cinco critérios"}),La.map(v=>e.jsxs("label",{className:"lab-rubric-item",children:[e.jsx("input",{type:"checkbox",checked:m.includes(v.id),onChange:()=>x(v.id),"aria-describedby":`${E}-${v.id}-help`}),e.jsxs("span",{children:[e.jsx("strong",{children:v.label}),e.jsx("span",{id:`${E}-${v.id}-help`,children:v.explanation})]})]},v.id))]}),e.jsxs("p",{className:"lab-self-count",role:"status",children:[m.length," de ",La.length," critérios assinalados nesta autorrevisão."]}),e.jsx("p",{children:"Essa contagem expressa somente sua conferência. Não é nota, avaliação de competência, certificação ou autorização para executar cuidados."}),e.jsxs("div",{className:"lab-example",children:[e.jsx("h4",{children:"Exemplo restrito aos fatos fornecidos"}),e.jsx("blockquote",{children:c.example}),e.jsx("p",{children:c.exampleComment}),e.jsx("p",{children:"Este é um exercício de escrita. O exemplo é incompleto para uso em prontuário e não deve ser copiado para um registro real."})]}),e.jsxs("div",{className:"lab-example lab-problematic",children:[e.jsx("h4",{children:"Compare: por que este exemplo precisa de revisão?"}),e.jsx("blockquote",{children:c.problematicExample}),e.jsx("p",{children:c.problematicComment})]}),e.jsx("p",{children:"Que informação faltou para produzir um registro completo? Leve a dúvida ao preceptor ou enfermeiro responsável, sem inventar a resposta."})]}),e.jsxs("div",{className:"lab-sources",children:[e.jsxs("h3",{children:[e.jsx(D,{size:19,"aria-hidden":"true"}),"Materiais usados neste exercício"]}),e.jsx("ul",{children:c.sourceRefs.map(v=>e.jsx("li",{children:v.href.startsWith("#")?e.jsx("a",{href:v.href,children:v.label}):e.jsxs("a",{...K(v.href),children:[v.label,e.jsx("span",{className:"sr-only",children:" — abre o PDF em outra aba"})]})},v.href))}),e.jsx("a",{href:c.relatedHref,children:"Revisar o módulo de anotações de enfermagem"}),e.jsx("p",{children:"Base: materiais educativos já fornecidos ao projeto. Revisão clínica e institucional pendente; não há validação profissional registrada."})]})]}),e.jsx(V,{contentId:`annotation.${c.id}`})]})}function S({number:a,x:o,y:s,line:n}){return e.jsxs("g",{className:"equipment-marker","aria-hidden":"true",children:[n&&e.jsx("path",{className:"equipment-leader",d:n}),e.jsx("circle",{cx:o,cy:s,r:"20"}),e.jsx("text",{x:o,y:s,dominantBaseline:"central",textAnchor:"middle",children:a})]})}function la({x:a=45,y:o=45,width:s=170,height:n=105}){return e.jsxs(e.Fragment,{children:[e.jsx("rect",{className:"equipment-body",x:a-10,y:o-10,width:s+20,height:n+30,rx:"12"}),e.jsx("rect",{className:"equipment-screen",x:a,y:o,width:s,height:n,rx:"6"}),e.jsx("path",{className:"equipment-trace",d:`M${a+10} ${o+n/2} h25 l9 -12 10 25 12 -43 13 58 11 -28 h${Math.max(10,s-103)}`})]})}function ua({x:a=35,y:o=40,scale:s=1}){return e.jsxs("g",{transform:`translate(${a} ${o}) scale(${s})`,children:[e.jsx("path",{className:"equipment-line",d:"M0 45 C30 10 37 5 55 30 M55 30 H90 M90 30 C108 5 116 10 145 45 M60 30 v-15 M85 30 v-15 M0 45 C7 90 34 111 71 121 C108 110 138 88 145 45 M71 121 v25"}),e.jsx("rect",{className:"equipment-body",x:"58",y:"62",width:"27",height:"18",rx:"5"})]})}function _i({kind:a}){switch(a){case"monitor":return e.jsxs(e.Fragment,{children:[e.jsx(la,{x:42,y:38,width:180,height:96}),e.jsx("path",{className:"equipment-outline",d:"M115 154 v22 h40 v-22 M95 182 h80"}),e.jsx("path",{className:"equipment-line",d:"M235 60 h22 c15 0 14 22 27 22"}),e.jsx("circle",{className:"equipment-body",cx:"300",cy:"88",r:"12"}),e.jsx("circle",{className:"equipment-body",cx:"276",cy:"116",r:"11"}),e.jsx("path",{className:"equipment-line",d:"M255 95 l13 14 M235 110 c25 0 24 44 45 44"}),e.jsx("rect",{className:"equipment-body",x:"279",y:"142",width:"37",height:"27",rx:"10"}),e.jsx("path",{className:"equipment-line",d:"M120 190 C124 207 183 211 208 194"}),e.jsx("rect",{className:"equipment-body",x:"215",y:"183",width:"82",height:"29",rx:"8"}),e.jsx(S,{number:1,x:37,y:24,line:"M49 40 L68 56"}),e.jsx(S,{number:2,x:317,y:31,line:"M309 49 L299 76"}),e.jsx(S,{number:3,x:329,y:151,line:"M310 151 L297 154"}),e.jsx(S,{number:4,x:318,y:210,line:"M300 204 L282 199"})]});case"ventilator":return e.jsxs(e.Fragment,{children:[e.jsx(la,{x:38,y:43,width:128,height:85}),e.jsx("path",{className:"equipment-outline",d:"M100 149 v56 M70 210 h70"}),e.jsx("circle",{className:"equipment-body",cx:"72",cy:"216",r:"7"}),e.jsx("circle",{className:"equipment-body",cx:"138",cy:"216",r:"7"}),e.jsx("path",{className:"equipment-tube",d:"M193 100 C215 94 230 99 230 123 V154 C230 177 292 179 292 146 V106"}),e.jsx("path",{className:"equipment-line",d:"M193 100 C215 94 230 99 230 123 V154 C230 177 292 179 292 146 V106"}),e.jsx("rect",{className:"equipment-body",x:"272",y:"87",width:"39",height:"24",rx:"7"}),e.jsx("rect",{className:"equipment-body",x:"204",y:"184",width:"83",height:"36",rx:"8"}),e.jsx("path",{className:"equipment-fill",d:"M223 194 v-16 h44 v16"}),e.jsx(S,{number:1,x:39,y:23,line:"M50 40 L67 55"}),e.jsx(S,{number:2,x:325,y:126,line:"M305 130 L292 137"}),e.jsx(S,{number:3,x:320,y:203,line:"M301 203 L287 203"})]});case"infusion":return e.jsxs(e.Fragment,{children:[e.jsx("path",{className:"equipment-outline",d:"M142 10 h48 M166 10 v210 M133 220 h65"}),e.jsx("rect",{className:"equipment-body",x:"68",y:"30",width:"62",height:"69",rx:"12"}),e.jsx("path",{className:"equipment-line",d:"M86 31 v-9 h27 v9 M99 99 v23"}),e.jsx("rect",{className:"equipment-fill",x:"75",y:"61",width:"48",height:"29",rx:"5"}),e.jsx("rect",{className:"equipment-body",x:"71",y:"131",width:"128",height:"75",rx:"10"}),e.jsx("rect",{className:"equipment-screen",x:"84",y:"142",width:"76",height:"35",rx:"4"}),e.jsx("circle",{className:"equipment-accent",cx:"177",cy:"160",r:"8"}),e.jsx("path",{className:"equipment-line",d:"M99 121 C221 117 242 136 240 157 V182 C240 199 286 205 298 184"}),e.jsx(S,{number:1,x:38,y:55,line:"M58 55 L70 55"}),e.jsx(S,{number:2,x:38,y:169,line:"M58 169 L73 169"}),e.jsx(S,{number:3,x:294,y:139,line:"M276 147 L241 157"})]});case"syringe":return e.jsxs(e.Fragment,{children:[e.jsx("rect",{className:"equipment-body",x:"37",y:"92",width:"266",height:"105",rx:"12"}),e.jsx("rect",{className:"equipment-screen",x:"63",y:"133",width:"99",height:"42",rx:"5"}),e.jsx("circle",{className:"equipment-accent",cx:"213",cy:"155",r:"9"}),e.jsx("rect",{className:"equipment-fill",x:"71",y:"56",width:"130",height:"38",rx:"5"}),e.jsx("path",{className:"equipment-outline",d:"M91 56 v38 M110 58 v14 M129 58 v14 M148 58 v14 M167 58 v14 M200 75 h44 M244 53 v43 M70 75 H48"}),e.jsx("rect",{className:"equipment-body",x:"243",y:"45",width:"31",height:"55",rx:"5"}),e.jsx(S,{number:1,x:117,y:24,line:"M117 44 L117 57"}),e.jsx(S,{number:2,x:311,y:61,line:"M291 65 L273 72"}),e.jsx(S,{number:3,x:197,y:214,line:"M188 197 L165 168"})]});case"suction":return e.jsxs(e.Fragment,{children:[e.jsx("rect",{className:"equipment-body",x:"34",y:"43",width:"82",height:"62",rx:"10"}),e.jsx("circle",{className:"equipment-outline",cx:"76",cy:"73",r:"19"}),e.jsx("path",{className:"equipment-outline",d:"M76 73 l10 -8"}),e.jsx("rect",{className:"equipment-body",x:"135",y:"93",width:"91",height:"112",rx:"14"}),e.jsx("path",{className:"equipment-outline",d:"M129 94 h103 M153 136 h23 M153 156 h23 M153 176 h23"}),e.jsx("path",{className:"equipment-line",d:"M232 75 C302 60 311 108 293 128 S277 180 322 190"}),e.jsx("rect",{className:"equipment-fill",x:"237",y:"39",width:"41",height:"24",rx:"8"}),e.jsx(S,{number:1,x:38,y:20,line:"M47 37 L58 48"}),e.jsx(S,{number:2,x:104,y:161,line:"M124 161 L137 161"}),e.jsx(S,{number:3,x:329,y:110,line:"M309 112 L300 118"}),e.jsx(S,{number:4,x:310,y:35,line:"M292 44 L277 51"})]});case"oxygen":return e.jsxs(e.Fragment,{children:[e.jsx("rect",{className:"equipment-body",x:"34",y:"39",width:"71",height:"73",rx:"9"}),e.jsx("circle",{className:"equipment-outline",cx:"70",cy:"75",r:"20"}),e.jsx("rect",{className:"equipment-body",x:"143",y:"31",width:"39",height:"124",rx:"12"}),e.jsx("path",{className:"equipment-outline",d:"M163 45 v91 M151 156 h24"}),e.jsx("circle",{className:"equipment-accent",cx:"163",cy:"111",r:"7"}),e.jsx(ua,{x:209,y:71,scale:.72}),e.jsx(S,{number:1,x:40,y:17,line:"M49 35 L58 49"}),e.jsx(S,{number:2,x:154,y:195,line:"M156 175 L162 151"}),e.jsx(S,{number:3,x:317,y:44,line:"M307 61 L289 90"})]});case"high-flow":return e.jsxs(e.Fragment,{children:[e.jsx(ua,{x:165,y:12,scale:.95}),e.jsx("path",{className:"equipment-tube",d:"M258 177 C269 201 220 217 197 192"}),e.jsx("path",{className:"equipment-line",d:"M258 177 C269 201 220 217 197 192"}),e.jsx("rect",{className:"equipment-body",x:"32",y:"104",width:"121",height:"105",rx:"12"}),e.jsx("rect",{className:"equipment-screen",x:"46",y:"117",width:"67",height:"34",rx:"4"}),e.jsx("rect",{className:"equipment-fill",x:"48",y:"169",width:"52",height:"31",rx:"8"}),e.jsx("path",{className:"equipment-outline",d:"M118 181 h19"}),e.jsx(S,{number:1,x:323,y:30,line:"M304 38 L276 47"}),e.jsx(S,{number:2,x:313,y:197,line:"M294 191 L261 182"}),e.jsx(S,{number:3,x:46,y:73,line:"M53 92 L65 106"})]});case"renal":return e.jsxs(e.Fragment,{children:[e.jsx(la,{x:39,y:37,width:117,height:78}),e.jsx("rect",{className:"equipment-body",x:"29",y:"137",width:"139",height:"57",rx:"9"}),e.jsx("path",{className:"equipment-outline",d:"M62 194 v20 M135 194 v20 M48 218 h101"}),e.jsx("rect",{className:"equipment-body",x:"232",y:"54",width:"55",height:"117",rx:"15"}),e.jsx("path",{className:"equipment-outline",d:"M240 71 h39 M240 151 h39 M248 78 v64 M259 78 v64 M270 78 v64"}),e.jsx("path",{className:"equipment-line equipment-line-accent",d:"M192 51 C214 19 309 23 311 63 V155 C312 187 213 192 195 168"}),e.jsx("path",{className:"equipment-line",d:"M192 90 C206 77 218 89 231 99 M287 130 C321 129 325 186 301 204"}),e.jsx(S,{number:1,x:35,y:18,line:"M44 36 L58 49"}),e.jsx(S,{number:2,x:223,y:217,line:"M232 198 L247 168"}),e.jsx(S,{number:3,x:330,y:76,line:"M312 84 L304 93"})]});case"venous":return e.jsxs(e.Fragment,{children:[e.jsx("rect",{className:"equipment-fill",x:"41",y:"113",width:"256",height:"94",rx:"22"}),e.jsx("rect",{className:"equipment-dressing",x:"119",y:"127",width:"105",height:"64",rx:"12"}),e.jsx("path",{className:"equipment-line",d:"M176 165 V93 C176 72 115 77 113 48 M176 110 C176 66 233 79 234 49"}),e.jsx("rect",{className:"equipment-body",x:"98",y:"30",width:"30",height:"26",rx:"5"}),e.jsx("rect",{className:"equipment-body",x:"219",y:"30",width:"30",height:"26",rx:"5"}),e.jsx("path",{className:"equipment-outline",d:"M156 153 h41 v18 h-41z"}),e.jsx(S,{number:1,x:173,y:24,line:"M153 27 L128 40"}),e.jsx(S,{number:2,x:274,y:117,line:"M259 129 L196 160"}),e.jsx(S,{number:3,x:65,y:148,line:"M85 151 L120 160"})]});case"urinary":return e.jsxs(e.Fragment,{children:[e.jsx("path",{className:"equipment-line",d:"M37 58 H104 C137 58 125 117 162 117 H221 V134"}),e.jsx("rect",{className:"equipment-dressing",x:"57",y:"39",width:"44",height:"38",rx:"8"}),e.jsx("rect",{className:"equipment-body",x:"164",y:"139",width:"116",height:"77",rx:"14"}),e.jsx("path",{className:"equipment-fill",d:"M173 180 H271 V204 Q271 208 265 208 H179 Q173 208 173 202z"}),e.jsx("path",{className:"equipment-outline",d:"M186 154 h24 M186 169 h24 M222 215 v12"}),e.jsx(S,{number:1,x:66,y:17,line:"M70 37 L75 42"}),e.jsx(S,{number:2,x:177,y:72,line:"M178 92 L179 117"}),e.jsx(S,{number:3,x:317,y:171,line:"M297 174 L279 177"})]});case"enteral":return e.jsxs(e.Fragment,{children:[e.jsx("rect",{className:"equipment-body",x:"38",y:"77",width:"42",height:"39",rx:"8"}),e.jsx("path",{className:"equipment-line",d:"M80 96 C113 96 103 58 145 58 H250 C305 58 308 192 264 196 H170"}),e.jsx("rect",{className:"equipment-dressing",x:"220",y:"33",width:"34",height:"54",rx:"7"}),e.jsx("path",{className:"equipment-outline",d:"M160 50 v16 M171 50 v16 M183 50 v16"}),e.jsx(S,{number:1,x:42,y:39,line:"M48 57 L57 79"}),e.jsx(S,{number:2,x:154,y:108,line:"M159 89 L168 66"}),e.jsx(S,{number:3,x:303,y:27,line:"M283 34 L253 48"})]});case"tube":return e.jsxs(e.Fragment,{children:[e.jsx("rect",{className:"equipment-body",x:"50",y:"48",width:"47",height:"40",rx:"5"}),e.jsx("path",{className:"equipment-tube",d:"M97 69 H167 C230 69 259 111 260 188"}),e.jsx("path",{className:"equipment-line",d:"M97 69 H167 C230 69 259 111 260 188"}),e.jsx("path",{className:"equipment-outline",d:"M145 58 v22 M157 58 v22 M169 58 v22"}),e.jsx("rect",{className:"equipment-dressing",x:"190",y:"61",width:"35",height:"70",rx:"8"}),e.jsx(S,{number:1,x:45,y:20,line:"M53 39 L64 52"}),e.jsx(S,{number:2,x:306,y:185,line:"M286 184 L263 178"}),e.jsx(S,{number:3,x:258,y:35,line:"M245 51 L222 73"})]});case"tracheostomy":return e.jsxs(e.Fragment,{children:[e.jsx("path",{className:"equipment-line",d:"M47 118 H98 M247 118 H308"}),e.jsx("path",{className:"equipment-line",d:"M47 133 H98 M247 133 H308"}),e.jsx("rect",{className:"equipment-body",x:"94",y:"87",width:"158",height:"74",rx:"20"}),e.jsx("rect",{className:"equipment-outline",x:"108",y:"109",width:"17",height:"30",rx:"5"}),e.jsx("rect",{className:"equipment-outline",x:"221",y:"109",width:"17",height:"30",rx:"5"}),e.jsx("path",{className:"equipment-tube",d:"M172 77 V144 C172 174 186 196 222 196"}),e.jsx("path",{className:"equipment-line",d:"M172 77 V144 C172 174 186 196 222 196"}),e.jsx("rect",{className:"equipment-body",x:"153",y:"51",width:"38",height:"30",rx:"5"}),e.jsx(S,{number:1,x:268,y:207,line:"M249 202 L219 193"}),e.jsx(S,{number:2,x:112,y:49,line:"M117 68 L128 88"}),e.jsx(S,{number:3,x:316,y:83,line:"M308 102 L299 119"})]});case"interfaces":return e.jsxs(e.Fragment,{children:[e.jsx(ua,{x:21,y:35,scale:.84}),e.jsx("path",{className:"equipment-body",d:"M236 67 C215 76 213 114 211 130 Q237 156 267 130 C264 112 264 79 246 67 Z"}),e.jsx("path",{className:"equipment-outline",d:"M225 84 l-20 -14 M254 84 l20 -14 M223 113 h7 M249 113 h7"}),e.jsx("path",{className:"equipment-line",d:"M239 142 V193"}),e.jsx(S,{number:1,x:47,y:24,line:"M54 43 L67 59"}),e.jsx(S,{number:2,x:305,y:95,line:"M286 103 L263 110"}),e.jsx(S,{number:3,x:164,y:205,line:"M144 201 L82 157"})]})}}function mo({moduleId:a,topicTitle:o}){const s=d.useId(),n=Xe.find(r=>r.moduleId===a&&r.topicTitle===o);return n?e.jsxs("figure",{className:"equipment-figure","aria-labelledby":`${s}-title`,children:[e.jsxs("figcaption",{children:[e.jsx("h3",{id:`${s}-title`,children:"Reconheça as partes"}),e.jsx("p",{children:"Esquema educativo, não representa modelo específico."})]}),e.jsxs("svg",{className:"equipment-diagram",viewBox:"0 0 360 240",role:"img","aria-labelledby":`${s}-svg-title ${s}-svg-description`,children:[e.jsx("title",{id:`${s}-svg-title`,children:`${n.topicTitle}: partes numeradas`}),e.jsx("desc",{id:`${s}-svg-description`,children:`${n.description} ${n.parts.map((r,i)=>`${i+1}: ${r.name}.`).join(" ")}`}),e.jsx(_i,{kind:n.kind})]}),e.jsx("p",{className:"equipment-description",children:n.description}),e.jsx("ol",{className:"equipment-parts","aria-label":`Legenda de ${n.topicTitle}`,children:n.parts.map((r,i)=>e.jsxs("li",{children:[e.jsx("span",{className:"equipment-part-number","aria-hidden":"true",children:i+1}),e.jsxs("div",{children:[e.jsx("strong",{children:r.name}),e.jsx("p",{children:r.detail})]})]},r.name))}),e.jsxs("div",{className:"equipment-attention",children:[e.jsx(Ca,{size:19,"aria-hidden":"true"}),e.jsxs("p",{children:[e.jsx("strong",{children:"Para observar com a equipe:"})," ",n.attention]})]}),e.jsxs("p",{className:"equipment-description",children:["Base: tópico “",n.topicTitle,"” do módulo ",a==="equipamentos"?"Equipamentos hospitalares":"Dispositivos",". O desenho é uma adaptação educativa original; a leitura abaixo complementa o estudo."]}),e.jsxs("a",{className:"equipment-source",...K(n.source.href),children:["Leitura complementar: ",n.source.label," ",e.jsx(T,{size:17,"aria-hidden":"true"}),e.jsx("span",{className:"sr-only",children:" (abre em outra aba)"})]}),e.jsx("p",{className:"equipment-review",children:"Desenho original para estudo · conteúdo e representação sujeitos à revisão clínica e institucional."})]}):null}function Qi(){return e.jsxs("svg",{className:"virtual-box-drawing",viewBox:"0 0 760 540","aria-hidden":"true",focusable:"false",children:[e.jsx("rect",{className:"virtual-room-floor",x:"17",y:"17",width:"726",height:"506",rx:"24"}),e.jsx("path",{className:"virtual-room-line",d:"M32 60 H728 M47 475 H713"}),e.jsx("rect",{className:"virtual-room-bed-base",x:"271",y:"136",width:"215",height:"267",rx:"22"}),e.jsx("rect",{className:"virtual-room-bed",x:"287",y:"119",width:"183",height:"267",rx:"18"}),e.jsx("rect",{className:"virtual-room-pillow",x:"305",y:"141",width:"146",height:"56",rx:"12"}),e.jsx("path",{className:"virtual-room-line",d:"M303 219 H453 M303 240 H453 M303 261 H453 M274 168 V313 M484 168 V313"}),e.jsx("path",{className:"virtual-room-bed-foot",d:"M299 399 V415 M459 399 V415 M287 416 H471"}),e.jsx("rect",{className:"virtual-room-equipment",x:"66",y:"66",width:"112",height:"77",rx:"12"}),e.jsx("rect",{className:"virtual-room-screen",x:"80",y:"79",width:"85",height:"47",rx:"5"}),e.jsx("path",{className:"virtual-room-line",d:"M122 145 V170 M98 171 H145"}),e.jsx("rect",{className:"virtual-room-equipment",x:"570",y:"65",width:"111",height:"79",rx:"12"}),e.jsx("rect",{className:"virtual-room-screen",x:"584",y:"78",width:"83",height:"46",rx:"5"}),e.jsx("path",{className:"virtual-room-line",d:"M601 149 V174 M652 149 V174 M591 175 H663"}),e.jsx("path",{className:"virtual-room-line",d:"M88 199 H159 M123 195 V295 M99 296 H148"}),e.jsx("rect",{className:"virtual-room-equipment",x:"100",y:"210",width:"45",height:"57",rx:"7"}),e.jsx("rect",{className:"virtual-room-screen",x:"109",y:"220",width:"27",height:"19",rx:"4"}),e.jsx("rect",{className:"virtual-room-equipment",x:"586",y:"201",width:"78",height:"72",rx:"15"}),e.jsx("circle",{className:"virtual-room-pillow",cx:"626",cy:"225",r:"12"}),e.jsx("path",{className:"virtual-room-line",d:"M609 248 H642"}),e.jsx("rect",{className:"virtual-room-equipment",x:"81",y:"333",width:"79",height:"70",rx:"15"}),e.jsx("path",{className:"virtual-room-line",d:"M99 350 H140 M99 364 H140 M99 378 H126"}),e.jsx("rect",{className:"virtual-room-equipment",x:"587",y:"332",width:"78",height:"71",rx:"15"}),e.jsx("path",{className:"virtual-room-line",d:"M606 351 H645 M606 365 H645 M606 379 H632"}),e.jsx("rect",{className:"virtual-room-equipment",x:"243",y:"438",width:"77",height:"63",rx:"14"}),e.jsx("rect",{className:"virtual-room-equipment",x:"440",y:"438",width:"77",height:"63",rx:"14"})]})}function Ki({station:a,returnTo:o,close:s}){const n=d.useRef(null),r=d.useRef(null),i=d.useId();return d.useEffect(()=>{var u;const t=n.current;return t==null||t.showModal(),(u=r.current)==null||u.focus(),()=>{t!=null&&t.open&&t.close(),o!=null&&o.isConnected&&o.focus({preventScroll:!0})}},[o]),e.jsx("dialog",{ref:n,className:"virtual-cti-dialog","aria-labelledby":i,onCancel:t=>{t.preventDefault(),s()},onClick:t=>{t.target===n.current&&s()},children:e.jsxs("div",{className:"virtual-dialog-content",children:[e.jsxs("div",{className:"virtual-dialog-heading",children:[e.jsxs("div",{children:[e.jsx("span",{className:"virtual-eyebrow",children:"EXPLORAÇÃO EDUCATIVA"}),e.jsx("h2",{ref:r,id:i,tabIndex:-1,children:a.title})]}),e.jsx("button",{className:"virtual-close",type:"button",onClick:s,"aria-label":"Fechar explicação",children:e.jsx(_e,{size:22,"aria-hidden":"true"})})]}),e.jsx("p",{className:"virtual-dialog-intro",children:"Conheça a finalidade e as partes no esquema já disponível no aplicativo. A cena não demonstra instalação, conexão ou ajuste do equipamento."}),e.jsx(mo,{moduleId:a.moduleId,topicTitle:a.topicTitle}),e.jsxs("div",{className:"virtual-dialog-actions",children:[e.jsxs("a",{href:Ye(a.moduleId,a.topicTitle),onClick:s,children:["Explorar assunto no módulo ",e.jsx(R,{size:17,"aria-hidden":"true"})]}),e.jsx("button",{type:"button",onClick:s,children:"Voltar ao box"})]})]})})}function Xi(){const[a,o]=d.useState(null),s=d.useRef(null),n=d.useId(),r=ne.find(t=>t.id===a);function i(t,u){s.current=u.currentTarget,o(t.id)}return e.jsxs("section",{className:"virtual-cti","aria-labelledby":`${n}-heading`,children:[e.jsxs("div",{className:"virtual-intro",children:[e.jsx("span",{className:"virtual-intro-icon",children:e.jsx(Mo,{size:25,"aria-hidden":"true"})}),e.jsxs("div",{children:[e.jsx("h2",{id:`${n}-heading`,children:"Explore um box fictício"}),e.jsx("p",{children:"Selecione um número na cena ou um item da lista para reconhecer equipamentos e dispositivos com a equipe."})]})]}),e.jsxs("div",{className:"virtual-context",children:[e.jsx(Ca,{size:21,"aria-hidden":"true"}),e.jsxs("p",{children:[e.jsx("strong",{children:"Ilustração para estudo."})," Não representa a planta de um hospital, um paciente ou uma montagem de equipamentos. As posições apenas organizam os oito itens; eles não descrevem um conjunto de dispositivos usado em uma pessoa."]})]}),e.jsxs("figure",{className:"virtual-box-figure",children:[e.jsxs("div",{className:"virtual-box-stage",role:"group","aria-label":"Box fictício com oito itens para explorar","aria-describedby":`${n}-scene-help`,children:[e.jsx(Qi,{}),e.jsx("span",{className:"virtual-scene-label","aria-hidden":"true",children:"Box fictício · leito vazio"}),ne.map((t,u)=>e.jsx("button",{className:"virtual-box-station",type:"button","data-station-id":t.id,style:{"--station-x":`${t.x}%`,"--station-y":`${t.y}%`},"aria-label":`Explorar ${t.title} no box`,"aria-haspopup":"dialog","aria-pressed":a===t.id,onClick:m=>i(t,m),children:e.jsx("span",{"aria-hidden":"true",children:u+1})},t.id))]}),e.jsx("figcaption",{id:`${n}-scene-help`,children:"Os números correspondem à lista abaixo. Use Tab para alcançar os botões e Enter ou Espaço para abrir uma explicação. A lista oferece as mesmas oito opções, sem depender da imagem."})]}),e.jsxs("div",{className:"virtual-list-heading",children:[e.jsx(Ro,{size:21,"aria-hidden":"true"}),e.jsx("h3",{children:"Os mesmos itens em lista"})]}),e.jsx("ol",{className:"virtual-station-list",children:ne.map((t,u)=>e.jsxs("li",{children:[e.jsxs("button",{type:"button","data-station-id":t.id,"aria-label":`Abrir ${t.title} na lista`,"aria-haspopup":"dialog","aria-pressed":a===t.id,onClick:m=>i(t,m),children:[e.jsx("span",{className:"virtual-list-number","aria-hidden":"true",children:u+1}),e.jsx("span",{children:t.title}),e.jsx(R,{size:18,"aria-hidden":"true"})]}),e.jsx("p",{children:t.description})]},t.id))}),e.jsx("p",{className:"virtual-review",children:"Conteúdo educativo baseado nos módulos e desenhos existentes. Revisão clínica e institucional pendente. O reconhecimento de um item não autoriza sua manipulação; a atuação depende das atribuições, capacitação e orientação da equipe."}),r&&e.jsx(Ki,{station:r,returnTo:s.current,close:()=>o(null)},r.id)]})}function Wi(){const a=d.useId();return e.jsxs("section",{className:"project-preparation project-overview","aria-labelledby":`${a}-title`,children:[e.jsxs("div",{className:"preparation-intro",children:[e.jsx(fe,{size:27,"aria-hidden":"true"}),e.jsxs("div",{children:[e.jsx("h2",{id:`${a}-title`,children:"Um projeto acadêmico de acolhimento e aprendizagem"}),e.jsx("p",{children:"Conhecendo a CTI integra um Projeto Baseado em Problemas (PBL) do curso Técnico em Enfermagem da Faculdade Moinhos de Vento."})]})]}),e.jsx("p",{children:"A proposta nasceu para apoiar estagiários que chegam à CTI Adulto. Durante o acompanhamento do estágio, foi identificada também a necessidade de ambientação de novos colaboradores de enfermagem, inclusive profissionais com experiência em outras instituições."}),e.jsx("p",{children:"O objetivo é organizar o acesso aos conteúdos educativos e ajudar cada pessoa a reconhecer o setor, formular dúvidas e conversar com a equipe. Esta versão foi preparada para demonstração e avaliação técnica de uma possível utilização institucional."}),e.jsxs("div",{className:"preparation-audiences",children:[e.jsxs("article",{children:[e.jsx(fe,{size:25,"aria-hidden":"true"}),e.jsx("h3",{children:"Sou estagiário"}),e.jsx("p",{children:"Primeiro dia, rotina, equipamentos, siglas, escalas, segurança, registros e discussão de situações fictícias com o preceptor."})]}),e.jsxs("article",{children:[e.jsx(ao,{size:25,"aria-hidden":"true"}),e.jsx("h3",{children:"Sou novo colaborador"}),e.jsx("p",{children:"Ambientação, organização do trabalho, comunicação, equipamentos e um roteiro de integração a ser contextualizado pela equipe responsável."})]})]}),e.jsx("p",{children:"Os dois perfis usam a mesma base. A escolha destaca prioridades e pode ser alterada; os conteúdos educativos gerais continuam acessíveis, sem cadastro."}),e.jsxs("div",{className:"preparation-card",children:[e.jsx("h3",{children:"O que você pode explorar"}),e.jsxs("ul",{children:[e.jsx("li",{children:"Busca por assunto e Siglário dentro do aplicativo."}),e.jsx("li",{children:"Checklists de ambientação, favoritos e retomada do caderno neste navegador."}),e.jsx("li",{children:"Equipamentos ilustrados, box fictício e guias educativos de escalas."}),e.jsx("li",{children:"Casos PBL, quiz e laboratório de anotações com fatos simulados."}),e.jsx("li",{children:"PDFs, referências e acompanhamento das pendências de revisão."})]})]}),e.jsxs("div",{className:"preparation-status",children:[e.jsx(Y,{size:24,"aria-hidden":"true"}),e.jsxs("div",{children:[e.jsx("strong",{children:"Demonstração educacional em avaliação"}),e.jsx("p",{children:"O aplicativo não representa uma publicação oficialmente adotada ou validada pelo Hospital Moinhos de Vento. Não utiliza logotipo ou identidade visual institucional. A revisão profissional e a autorização institucional do aplicativo permanecem pendentes."})]})]}),e.jsx("p",{children:"Os materiais servem ao estudo e à ambientação. Não substituem supervisão, protocolos aplicáveis ou orientação da equipe. Concluir checklists e exercícios não comprova treinamento institucional obrigatório, certificação ou autorização para executar procedimentos."}),e.jsxs("div",{className:"preparation-card preparation-credits",children:[e.jsx("h3",{children:"Participação, créditos e revisão"}),e.jsxs("dl",{children:[e.jsxs("div",{children:[e.jsx("dt",{children:"Participantes do projeto"}),e.jsx("dd",{children:"Nomes a confirmar pelo responsável."})]}),e.jsxs("div",{children:[e.jsx("dt",{children:"Orientação acadêmica"}),e.jsx("dd",{children:"Nomes e créditos a confirmar."})]}),e.jsxs("div",{children:[e.jsx("dt",{children:"Responsáveis pela revisão profissional"}),e.jsx("dd",{children:"A definir."})]}),e.jsxs("div",{children:[e.jsx("dt",{children:"Última revisão clínica do aplicativo"}),e.jsx("dd",{children:"Sem data de revisão registrada."})]})]}),e.jsx("p",{children:"Os créditos presentes nos documentos originais foram preservados. A atualização técnica do aplicativo não equivale à validação clínica desses materiais."})]}),e.jsxs("div",{className:"preparation-actions",children:[e.jsxs("a",{className:"preparation-button",href:"#demonstracao",children:["Iniciar demonstração guiada ",e.jsx(R,{size:17,"aria-hidden":"true"})]}),e.jsxs("a",{className:"preparation-link",href:"#conteudos",children:["Ver conteúdos e revisão ",e.jsx(R,{size:17,"aria-hidden":"true"})]})]})]})}function Ji(){const a=d.useId(),[o,s]=d.useState(!1),[n,r]=d.useState({}),[i,t]=d.useState(!1),[u,m]=d.useState(""),h=d.useRef(null),f=d.useRef(null),C=vi(n),b=Va(n,o);d.useEffect(()=>{var q;i&&((q=h.current)==null||q.focus())},[i]);function A(){var q;r({}),t(!1),s(!1),m("Respostas e concordância limpas desta tela. Uma cópia que você já baixou continua sob seu controle."),(q=f.current)==null||q.focus()}function y(q){var E;q.preventDefault(),b&&(t(!0),m("Resumo gerado somente nesta tela. Nenhuma resposta foi enviada."),(E=h.current)==null||E.focus())}function j(){const q=Va(n,o);if(!q||!i)return;let E;try{E=URL.createObjectURL(new Blob([JSON.stringify(q,null,2)],{type:"application/json;charset=utf-8"}));const c=document.createElement("a");c.href=E,c.download="avaliacao-pbl-respostas.json",document.body.append(c),c.click(),c.remove(),m("Arquivo de respostas criado no aparelho. Ele não foi enviado à equipe ou a um servidor.")}catch{m("O navegador não permitiu criar o arquivo. Seu resumo continua disponível nesta tela.")}finally{E&&setTimeout(()=>URL.revokeObjectURL(E),1e3)}}return e.jsxs("section",{className:"project-preparation pbl-feedback","aria-labelledby":`${a}-title`,children:[e.jsxs("div",{className:"preparation-intro",children:[e.jsx(Io,{size:27,"aria-hidden":"true"}),e.jsxs("div",{children:[e.jsx("h2",{id:`${a}-title`,children:"Como foi sua experiência?"}),e.jsx("p",{children:"Avaliação voluntária de usabilidade e aprendizagem percebida, para demonstração do PBL."})]})]}),e.jsxs("p",{children:["Este questionário educativo foi criado para o projeto. Ele registra sua percepção, não comprova aprendizagem objetiva ou competência clínica e não possui validação formal registrada. Versão do instrumento: ",He,"."]}),e.jsxs("div",{className:"preparation-card feedback-privacy",id:`${a}-privacy`,children:[e.jsx("h3",{children:"Você decide se quer responder"}),e.jsxs("ul",{children:[e.jsx("li",{children:"Não solicitamos nome, matrícula, e-mail ou dados de pacientes."}),e.jsx("li",{children:"As respostas ficam apenas na memória desta tela. Sair dela, recarregar ou usar “Limpar respostas” reinicia o questionário."}),e.jsx("li",{children:"Não há envio automático, banco de respostas ou acompanhamento remoto. Responder aqui não encaminha uma avaliação à equipe."}),e.jsx("li",{children:"Se você escolher baixar o arquivo, a cópia ficará em seu aparelho e você decidirá como guardá-la ou compartilhá-la."})]})]}),e.jsxs("label",{className:"feedback-consent",htmlFor:`${a}-consent`,children:[e.jsx("input",{ref:f,type:"checkbox",id:`${a}-consent`,checked:o,"aria-describedby":`${a}-privacy`,onChange:q=>{s(q.target.checked),m(""),q.target.checked||(r({}),t(!1))}}),e.jsx("span",{children:"Entendi que a participação é voluntária e que minhas respostas ficam somente nesta tela, sem envio automático."})]}),e.jsxs("form",{onSubmit:y,"aria-label":"Avaliação local do PBL",children:[e.jsxs("fieldset",{className:"feedback-questions",disabled:!o,children:[e.jsx("legend",{children:"Escolha uma resposta para cada afirmação"}),e.jsx("p",{children:"Use de 1 (discordo totalmente) a 5 (concordo totalmente), ou escolha “Não avaliei”. Você pode deixar de participar a qualquer momento."}),Se.map((q,E)=>e.jsxs("div",{className:"feedback-question",children:[e.jsxs("label",{htmlFor:`${a}-${q.id}`,children:[e.jsx("span",{className:"feedback-number","aria-hidden":"true",children:E+1}),e.jsx("span",{children:q.text})]}),e.jsxs("select",{id:`${a}-${q.id}`,required:!0,value:n[q.id]??"",onChange:c=>{const l=c.target.value;r(p=>{const N={...p};return Ea(l)?N[q.id]=l:delete N[q.id],N}),t(!1),m("")},children:[e.jsx("option",{value:"",children:"Escolha uma opção"}),ya.map(c=>e.jsx("option",{value:c.value,children:c.label},c.value))]})]},q.id))]}),e.jsxs("p",{className:"feedback-count",role:"status",children:[C," de ",Se.length," itens respondidos. “Não avaliei” também é uma resposta válida."]}),e.jsxs("div",{className:"preparation-actions",children:[e.jsx("button",{className:"preparation-button",type:"submit",disabled:!b,children:"Gerar meu resumo"}),e.jsxs("button",{className:"preparation-secondary",type:"button",onClick:A,disabled:!o&&C===0,children:[e.jsx(he,{size:17,"aria-hidden":"true"})," Limpar respostas"]})]})]}),i&&b&&e.jsxs("section",{className:"preparation-card feedback-summary","aria-labelledby":`${a}-summary`,children:[e.jsx("h3",{id:`${a}-summary`,ref:h,tabIndex:-1,children:"Meu resumo local"}),e.jsx("p",{children:"Confira as respostas que você escolheu. Não é calculada uma nota de aprendizagem ou certificação."}),e.jsx("dl",{children:Se.map(q=>e.jsxs("div",{children:[e.jsx("dt",{children:q.text}),e.jsx("dd",{children:xi(n[q.id])})]},q.id))}),e.jsxs("button",{className:"preparation-button",type:"button",onClick:j,children:[e.jsx(pe,{size:17,"aria-hidden":"true"})," Baixar minhas respostas"]}),e.jsx("p",{className:"preparation-small",children:"O arquivo contém somente a versão do instrumento e as respostas fechadas. Nenhum identificador, horário ou dado do aparelho é incluído."})]}),e.jsx("p",{className:"preparation-notice",role:"status","aria-live":"polite",children:u}),e.jsxs("details",{className:"preparation-details",children:[e.jsx("summary",{children:"O que precisa ser definido antes de uma coleta remota?"}),e.jsx("p",{children:"Uma eventual coleta centralizada depende de aprovação de uma proposta específica: finalidade, participação voluntária, consentimento, perguntas, responsável, local de armazenamento, prazo e procedimento de exclusão, controle de acesso e segurança. Esta demonstração não envia respostas e não cria esse serviço."})]})]})}let ma={index:0,viewed:[],finished:!1};function Zi(){const a=d.useId(),[o,s]=d.useState(()=>({...ma,viewed:[...ma.viewed]})),n=d.useRef(null),r=d.useRef(!1),i=G[o.index];d.useEffect(()=>{var m;ma={...o,viewed:[...o.viewed]},r.current&&((m=n.current)==null||m.focus(),r.current=!1)},[o]);function t(m){m<0||m>=G.length||(r.current=!0,s(h=>({...h,index:m,finished:!1})))}function u(){r.current=!0,s({index:0,viewed:[],finished:!1})}return e.jsxs("section",{className:"project-preparation guided-demo","aria-labelledby":`${a}-title`,children:[e.jsxs("div",{className:"preparation-intro",children:[e.jsx(ko,{size:27,"aria-hidden":"true"}),e.jsxs("div",{children:[e.jsx("h2",{id:`${a}-title`,children:"Demonstração guiada"}),e.jsx("p",{children:"Um roteiro de aproximadamente 5–8 minutos, no seu ritmo, para apresentar os dois públicos e os recursos educativos."})]})]}),e.jsx("p",{children:"Use somente cenários fictícios. As etapas vistas ficam apenas na memória desta aba; você pode voltar ao roteiro depois de explorar uma tela. Recarregar o aplicativo ou reiniciar esta demonstração limpa esse acompanhamento."}),e.jsxs("div",{className:"demo-progress",children:[e.jsxs("strong",{children:[o.viewed.length," de ",G.length," etapas marcadas como vistas"]}),e.jsx("progress",{value:o.viewed.length,max:G.length,"aria-label":"Etapas marcadas como vistas na demonstração"})]}),e.jsx("nav",{className:"demo-step-nav","aria-label":"Etapas da demonstração",children:G.map((m,h)=>e.jsxs("button",{type:"button","aria-label":`${h+1}. ${m.title}`,"aria-current":!o.finished&&h===o.index?"step":void 0,onClick:()=>t(h),children:[e.jsx("span",{children:h+1}),o.viewed.includes(m.id)&&e.jsx(xe,{size:15,"aria-hidden":"true"})]},m.id))}),o.finished?e.jsxs("div",{className:"preparation-card demo-complete",children:[e.jsx("h3",{ref:n,tabIndex:-1,children:"Demonstração percorrida"}),e.jsxs("p",{children:["Você marcou ",o.viewed.length," de ",G.length," etapas como vistas. Este acompanhamento é um roteiro de apresentação, não certificação, avaliação clínica ou registro de treinamento obrigatório."]}),e.jsx("p",{children:"Reúna as pendências de revisão e as observações da equipe responsável. A implantação institucional e qualquer coleta remota de avaliação dependem de decisões e autorizações próprias."}),e.jsxs("div",{className:"preparation-actions",children:[e.jsxs("button",{className:"preparation-button",type:"button",onClick:()=>t(0),children:["Rever etapas ",e.jsx(R,{size:17,"aria-hidden":"true"})]}),e.jsxs("button",{className:"preparation-secondary",type:"button",onClick:u,children:[e.jsx(he,{size:17,"aria-hidden":"true"})," Reiniciar demonstração"]})]})]}):e.jsxs("div",{className:"preparation-card demo-current",children:[e.jsxs("p",{className:"demo-step-number",children:["Etapa ",o.index+1," de ",G.length]}),e.jsx("h3",{ref:n,tabIndex:-1,children:i.title}),e.jsx("p",{className:"demo-purpose",children:i.purpose}),e.jsx("ol",{children:i.actions.map(m=>e.jsx("li",{children:m},m))}),e.jsx("div",{className:"demo-links",children:i.links.map(m=>e.jsxs("a",{className:"preparation-link",href:m.href,children:[m.label," ",e.jsx(R,{size:17,"aria-hidden":"true"})]},m.href))}),e.jsxs("label",{className:"demo-mark",htmlFor:`${a}-viewed`,children:[e.jsx("input",{id:`${a}-viewed`,type:"checkbox",checked:o.viewed.includes(i.id),onChange:m=>{const h=m.target.checked;s(f=>({...f,viewed:h?[...new Set([...f.viewed,i.id])]:f.viewed.filter(C=>C!==i.id)}))}}),e.jsx("span",{children:"Marcar esta etapa como vista"})]}),e.jsxs("div",{className:"demo-controls",children:[e.jsxs("button",{className:"preparation-secondary",type:"button",disabled:o.index===0,onClick:()=>t(o.index-1),children:[e.jsx(Le,{size:17,"aria-hidden":"true"})," Etapa anterior"]}),e.jsxs("button",{className:"preparation-button",type:"button",onClick:()=>{o.index+1<G.length?t(o.index+1):(r.current=!0,s(m=>({...m,finished:!0})))},children:[o.index+1===G.length?"Concluir demonstração":"Próxima etapa"," ",e.jsx(R,{size:17,"aria-hidden":"true"})]})]}),e.jsxs("button",{className:"preparation-link demo-restart",type:"button",onClick:u,children:[e.jsx(he,{size:17,"aria-hidden":"true"})," Reiniciar demonstração"]})]}),e.jsx("p",{className:"preparation-small",children:"O aplicativo é um projeto acadêmico educativo em avaliação. Conteúdos, referências e rotinas locais precisam de revisão e das autorizações aplicáveis antes de uso institucional."})]})}const Qa="cti-favorites-v1",Yi=ze.map(a=>a.id),ke=d.createContext({ids:[],saved:!0,toggle:a=>{},clear:()=>{}}),es=()=>d.useContext(ke);function as({children:a}){const[o,s]=d.useState(()=>co(Ie(Qa,mi))),[n,r]=d.useState(!0);function i(t){if(!Yi.includes(t))return;const u=o.includes(t)?o.filter(m=>m!==t):[...o,t];r(Ra(Qa,u)),s(u)}return e.jsx(ke.Provider,{value:{ids:o,saved:n,toggle:i,clear:()=>{s([]),r(!0)}},children:a})}function B({id:a}){const{ids:o,saved:s,toggle:n}=d.useContext(ke),r=ze.find(u=>u.id===a);if(!r)return null;const i=o.includes(a),t=i?Ao:Pe;return e.jsxs("div",{className:"favorite-control",children:[e.jsxs("button",{type:"button",className:`favorite-button${i?" is-saved":""}`,"aria-pressed":i,"aria-label":`${i?"Remover dos":"Adicionar aos"} favoritos: ${r.title}`,onClick:()=>n(a),children:[e.jsx(t,{size:17,"aria-hidden":"true"}),i?"Salvo":"Favoritar"]}),!s&&e.jsx("span",{role:"status",className:"learning-storage-note",children:"Salvo apenas nesta sessão; o navegador não permitiu guardar no aparelho."})]})}function os(){const{ids:a,saved:o}=d.useContext(ke),s=pi(a);return e.jsxs("section",{className:"favorites-page","aria-label":"Conteúdos favoritos",children:[e.jsx("p",{className:"learning-local-note",children:"Seus favoritos ficam somente neste navegador, sem cadastro. Limpar os dados do navegador remove essa lista."}),!o&&e.jsx("p",{role:"status",className:"learning-storage-note",children:"O navegador não permitiu salvar as alterações. A lista funciona enquanto você mantém esta sessão aberta."}),e.jsxs("p",{role:"status",className:"favorites-count",children:[s.length," ",s.length===1?"conteúdo salvo":"conteúdos salvos"]}),s.length?e.jsx("ul",{className:"favorites-list",children:s.map(n=>e.jsxs("li",{children:[e.jsxs("div",{children:[e.jsx("span",{children:n.kind}),e.jsxs("a",{href:n.href,children:[n.title,e.jsx(R,{size:17,"aria-hidden":"true"})]})]}),e.jsx(B,{id:n.id})]},n.id))}):e.jsxs("div",{className:"favorites-empty",children:[e.jsx(Pe,{size:30,"aria-hidden":"true"}),e.jsx("h2",{children:"Guarde o que você quer rever."}),e.jsx("p",{children:"Use “Favoritar” nos módulos, assuntos, escalas e termos do siglário."}),e.jsxs("a",{className:"button",href:"#modulos",children:["Explorar os módulos ",e.jsx(R,{size:17})]})]})]})}function is(){const{ids:a}=d.useContext(ke),o=Bi(96);return e.jsxs("section",{className:"learning-shortcuts","aria-labelledby":"learning-tools-title",children:[e.jsx("div",{className:"section-heading",children:e.jsxs("div",{children:[e.jsx("span",{className:"eyebrow",children:"PARA O SEU ESTÁGIO"}),e.jsx("h2",{id:"learning-tools-title",children:"Organize seu aprendizado"})]})}),e.jsxs("div",{className:"learning-shortcut-grid",children:[e.jsxs("a",{href:"#primeiro-dia",children:[e.jsx(Y,{size:24,"aria-hidden":"true"}),e.jsx("strong",{children:"Meu primeiro dia"}),e.jsx("span",{children:"Um roteiro para conhecer o setor com seu preceptor."}),e.jsxs("span",{className:"learning-shortcut-action",children:["Abrir checklist ",e.jsx(R,{size:17})]})]}),e.jsxs("a",{href:"#glossario",children:[e.jsx(fa,{size:24,"aria-hidden":"true"}),e.jsx("strong",{children:"Siglário"}),e.jsx("span",{children:"Consulte as 746 siglas e definições da lista enviada para o projeto."}),e.jsxs("span",{className:"learning-shortcut-action",children:["Consultar termos ",e.jsx(R,{size:17})]})]}),e.jsxs("a",{href:"#favoritos",children:[e.jsx(Pe,{size:24,"aria-hidden":"true"}),e.jsx("strong",{children:"Meus favoritos"}),e.jsx("span",{children:a.length?`${a.length} ${a.length===1?"conteúdo salvo":"conteúdos salvos"} neste navegador.`:"Guarde os assuntos que deseja consultar novamente."}),e.jsxs("span",{className:"learning-shortcut-action",children:["Ver favoritos ",e.jsx(R,{size:17})]})]})]}),o>1&&e.jsxs("a",{className:"continue-reading",href:"#caderno",children:[e.jsx(D,{size:22,"aria-hidden":"true"}),e.jsxs("span",{children:[e.jsx("strong",{children:"Continuar a leitura do caderno"}),e.jsxs("span",{children:["Retomar na página ",o," de 96"]})]}),e.jsx(R,{size:18,"aria-hidden":"true"})]})]})}function ss({route:a}){return e.jsxs("details",{className:"more-learning-tools",children:[e.jsx("summary",{children:"Mais ferramentas de aprendizagem"}),e.jsx("nav",{"aria-label":"Mais ferramentas",children:ae.map(o=>e.jsx("a",{href:o.href,"aria-current":o.href===`#${a}`?"page":void 0,children:o.title},o.id))})]})}function rs(){return e.jsxs("section",{className:"additional-learning-tools","aria-labelledby":"additional-tools-title",children:[e.jsx("div",{className:"section-heading",children:e.jsxs("div",{children:[e.jsx("span",{className:"eyebrow",children:"PRATIQUE E EXPLORE"}),e.jsx("h2",{id:"additional-tools-title",children:"Mais recursos para aprender"}),e.jsx("p",{children:"Explore os materiais e prepare suas dúvidas para conversar com a equipe."})]})}),e.jsx("div",{className:"additional-tool-grid",children:ae.filter(a=>a.id!=="tool.perfil").map(a=>e.jsxs("article",{className:"additional-tool-card",children:[e.jsxs("a",{href:a.href,children:[e.jsx("h3",{children:a.title}),e.jsx("p",{children:a.description}),e.jsxs("span",{className:"institutional-link",children:["Explorar recurso ",e.jsx(R,{size:17,"aria-hidden":"true"})]})]}),e.jsx(B,{id:a.id})]},a.id))})]})}const Fe="cti-first-day-v1",Ka=W.map(a=>a.id),ns="/materiais/caderno-cti-adulto-digital.pdf";function ts(){const[a,o]=d.useState(()=>Ie(Fe,Ka)),[s,n]=d.useState(!1),r=d.useId();d.useEffect(()=>{const t=u=>{(u.key===Fe||u.key===null)&&o(Ie(Fe,Ka))};return window.addEventListener("storage",t),()=>window.removeEventListener("storage",t)},[]);const i=t=>{o(t),n(!Ra(Fe,t))};return e.jsxs("section",{className:"starter-checklist","aria-labelledby":`${r}-heading`,children:[e.jsxs("div",{className:"starter-intro",children:[e.jsx(Y,{size:25,"aria-hidden":"true"}),e.jsxs("div",{children:[e.jsx("h2",{id:`${r}-heading`,children:"Meu primeiro dia na CTI"}),e.jsx("p",{children:"Use este roteiro para conversar com o preceptor e reconhecer o setor. Marque o que já foi apresentado a você."})]})]}),e.jsxs("div",{className:"starter-progress",children:[e.jsxs("div",{children:[e.jsxs("strong",{children:[a.length," de ",W.length," itens marcados"]}),e.jsx("span",{children:"Roteiro pessoal de integração; não certifica competência."})]}),e.jsx("progress",{value:a.length,max:W.length,"aria-label":"Itens marcados no roteiro do primeiro dia"})]}),e.jsx("p",{className:"starter-storage",role:"status",children:s?"Não foi possível guardar estas marcações no aparelho. Elas continuam nesta tela, mas podem desaparecer ao sair.":"As marcações são guardadas somente neste navegador quando o aparelho permite. Não informe dados de pacientes. O navegador pode apagar os dados salvos."}),e.jsx("ul",{className:"starter-checklist-items",children:W.map((t,u)=>{const m=a.includes(t.id);return e.jsxs("li",{className:m?"is-complete":"",children:[e.jsxs("label",{htmlFor:`${r}-${t.id}`,children:[e.jsx("input",{id:`${r}-${t.id}`,type:"checkbox",checked:m,onChange:()=>i(m?a.filter(h=>h!==t.id):[...a,t.id])}),e.jsxs("span",{children:[e.jsx("span",{className:"starter-item-number",children:String(u+1).padStart(2,"0")}),e.jsx("strong",{children:t.title}),m&&e.jsx(xe,{className:"starter-item-check",size:18,"aria-hidden":"true"})]})]}),e.jsxs("div",{className:"starter-item-body",children:[e.jsx("p",{children:t.detail}),e.jsxs("a",{href:t.href,children:["Revisar assunto relacionado ",e.jsx(R,{size:16,"aria-hidden":"true"})]}),e.jsxs("p",{className:"starter-source",children:["Base: ",t.sourceLabel,".",t.sourcePage&&e.jsxs(e.Fragment,{children:[" ",e.jsxs("a",{href:`${ns}#page=${t.sourcePage}`,target:"_blank",rel:"noopener noreferrer",children:["Conferir no caderno ",e.jsx(T,{size:14,"aria-hidden":"true"})]})]})]})]})]},t.id)})}),e.jsxs("div",{className:"starter-checklist-bottom",children:[a.length===W.length&&e.jsx("p",{role:"status",children:"Roteiro marcado. Continue levando suas dúvidas ao preceptor e respeitando a supervisão em cada atividade."}),e.jsx("button",{className:"starter-secondary",onClick:()=>i([]),disabled:a.length===0,children:"Desmarcar todos os itens"})]}),e.jsx("p",{className:"starter-review",children:"Conteúdo educativo baseado nos módulos e no caderno do projeto. A organização e os fluxos locais devem ser apresentados pela equipe. Revisão clínica e institucional pendente."})]})}const Ce=40,ds=["0–9",..."ABCDEFGHIJKLMNOPQRSTUVWXYZ"];function cs({renderFavorite:a,initialTerm:o,initialQuery:s}){const n=ee.find(x=>x.id===o),[r,i]=d.useState(()=>(n==null?void 0:n.term)??s??""),[t,u]=d.useState(()=>n==null?void 0:n.id),[m,h]=d.useState(""),[f,C]=d.useState(Ce),b=d.useRef(null),A=d.useRef(null),y=d.useRef(null),j=d.useRef(null),q=d.useId(),E=ds,c=Qo(r).filter(x=>(!m||x.group===m)&&(!t||x.id===t)),l=c.slice(0,f);d.useEffect(()=>{const x=ee.find(v=>v.id===o);i((x==null?void 0:x.term)??s??""),u(x==null?void 0:x.id),h(""),C(Ce),j.current=null},[o,s]),d.useEffect(()=>{var v,z;const x=j.current;x!==null&&(j.current=null,(z=(v=y.current)==null?void 0:v.querySelectorAll(".starter-term")[x])==null||z.focus())},[f,r,m,t]);function p(x){j.current=null,u(void 0),i(x),h(""),C(Ce)}function N(){var x;p(""),(x=b.current)==null||x.focus()}return e.jsxs("section",{className:"starter-glossary","aria-labelledby":`${q}-heading`,children:[e.jsxs("div",{className:"starter-intro",children:[e.jsx(ha,{size:25,"aria-hidden":"true"}),e.jsxs("div",{children:[e.jsx("h2",{id:`${q}-heading`,children:"Siglas e significados"}),e.jsx("p",{children:"Pesquise uma sigla ou uma palavra da definição. Consulte os termos dentro do aplicativo, inclusive offline após o primeiro carregamento completo."})]})]}),e.jsxs("form",{className:"glossary-controls",role:"search","aria-label":"Pesquisar no siglário",onSubmit:x=>{var v;x.preventDefault(),(v=A.current)==null||v.focus()},children:[e.jsxs("label",{className:"starter-search",htmlFor:`${q}-search`,children:[e.jsx(ha,{size:20,"aria-hidden":"true"}),e.jsx("span",{className:"sr-only",children:"Pesquisar siglas e termos do siglário"}),e.jsx("input",{ref:b,id:`${q}-search`,type:"search","aria-label":"Pesquisar siglas e termos do siglário",autoComplete:"off",enterKeyHint:"search",placeholder:"Ex.: CVC, saturação ou balanço hídrico",value:r,onChange:x=>p(x.target.value)}),r&&e.jsx("button",{type:"button","aria-label":"Limpar pesquisa do siglário",onClick:N,children:e.jsx(_e,{size:19,"aria-hidden":"true"})})]}),e.jsxs("label",{className:"glossary-initial-filter",htmlFor:`${q}-initial`,children:[e.jsx("span",{children:"Filtrar por inicial"}),e.jsxs("select",{id:`${q}-initial`,value:m,onChange:x=>{j.current=null,u(void 0),h(x.target.value),C(Ce)},children:[e.jsx("option",{value:"",children:"Todas as iniciais"}),E.map(x=>e.jsx("option",{value:x,children:x},x))]})]})]}),e.jsx("h3",{className:"glossary-results-heading",ref:A,tabIndex:-1,children:"Resultados do siglário"}),e.jsxs("p",{className:"starter-results",role:"status","aria-live":"polite","aria-atomic":"true",children:[c.length===1?"1 termo encontrado":`${c.length} termos encontrados`,r?` para “${r}”`:"",m?` com inicial ${m}`:"",". Mostrando ",l.length," de ",c.length,". O siglário tem ",ee.length," entradas."]}),e.jsx("div",{ref:y,className:"starter-glossary-grid",id:`${q}-results`,children:l.map(x=>e.jsxs("article",{className:"starter-term",id:`glossary-${x.id}`,tabIndex:-1,"aria-labelledby":`${q}-term-${x.id}`,children:[e.jsxs("div",{className:"starter-term-top",children:[e.jsx("h3",{id:`${q}-term-${x.id}`,children:x.term}),a==null?void 0:a(x.id)]}),e.jsx("p",{children:x.definition}),x.supplement&&e.jsx("p",{children:x.supplement}),x.reviewNote&&e.jsxs("div",{className:"glossary-review-note",children:[e.jsx("strong",{children:"Conferir com a fonte"}),e.jsx("p",{children:x.reviewNote})]}),x.href&&e.jsxs("a",{className:"starter-related",href:x.href,children:["Explorar assunto relacionado ",e.jsx(R,{size:17,"aria-hidden":"true"})]}),x.reference&&e.jsx("div",{className:"starter-term-source",children:e.jsxs("a",{href:x.reference.href,target:"_blank",rel:"noopener noreferrer",children:[x.reference.label," ",e.jsx(T,{size:15,"aria-hidden":"true"})]})}),x.sourceLabel!==Qe.label&&e.jsx("p",{className:"starter-term-source",children:x.sourceLabel})]},x.id))}),l.length<c.length&&e.jsx("button",{className:"starter-secondary glossary-more",type:"button","aria-controls":`${q}-results`,onClick:()=>{j.current=l.length,C(x=>x+Ce)},children:"Mostrar mais termos"}),!c.length&&e.jsxs("div",{className:"starter-empty",children:[e.jsx("h3",{children:"Nenhum termo encontrado."}),e.jsx("p",{children:"Tente outra sigla ou palavra da definição, ou limpe a pesquisa e o filtro."}),e.jsx("button",{className:"starter-secondary",type:"button",onClick:N,children:"Mostrar todos os termos"})]}),e.jsx("p",{className:"starter-review glossary-transcription-source",children:"Transcrição fornecida para este projeto, a partir do glossário indicado no Google Looker Studio, com atualizações enviadas pelo responsável, que informou conferência com a instituição. Essa confirmação foi relatada pelo responsável; não representa aprovação institucional do aplicativo. Revisão clínica e institucional do aplicativo pendente."})]})}function ls({initialCase:a}={}){var c;const o=d.useId(),[s,n]=d.useState(((c=Q.find(l=>l.id===a))==null?void 0:c.id)??Q[0].id),[r,i]=d.useState(0),[t,u]=d.useState([]),[m,h]=d.useState(!1),f=d.useRef(null),C=d.useRef(!1),b=Q.find(l=>l.id===s),A=b.steps[r],y=t[r],j=y!==void 0;d.useEffect(()=>{var l;C.current&&((l=f.current)==null||l.focus(),C.current=!1)},[r,m,s]);const q=(l=!0)=>{var p;C.current=l,i(0),u([]),h(!1),l&&r===0&&!m&&((p=f.current)==null||p.focus())};d.useEffect(()=>{const l=Q.find(p=>p.id===a);l&&(n(l.id),i(0),u([]),h(!1))},[a]);const E=()=>{C.current=!0,r+1===b.steps.length?h(!0):i(l=>l+1)};return e.jsxs("section",{className:"case-studies","aria-labelledby":`${o}-title`,children:[e.jsxs("div",{className:"case-heading",children:[e.jsx("span",{className:"case-heading-icon",children:e.jsx(eo,{size:25,"aria-hidden":"true"})}),e.jsxs("div",{children:[e.jsx("h2",{id:`${o}-title`,children:"Aprender com casos simulados"}),e.jsx("p",{children:"Leia a situação, escolha uma atitude e explore a explicação antes de continuar."})]})]}),e.jsx("p",{className:"case-intro",children:"Os cinco casos são fictícios e servem para discussão com o preceptor. Não recebem dados de pacientes nem certificam competência clínica. Revisão clínica e institucional pendente."}),e.jsxs("div",{className:"case-panel",children:[e.jsxs("div",{className:"case-selector",children:[e.jsx("label",{htmlFor:`${o}-select`,children:"Escolha um caso"}),e.jsx("select",{id:`${o}-select`,value:s,onChange:l=>{n(l.target.value),q(!1)},children:Q.map(l=>e.jsxs("option",{value:l.id,children:[l.subject," — ",l.title]},l.id))})]}),e.jsxs("div",{className:"case-meta",children:[e.jsx("span",{children:b.subject}),e.jsx("span",{children:m?"Discussão final":`Etapa ${r+1} de ${b.steps.length}`})]}),e.jsx("progress",{className:"case-progress",value:m?b.steps.length:r,max:b.steps.length,"aria-label":"Etapas percorridas neste caso"}),e.jsxs("p",{className:"case-goal",children:[e.jsx("strong",{children:"Objetivo do caso:"})," ",b.goal]}),m?e.jsxs("div",{className:"case-complete",children:[e.jsx("h3",{ref:f,tabIndex:-1,children:"Leve essa discussão ao preceptor"}),e.jsx("p",{children:b.discussion}),e.jsxs("details",{className:"case-review",children:[e.jsx("summary",{children:"Rever minhas escolhas neste caso"}),e.jsx("ol",{children:b.steps.map((l,p)=>{const N=l.options[t[p]];return e.jsxs("li",{children:[e.jsx("strong",{children:l.question}),e.jsxs("p",{children:["Sua escolha: ",N==null?void 0:N.text]}),e.jsx("p",{children:N==null?void 0:N.feedback}),e.jsxs("p",{className:"case-expected",children:[e.jsx("strong",{children:"Atitude esperada:"})," ",l.options[l.answer].text]})]},l.id)})})]}),e.jsxs("p",{className:"case-learning-note",children:["Você percorreu ",b.steps.length," decisões para estudo. Este exercício não é uma avaliação de paciente ou habilitação para executar cuidados."]}),e.jsxs("button",{className:"case-button",onClick:()=>q(),children:[e.jsx(he,{size:18,"aria-hidden":"true"})," Repetir este caso"]})]}):e.jsxs(e.Fragment,{children:[e.jsx("h3",{ref:f,tabIndex:-1,children:b.title}),e.jsx("p",{className:"case-situation",children:A.situation}),e.jsxs("fieldset",{className:"case-options",disabled:j,children:[e.jsx("legend",{children:A.question}),A.options.map((l,p)=>e.jsxs("button",{className:`case-option${j&&p===A.answer?" case-option-expected":""}${j&&p===y&&y!==A.answer?" case-option-selected":""}`,onClick:()=>u(N=>[...N,p]),children:[e.jsx("span",{className:"case-option-letter","aria-hidden":"true",children:String.fromCharCode(65+p)}),e.jsxs("span",{children:[l.text,j&&p===y&&e.jsx("span",{className:"case-choice-label",children:"Sua escolha"}),j&&p===A.answer&&e.jsxs("span",{className:"case-choice-label",children:[e.jsx(xe,{size:15,"aria-hidden":"true"})," Atitude esperada"]})]})]},l.text))]}),j&&e.jsxs("div",{className:"case-feedback",role:"status","aria-live":"polite","aria-atomic":"true",children:[e.jsx("strong",{children:y===A.answer?"Essa escolha favorece o cuidado seguro.":"Vamos refletir sobre essa escolha."}),e.jsx("p",{children:A.options[y].feedback}),y!==A.answer&&e.jsxs("p",{children:[e.jsx("strong",{children:"Atitude esperada:"})," ",A.options[A.answer].text]})]}),j&&e.jsxs("button",{className:"case-button",onClick:E,children:[r+1===b.steps.length?"Ver discussão final":"Continuar o caso",e.jsx(R,{size:18,"aria-hidden":"true"})]})]}),e.jsxs("div",{className:"case-sources",children:[e.jsxs("h4",{children:[e.jsx(D,{size:18,"aria-hidden":"true"})," Base para estudar"]}),e.jsxs("a",{href:b.relatedModule.href,children:[b.relatedModule.label,e.jsx(R,{size:16,"aria-hidden":"true"})]}),b.sources.map(l=>e.jsxs("a",{...K(l.href),children:[l.label,e.jsx(T,{size:16,"aria-hidden":"true"}),e.jsx("span",{className:"sr-only",children:" (abre em outra aba)"})]},l.href)),e.jsx("p",{children:"Casos adaptados dos conteúdos do projeto. As referências e os créditos permanecem no material original."})]})]}),e.jsx(V,{contentId:`case.${b.id}`,compact:!0})]})}const U=(a,o)=>({label:o,href:`#${a}`}),_=(a,o)=>({label:`Caderno CTI Adulto — ${o}, página ${a}`,href:`/materiais/caderno-cti-adulto-digital.pdf#page=${a}`,page:a}),us=[{text:"Durante o cuidado, um monitor dispara um alarme. Qual é a atitude mais adequada ao estagiário?",refs:[U("equipamentos","Equipamentos — monitor multiparamétrico"),_(4,"referências e metas: resultados inesperados")]},{text:"Qual anotação oferece melhor rastreabilidade?",refs:[U("registros","Anotações de enfermagem"),_(38,"anotação de enfermagem")]},{text:"Um colega pede uma foto do prontuário para estudar em casa. Como agir?",refs:[U("acolhimento","Bem-vindo à CTI — ética, sigilo e humanização")]},{text:"Caso simulado: uma pessoa compreende instruções e consegue comunicar sua dor. Qual princípio orienta a avaliação?",refs:[U("escalas","Escalas clínicas — avaliação da dor"),_(10,"escolha da escala de dor")]},{text:"Caso simulado: a resposta verbal não pode ser testada por uma limitação. O que fazer ao avaliar Glasgow?",refs:[U("escalas","Escalas clínicas — Glasgow"),_(20,"Glasgow: componentes não testáveis")]},{text:"Há dúvida sobre a liberação de uma sonda para administrar dieta. Qual a conduta?",refs:[U("dispositivos","Dispositivos — sonda nasoenteral"),_(25,"sondas e dieta enteral")]},{text:"Um ventilador apresenta um alarme durante a mobilização. Qual ação é apropriada?",refs:[U("equipamentos","Equipamentos — ventilador mecânico"),_(8,"via aérea e alarmes")]},{text:"Um volume de eliminação não pôde ser medido. Como registrar?",refs:[U("registros","Anotações de enfermagem — eliminações e balanço"),_(24,"balanço e função renal"),_(38,"anotação de enfermagem")]}],ms=new Map([...us.map(a=>[a.text,a.refs]),...Aa.map(a=>[a.text,[U(a.moduleId,a.label.replaceAll("Glossário","Siglário")),...a.page?[_(a.page,"material de apoio à questão")]:[]]])]);function ps(a){return ms.get(a)??[]}function fs(){const[a,o]=d.useState("Todos"),[s,n]=d.useState([]),[r,i]=d.useState(0),t=d.useRef(null),u=d.useRef(null),m=d.useRef(null),h=d.useId(),f=ra.filter(l=>a==="Todos"||l.subject===a),C=f[r],b=r>=f.length,A=s[r],y=A!==void 0,j=C?ps(C.text):[];d.useEffect(()=>{var p;const l=m.current;l&&(m.current=null,(p=l==="feedback"?u.current:t.current)==null||p.focus())},[a,r,b,y]);function q(){m.current="heading",n([]),i(0)}function E(){m.current="heading",i(l=>l+1)}function c(l){y||(m.current="feedback",n(p=>p[r]===void 0?[...p,l]:p))}return e.jsxs("section",{className:"quiz panel","aria-label":"Quiz de revisão",children:[e.jsxs("p",{className:"quiz-intro",children:["Banco com ",e.jsxs("strong",{children:[ra.length," questões de revisão"]}),". Escolha um assunto ou pratique todos os temas e leia a explicação após cada resposta."]}),e.jsxs("label",{className:"filter",children:["Escolha um assunto ",e.jsx("select",{value:a,onChange:l=>{o(l.target.value),q()},children:["Todos",...new Set(ra.map(l=>l.subject))].map(l=>e.jsx("option",{children:l},l))})]}),b?e.jsxs("div",{role:"status",className:"quiz-result",children:[e.jsx("span",{className:"module-icon",children:e.jsx(fe,{size:35,"aria-hidden":"true"})}),e.jsx("h2",{ref:t,tabIndex:-1,children:"Uma nova etapa no seu aprendizado."}),e.jsxs("p",{children:["Você acertou ",e.jsxs("strong",{children:[Jo(f,s)," de ",f.length]})," questões."]}),e.jsx("p",{children:"Continue explorando os módulos e leve suas dúvidas ao preceptor. Este resultado não certifica competência clínica."}),e.jsxs("button",{className:"button",onClick:q,children:["Refazer quiz ",e.jsx(R,{size:17,"aria-hidden":"true"})]})]}):e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"quiz-meta",children:[e.jsxs("span",{id:`${h}-number`,children:["QUESTÃO ",r+1," DE ",f.length]}),e.jsx("span",{children:C.subject})]}),e.jsx("div",{className:"progress-track",children:e.jsx("span",{style:{width:`${r/f.length*100}%`}})}),e.jsx("h2",{ref:t,tabIndex:-1,"aria-describedby":`${h}-number`,children:C.text}),e.jsxs("fieldset",{disabled:y,children:[e.jsx("legend",{className:"sr-only",children:"Selecione uma resposta"}),C.options.map((l,p)=>e.jsxs("button",{className:`answer ${y?p===C.answer?"correct":p===A?"incorrect":"":""}`,onClick:()=>c(p),children:[e.jsx("b",{children:String.fromCharCode(65+p)}),e.jsxs("span",{className:"quiz-answer-copy",children:[e.jsx("span",{children:l}),y&&(p===A||p===C.answer)&&e.jsxs("span",{className:"quiz-answer-labels",children:[p===A&&e.jsx("span",{className:"quiz-answer-state",children:"Sua escolha"}),p===C.answer&&e.jsxs("span",{className:"quiz-answer-state",children:[e.jsx(xe,{size:16,"aria-hidden":"true"})," Resposta esperada"]})]})]})]},l))]}),y&&e.jsxs("div",{ref:u,role:"status",className:"feedback",tabIndex:-1,"aria-labelledby":`${h}-feedback-title`,"aria-describedby":`${h}-feedback-text`,children:[e.jsx("strong",{id:`${h}-feedback-title`,children:A===C.answer?"Resposta correta.":"Vamos aprender com essa resposta."}),e.jsx("p",{id:`${h}-feedback-text`,children:C.explanation}),e.jsxs("button",{className:"button",onClick:E,children:[r===f.length-1?"Ver resultado":"Próxima questão",e.jsx(R,{size:17,"aria-hidden":"true"})]}),e.jsxs("div",{className:"question-references",children:[e.jsx("h3",{children:"Materiais de apoio à questão"}),e.jsx("ul",{children:j.map(l=>e.jsx("li",{children:l.href.startsWith("#")?e.jsx("a",{href:l.href,children:l.label}):e.jsxs("a",{...K(l.href),children:[l.label,e.jsx("span",{className:"sr-only",children:" — abre o PDF em outra aba"})]})},l.href))}),e.jsx("p",{children:"Base: conteúdos educativos já fornecidos ao projeto. Revisão clínica e institucional pendente; estas fontes não representam aprovação profissional."})]})]})]})]})}function hs(){const a=d.useId();return e.jsxs("section",{className:"pav-guide","aria-labelledby":`${a}-measures`,children:[e.jsxs("div",{className:"pav-guide-heading",children:[e.jsx("h3",{id:`${a}-measures`,children:"Medidas de prevenção"}),e.jsx("p",{children:"Confira a aplicação com o preceptor. O conjunto de medidas precisa ser adaptado ao protocolo adotado pelo serviço e à condição de cada pessoa."})]}),e.jsx("ol",{className:"pav-measures",role:"list",children:so.map((o,s)=>e.jsxs("li",{children:[e.jsxs("div",{className:"pav-measure-heading",children:[e.jsx("span",{className:"pav-measure-number","aria-hidden":"true",children:String(s+1).padStart(2,"0")}),e.jsx("h4",{children:o.title})]}),e.jsx("p",{children:o.detail}),o.scope&&e.jsx("p",{className:"pav-measure-scope",children:o.scope})]},o.id))}),e.jsxs("section",{className:"pav-sources","aria-labelledby":`${a}-sources`,children:[e.jsxs("h3",{id:`${a}-sources`,children:[e.jsx(D,{size:21,"aria-hidden":"true"}),"Fontes e referências"]}),e.jsx("ul",{role:"list",children:ro.map(o=>e.jsx("li",{children:e.jsxs("a",{...K(o.href),children:[e.jsx("span",{children:o.label}),e.jsx(T,{size:17,"aria-hidden":"true"}),K(o.href).target&&e.jsx("span",{className:"sr-only",children:" (abre em nova aba)"})]})},o.id))})]})]})}const vs=["Módulo","Assunto","Escala","Siglário","Ferramenta","PDF","Caso simulado"];function Ae(a){return a.normalize("NFKD").replace(/[\u0300-\u036f]/g,"").toLowerCase().replace(/[^a-z0-9]+/g," ").trim().replace(/\s+/g," ")}const xs={acolhimento:["acolhimento","integração","primeiro dia"],rotinas:["rotina","plantão"],equipamentos:["equipamentos","aparelhos"],escalas:["escalas","escalas de dor","sedação"],dispositivos:["dispositivos","cateteres","sondas"],registros:["registros","anotação","anotações"],quiz:["quiz","questões","perguntas","teste de conhecimentos"],biblioteca:["biblioteca","materiais","apostilas","PDF"],"acolher-familia":["família","familiares","acolhimento familiar","humanização","comunicação com a família"]},pa={acolhimento:Na.flatMap(a=>[a.title,a.text,a.example]).join(" "),visitante:[...Sa.flatMap(a=>[a.title,a.text,a.attention]),sa.unit,sa.reportedRule,sa.note].join(" "),falas:Re.flatMap(a=>[a.title,a.recommended,a.avoid,a.explanation]).join(" "),simulador:be.flatMap(a=>[a.title,a.situation,a.question,a.explanation,...a.options.flatMap(o=>[o.text,o.feedback])]).join(" "),material:[Ee.fullTitle,...Ee.pages.flatMap(a=>{var o;return[a.title,...((o=a.blocks)==null?void 0:o.flatMap(s=>[s.title,s.text]))??[]]})].join(" ")},po=[...k.map(a=>({id:`module.${a.id}`,title:a.title,kind:"Módulo",description:a.description,href:`#${a.id}`,aliases:xs[a.id]??[],body:a.id==="acolher-familia"?[a.label,...Object.values(pa)].join(" "):a.label})),...k.flatMap(a=>a.topics.map(o=>{var i,t,u;const s=Ye(a.id,o.title),n=a.id==="escalas"?de.find(m=>s===`#escalas/${m.id}`):void 0,r=a.id==="rotinas"&&o.title===J.title;return{id:ce(a.id,o.title),title:o.title,kind:n||a.id==="escalas"?"Escala":"Assunto",description:o.purpose,href:s,aliases:[...n?[n.label,n.name]:[],...r?["PAV","bundle de PAV","bundle PAV","pneumonia associada à ventilação mecânica"]:[]],body:[a.title,o.care,o.risk,...r?[Xo]:[],...n?[n.category,n.purpose,...n.when,...n.howToRead,...n.care,...n.measures.flatMap(m=>[m.title,m.detail]),n.criteria.intro,n.criteria.method,n.criteria.example??"",...((i=n.criteria.steps)==null?void 0:i.flatMap(m=>[m.title,m.detail]))??[],...((t=n.criteria.domains)==null?void 0:t.flatMap(m=>[m.title,...m.levels.map(h=>h.criterion)]))??[],...((u=n.levelGuide)==null?void 0:u.flatMap(m=>[m.label,m.description]))??[]]:[]].join(" ")}})),...ee.map(a=>({id:`term.${a.id}`,title:a.term,kind:"Siglário",description:a.definition,href:`#glossario/${a.id}`,aliases:[a.id,...a.aliases],body:[a.sourceLabel,a.supplement??""].join(" ")})),{id:"tool.primeiro-dia",title:"Checklist do primeiro dia",kind:"Ferramenta",description:"Um roteiro marcável para conhecer o setor com seu preceptor.",href:"#primeiro-dia",aliases:["checklist","meu primeiro dia","roteiro de integração"],body:W.flatMap(a=>[a.title,a.detail]).join(" ")},{id:"tool.glossario",title:"Siglário",kind:"Ferramenta",description:"Consulte as 746 siglas e definições da transcrição enviada para o projeto, dentro do aplicativo.",href:"#glossario",aliases:["siglas","siglário","glossário","glossário de siglas","termos"],body:""},{id:"tool.favoritos",title:"Meus favoritos",kind:"Ferramenta",description:"Consulte os conteúdos que você marcou para rever neste navegador.",href:"#favoritos",aliases:["favoritos","favorito","conteúdos salvos"],body:""},{id:"tool.caderno",title:"Caderno digital",kind:"Ferramenta",description:"Leia o Caderno CTI Adulto no aplicativo, uma página por vez.",href:"#caderno",aliases:["livro","caderno CTI Adulto","ler caderno","continuar leitura"],body:te[0].description},...ae.map(a=>({...a,kind:"Ferramenta",aliases:[...a.aliases],body:a.id==="tool.laboratorio"?fi:a.id==="tool.integracao"?Z.flatMap(o=>[o.title,o.detail]).join(" "):a.id==="tool.cti-virtual"?ne.flatMap(o=>[o.title,o.description]).join(" "):""})),...re.map(a=>({id:`annotation.${a.id}`,title:a.title,kind:"Ferramenta",description:a.goal,href:`#laboratorio/${a.id}`,aliases:["exercício de anotação","anotação simulada","laboratório de anotações"],body:[...a.facts.map(o=>o.text),...a.missingData].join(" ")})),...ne.map(a=>({id:`virtual.${a.id}`,title:`CTI virtual — ${a.title}`,kind:"Ferramenta",description:a.description,href:"#cti-virtual",aliases:["box fictício","desenho educativo","equipamento ilustrado"],body:a.title})),...Ke.map(a=>({id:`family.section.${a.id}`,title:a.title,kind:"Assunto",description:a.description,href:se(a.id),aliases:["acolhimento familiar",...a.id==="visitante"?["visitante","paciente sedado"]:a.id==="material"?["folheto para familiares","imprimir folheto","material para entregar ao familiar"]:[]],body:pa[a.id]??""})),...Re.map(a=>({id:`family.speech.${a.id}`,title:a.title,kind:"Assunto",description:a.recommended,href:se("falas"),aliases:["o que dizer","o que evitar","comunicação com familiares"],body:[a.avoid,a.explanation].join(" ")})),...be.map(a=>({id:`family.case.${a.id}`,title:a.title,kind:"Caso simulado",description:a.situation,href:Pa(a.id),aliases:["simulador de comunicação","caso familiar","situação fictícia"],body:[a.question,a.explanation,...a.options.flatMap(o=>[o.text,o.feedback])].join(" ")})),...Ze.map(a=>({id:`material.${a.id}`,title:a.title,kind:"PDF",description:a.description,href:se("material"),aliases:["folheto família","PDF para familiares",a.layout==="booklet-a4"?"A4 dobrado frente e verso":"A5 ordem de leitura"],body:pa.material})),...te.map(a=>({id:`material.${a.id}`,title:a.title,kind:"PDF",description:a.description,href:`#biblioteca/${a.id}`,aliases:a.use==="print"?["PDF para imprimir","caderno de bolso","quatro páginas por A4"]:["caderno PDF","PDF digital"],body:[a.originalFilename,`${a.pages} páginas`,"PDF Biblioteca"].join(" ")})),...ge.map(a=>({id:`material.${a.id}`,title:a.title,kind:"PDF",description:a.description,href:`#biblioteca/${a.id}`,aliases:[`Apostila ${a.title}`],body:[a.downloadFilename,`${a.pages} páginas`,"apostila PDF Biblioteca"].join(" ")})),...Q.map(a=>({id:`case.${a.id}`,title:a.title,kind:"Caso simulado",description:a.summary,href:`#quiz/${a.id}`,aliases:["caso simulado",`caso ${a.subject}`],body:[a.subject,a.goal,a.discussion,...a.steps.flatMap(o=>[o.situation,o.question,...o.options.flatMap(s=>[s.text,s.feedback])])].join(" ")}))],gs=po.map(({aliases:a,body:o,...s})=>s),bs=po.map((a,o)=>{const s=Ae(a.title),n=a.aliases.map(Ae),r=Ae(a.description),i=[s,...n,r,Ae(a.body)].join(" "),t=ae.some(u=>u.id===a.id)?750:950;return{result:gs[o],index:o,title:s,aliases:n,description:r,text:i,tokens:i.split(" "),exactAliasScore:t}}),Xa={Escala:0,Assunto:1,Siglário:2,Ferramenta:3,PDF:4,"Caso simulado":5,Módulo:6};function js(a,o=""){const s=Ae(a);if(!s)return[];const n=[...new Set(s.split(" "))];return bs.flatMap(r=>{if(o&&r.result.kind!==o)return[];if(!n.every(t=>r.text.includes(t)))return[];let i=0;return r.title===s?i=1e3:r.aliases.includes(s)?i=r.exactAliasScore:r.title.startsWith(s)?i=800:r.title.includes(s)?i=700:n.every(t=>r.title.includes(t))?i=650:r.aliases.some(t=>t.includes(s))?i=600:n.every(t=>[r.title,...r.aliases].join(" ").includes(t))?i=550:r.description.includes(s)&&(i=250),n.every(t=>r.tokens.includes(t))?i+=1e4:n.every(t=>r.tokens.some(u=>u.startsWith(t)))&&(i+=5e3),r.result.title===a.trim()&&(i+=2e4),i+=n.reduce((t,u)=>t+(r.title.includes(u)?8:r.aliases.some(m=>m.includes(u))?5:r.description.includes(u)?2:0),0),[{...r,score:i}]}).sort((r,i)=>i.score-r.score||Xa[r.result.kind]-Xa[i.result.kind]||r.index-i.index).map(r=>r.result)}const oe=8,Cs=["PAV","RASS","Curativos"];function qs({query:a,onQueryChange:o}){const s=d.useId(),n=d.useRef(null),r=d.useRef(null),i=d.useRef(null),t=d.useRef(null),[u,m]=d.useState(""),[h,f]=d.useState({query:a,category:u,limit:oe}),C=a.trim().length>0,b=C?js(a,u):[],A=h.query===a&&h.category===u?h.limit:oe,y=b.slice(0,A);d.useEffect(()=>{var N,x;const p=t.current;p!==null&&(t.current=null,(x=(N=i.current)==null?void 0:N.querySelectorAll("a")[p])==null||x.focus())},[A,a,u]);const j=u?` na categoria ${u}`:"",q=C?b.length===0?`Nenhum resultado encontrado para “${a.trim()}”${j}.`:`${b.length===1?"1 resultado encontrado":`${b.length} resultados encontrados`} para “${a.trim()}”${j}. Mostrando ${y.length} de ${b.length}.`:"";function E(p){var N,x;p.preventDefault(),C?(N=r.current)==null||N.focus():(x=n.current)==null||x.focus()}function c(){var p;t.current=null,o(""),m(""),f({query:"",category:"",limit:oe}),(p=n.current)==null||p.focus()}function l(p){var N;t.current=null,o(p),m(""),f({query:p,category:"",limit:oe}),(N=n.current)==null||N.focus()}return e.jsxs("section",{className:"home-search","aria-labelledby":`${s}-title`,children:[e.jsx("h2",{id:`${s}-title`,tabIndex:-1,children:"Pesquisar no app"}),e.jsx("p",{className:"home-search-intro",children:"Encontre assuntos, escalas, termos e materiais pelo nome."}),e.jsxs("form",{role:"search","aria-label":"Pesquisar no app",onSubmit:E,children:[e.jsx("label",{className:"home-search-sr-only",htmlFor:`${s}-input`,children:"Pesquisar pelo nome ou assunto"}),e.jsxs("div",{className:"home-search-controls",children:[e.jsxs("div",{className:"home-search-field",children:[e.jsx(ha,{size:21,"aria-hidden":"true"}),e.jsx("input",{ref:n,id:`${s}-input`,type:"search",autoComplete:"off",placeholder:"Ex.: PAV, RASS, bomba de infusão...",value:a,onChange:p=>{const N=p.target.value;t.current=null,f({query:N,category:u,limit:oe}),o(N)},enterKeyHint:"search"}),a.length>0&&e.jsx("button",{className:"home-search-clear",type:"button",onClick:c,"aria-label":"Limpar pesquisa",title:"Limpar pesquisa",children:e.jsx(_e,{size:21,"aria-hidden":"true"})})]}),e.jsx("button",{className:"home-search-submit",type:"submit",children:"Buscar"})]}),e.jsxs("div",{className:"home-search-category",children:[e.jsx("label",{htmlFor:`${s}-category`,children:"Categoria da pesquisa"}),e.jsxs("select",{id:`${s}-category`,value:u,onChange:p=>{const N=p.target.value;t.current=null,m(N),f({query:a,category:N,limit:oe})},children:[e.jsx("option",{value:"",children:"Todas as categorias"}),vs.map(p=>e.jsx("option",{children:p},p))]})]})]}),e.jsxs("div",{className:"home-search-shortcuts","aria-label":"Atalhos de pesquisa",children:[e.jsx("span",{children:"Busca rápida:"}),Cs.map(p=>e.jsx("button",{type:"button",onClick:()=>l(p),"aria-label":`Pesquisar ${p}`,children:p},p))]}),e.jsx("p",{className:"home-search-status",role:"status","aria-live":"polite","aria-atomic":"true",children:q}),C&&e.jsxs("div",{className:"home-search-results",children:[e.jsx("h3",{ref:r,tabIndex:-1,children:"Resultados da pesquisa"}),b.length===0?e.jsxs("div",{className:"home-search-empty",children:[e.jsx("p",{children:"Tente outro nome ou uma palavra do assunto que você procura."}),e.jsx("button",{type:"button",onClick:c,children:"Limpar pesquisa"})]}):e.jsxs(e.Fragment,{children:[e.jsx("ul",{ref:i,id:`${s}-results`,className:"home-search-list",children:y.map(p=>e.jsx("li",{children:e.jsxs("a",{href:p.href,...p.external?{target:"_blank",rel:"noopener noreferrer"}:{},children:[e.jsxs("div",{className:"home-search-result-copy",children:[e.jsx("span",{className:"home-search-kind",children:p.kind}),e.jsx("h4",{children:p.title}),e.jsx("p",{children:p.description}),p.external&&e.jsx("span",{className:"home-search-sr-only",children:"Abre em nova aba."})]}),e.jsx(R,{size:21,"aria-hidden":"true"})]})},p.id))}),y.length<b.length&&e.jsxs("button",{className:"home-search-more",type:"button","aria-controls":`${s}-results`,onClick:()=>{t.current=y.length,f({query:a,category:u,limit:A+oe})},children:["Mostrar mais resultados",e.jsx(Za,{size:19,"aria-hidden":"true"})]})]})]})]})}const As=d.lazy(()=>ja(()=>import("./FamilyWelcome-wbhGX3ID.js"),__vite__mapDeps([0,1,2]))),Ns=d.lazy(()=>ja(()=>import("./BookReader-B-owekCN.js"),__vite__mapDeps([3,1,4]))),Ss=d.lazy(()=>ja(()=>import("./PdfReader-D-tbJd6c.js"),__vite__mapDeps([5,1,6]))),Ps=[Ne,So,me,va,$e,yo,fe,Ve,Ya];function ys(){try{const a=JSON.parse(localStorage.getItem("cti-visited")||"[]");return Array.isArray(a)?[...new Set(a.filter(o=>typeof o=="string"&&k.some(s=>s.id===o)))]:[]}catch{return[]}}function Es(){const a=Ma(),[o,s]=d.useState(location.hash.slice(1)||"inicio"),[n,r]=o.split("?"),[i,t]=n.split("/"),u=new URLSearchParams(r).get("q")??void 0,m=es(),[h,f]=d.useState(""),[C,b]=d.useState(""),[A,y]=d.useState(ys),[j,q]=d.useState(null),[E,c]=d.useState(null),[l,p]=d.useState(!navigator.onLine),N=d.useRef(null),x=d.useRef(null);d.useEffect(()=>{const g=()=>{s(location.hash.slice(1)||"inicio"),q(null),b(""),window.scrollTo(0,0)},I=ue=>{ue.preventDefault(),c(ue)},w=()=>p(!navigator.onLine);return window.addEventListener("hashchange",g),window.addEventListener("beforeinstallprompt",I),window.addEventListener("online",w),window.addEventListener("offline",w),()=>{window.removeEventListener("hashchange",g),window.removeEventListener("beforeinstallprompt",I),window.removeEventListener("online",w),window.removeEventListener("offline",w)}},[]),d.useEffect(()=>{k.some(I=>I.id===i)&&y(I=>{const w=[...new Set([...I,i])];try{localStorage.setItem("cti-visited",JSON.stringify(w))}catch{}return w});const g=i==="inicio"||i==="modulos"?document.querySelector(".home-search h2"):N.current;g==null||g.focus({preventScroll:!0})},[o]),d.useEffect(()=>{const g=k.find(I=>I.id===i);q((g==null?void 0:g.topics.find(I=>!(i==="escalas"&&Je(I.title))&&Fa(i,I.title,t)))??null)},[o]),d.useEffect(()=>{if(i!=="biblioteca"||!t)return;const g=document.getElementById(`material-${t}`);if(!g)return;const I=requestAnimationFrame(()=>{g.scrollIntoView({block:"start",behavior:"auto"}),g.focus({preventScroll:!0})});return()=>cancelAnimationFrame(I)},[o]);const v=k.find(g=>g.id===i),z=Ai(t),le=Object.assign(Object.create(null),{"primeiro-dia":"Checklist do primeiro dia",glossario:"Siglário",favoritos:"Meus favoritos"},Object.fromEntries(ae.map(g=>[g.href.slice(1),g.title]))),fo=g=>{var w;const I=(w=k.find(ue=>ue.id==="escalas"))==null?void 0:w.topics.find(ue=>ue.title===oi(g));return I?e.jsx(B,{id:ce("escalas",I.title)}):null},Te=i==="modulos"||!!(v&&i!=="biblioteca"&&i!=="escalas"),we=i==="biblioteca"||i==="caderno"||i==="pdf"&&!!z,F=(g,I=i===g)=>i===g?"page":I?"location":void 0;d.useEffect(()=>{const g=v==null?void 0:v.topics.find(w=>Fa(i,w.title,t)),I=(g==null?void 0:g.title)||(v==null?void 0:v.title)||le[i]||(i==="inicio"?"Início":i==="modulos"?"Módulos de aprendizado":i==="projeto"?"Sobre o projeto":i==="caderno"?"Caderno CTI Adulto":i==="pdf"&&z?z.title:"Página não encontrada");document.title=`${I} • Conhecendo a CTI`},[o]);const ho=()=>{const g=Hi();a.resetProfile(),y([]),m.clear(),f(g?"Perfil, marcações dos dois checklists, favoritos, página de leitura e visitas apagados deste navegador.":"O navegador não permitiu apagar todos os dados salvos. Verifique as configurações de armazenamento.")};return e.jsxs(e.Fragment,{children:[e.jsx("a",{className:"skip-link",href:"#conteudo-principal",onClick:g=>{var I,w;g.preventDefault(),(I=x.current)==null||I.focus({preventScroll:!0}),(w=x.current)==null||w.scrollIntoView({block:"start"})},children:"Pular para o conteúdo"}),e.jsxs("aside",{className:"sidebar",children:[e.jsxs("a",{className:"brand",href:"#inicio",children:[e.jsx("span",{className:"brand-symbol",children:e.jsx(Ne,{})}),e.jsxs("span",{children:["Conhecendo",e.jsxs("span",{className:"brand-line",children:["a CTI",e.jsx("span",{className:"brand-dot",children:"."})]})]})]}),e.jsx("div",{className:"sidebar-caption",children:"APRENDIZAGEM NA CTI ADULTO"}),e.jsxs("nav",{"aria-label":"Navegação principal",children:[e.jsxs("a",{className:i==="inicio"?"active":"","aria-current":F("inicio"),href:"#inicio",children:[e.jsx(aa,{size:19}),"Visão geral"]}),e.jsxs("a",{className:Te?"active":"","aria-current":F("modulos",Te),href:"#modulos",children:[e.jsx(D,{size:19}),"Módulos de aprendizado",e.jsx("span",{className:"nav-count",children:k.length})]}),e.jsxs("a",{className:i==="escalas"?"active":"","aria-current":F("escalas"),href:"#escalas",children:[e.jsx(me,{size:19}),"Escalas clínicas"]}),e.jsxs("a",{className:we?"active":"","aria-current":F("biblioteca",we),href:"#biblioteca",children:[e.jsx(Ve,{size:19}),"Biblioteca científica"]}),e.jsxs("a",{className:i==="projeto"?"active":"","aria-current":F("projeto"),href:"#projeto",children:[e.jsx(ka,{size:19}),"Sobre o projeto"]}),e.jsx("div",{className:"tools-caption",children:"FERRAMENTAS DE ESTUDO"}),e.jsxs("a",{className:i==="primeiro-dia"?"active":"","aria-current":F("primeiro-dia"),href:"#primeiro-dia",children:[e.jsx(Y,{size:19}),"Meu primeiro dia"]}),e.jsxs("a",{className:i==="glossario"?"active":"","aria-current":F("glossario"),href:"#glossario",children:[e.jsx(fa,{size:19}),"Siglário"]}),e.jsxs("a",{className:i==="favoritos"?"active":"","aria-current":F("favoritos"),href:"#favoritos",children:[e.jsx(Pe,{size:19}),"Meus favoritos"]}),ae.map(g=>e.jsxs("a",{href:g.href,className:g.href===`#${i}`?"active":"","aria-current":g.href===`#${i}`?"page":void 0,children:[e.jsx(D,{size:19}),g.title]},g.id))]}),e.jsxs("div",{className:"sidebar-bottom",children:[e.jsx("div",{className:"student-icon",children:e.jsx(fe,{})}),e.jsx("strong",{children:"Aprender para cuidar melhor."}),e.jsx("p",{children:"Um passo de cada vez, com conhecimento e segurança."}),e.jsx("span",{className:"pilot-dot"})," Projeto-piloto educativo"]}),e.jsx("div",{className:"sidebar-footer",children:"PBL · ENFERMAGEM INTENSIVA"})]}),e.jsxs("div",{className:"page",children:[e.jsxs("header",{className:"topbar",children:[e.jsx("span",{children:"Seu espaço de aprendizado"}),e.jsxs("div",{children:[e.jsxs("span",{className:"badge",children:[e.jsx("span",{})," Protótipo educativo"]}),e.jsx(ba,{compact:!0}),e.jsx("span",{className:"avatar",children:e.jsx(va,{size:19})})]})]}),e.jsxs("main",{ref:x,id:"conteudo-principal",tabIndex:-1,children:[e.jsxs("div",{className:"breadcrumb",children:[e.jsx("a",{href:"#inicio",children:"Início"}),i!=="inicio"&&e.jsxs(e.Fragment,{children:[e.jsx(No,{size:14}),e.jsx("span",{children:(v==null?void 0:v.title)||le[i]||(i==="projeto"?"Sobre o projeto":i==="caderno"?"Caderno digital":i==="pdf"?"Documento em PDF":"Módulos")})]})]}),l&&e.jsxs("div",{role:"status",className:"notice",children:[e.jsx(Oo,{size:18})," Você está offline. Conteúdos salvos neste dispositivo continuam disponíveis; links externos precisam de conexão."]}),i!=="inicio"&&i!=="modulos"&&e.jsx(ss,{route:i}),i==="inicio"||i==="modulos"?e.jsxs(e.Fragment,{children:[e.jsx(qs,{query:C,onQueryChange:b}),!C.trim()&&e.jsxs(e.Fragment,{children:[e.jsx(Vi,{}),e.jsxs("section",{className:"welcome",children:[e.jsxs("div",{children:[e.jsx("div",{className:"eyebrow",children:"CONHECIMENTO QUE ACOLHE"}),e.jsxs("h1",{ref:N,tabIndex:-1,children:["Seu primeiro passo",e.jsx("br",{}),"para cuidar com ",e.jsx("em",{children:"confiança."})]}),e.jsxs("p",{children:["Bem-vindo ao ",e.jsx("strong",{children:"Conhecendo a CTI."})," Um guia interativo para apoiar estagiários e novos colaboradores de enfermagem na CTI Adulto."]}),e.jsxs("a",{className:"button",href:"#acolhimento",children:["Começar a aprender ",e.jsx(R,{size:17})]}),e.jsxs("span",{className:"hero-note",children:[e.jsx($e,{size:14})," Sem cadastro. No seu ritmo."]})]}),e.jsxs("div",{className:"hero-art","aria-hidden":"true",children:[e.jsx("div",{className:"art-orbit"}),e.jsxs("div",{className:"art-monitor",children:[e.jsxs("div",{className:"monitor-label",children:[e.jsx("span",{})," MONITORIZAÇÃO"]}),e.jsx("svg",{viewBox:"0 0 250 85",children:e.jsx("path",{d:"M0 50H47l8-10 8 20 9-47 10 62 10-25h34l8-11 8 20 9-46 11 62 10-25h68"})}),e.jsxs("div",{className:"monitor-stats",children:[e.jsxs("span",{children:["♥ ",e.jsx("b",{children:"CTI"})]}),e.jsxs("span",{children:["+ ",e.jsx("b",{children:"CUIDADO"})]})]})]}),e.jsx("div",{className:"monitor-neck"}),e.jsx("div",{className:"monitor-base"}),e.jsxs("div",{className:"art-tag tag-one",children:[e.jsx($e,{})," Segurança em cada cuidado"]}),e.jsxs("div",{className:"art-tag tag-two",children:[e.jsx(Ne,{})," Aprendizado que faz a diferença"]}),e.jsx("div",{className:"art-plus",children:"+"})]})]}),e.jsxs("section",{className:"journey",children:[e.jsx("div",{className:"journey-icon",children:e.jsx(D,{})}),e.jsxs("div",{children:[e.jsx("strong",{children:"Sua jornada de aprendizado"}),e.jsx("p",{children:"Explore os módulos e construa seu conhecimento."})]}),e.jsxs("div",{className:"progress-info",children:[e.jsxs("strong",{children:[A.length,e.jsxs("span",{children:[" de ",k.length," módulos visitados"]})]}),e.jsx("div",{className:"progress-track",children:e.jsx("span",{style:{width:`${A.length/k.length*100}%`}})})]})]}),e.jsx(is,{}),e.jsxs("section",{className:"module-section",children:[e.jsx("div",{className:"section-heading",children:e.jsxs("div",{children:[e.jsx("span",{className:"eyebrow",children:"EXPLORE E APRENDA"}),e.jsx("h2",{children:"Módulos de aprendizado"}),e.jsx("p",{children:"Conteúdos para estudo, ambientação e integração à CTI Adulto."})]})}),e.jsx("div",{className:"module-grid",children:k.map(g=>{const I=k.indexOf(g),w=Ps[I];return e.jsxs("article",{className:"module-tile",children:[e.jsxs("a",{className:"module-card",href:`#${g.id}`,children:[e.jsxs("div",{className:"card-top",children:[e.jsx("span",{className:`module-icon color-${I}`,children:e.jsx(w,{size:25})}),e.jsx("span",{className:"module-number",children:A.includes(g.id)?e.jsx(xe,{size:16}):String(I+1).padStart(2,"0")})]}),e.jsx("h3",{children:g.title}),e.jsx("p",{children:g.description}),e.jsxs("div",{className:"card-bottom",children:[e.jsx("span",{children:g.label}),e.jsx(T,{size:18})]})]}),e.jsx(B,{id:`module.${g.id}`})]},g.id)})}),e.jsx(yi,{}),e.jsx(rs,{}),e.jsxs("div",{className:"learning-tip",children:[e.jsx("span",{className:"tip-icon",children:e.jsx(va,{})}),e.jsxs("div",{children:[e.jsx("strong",{children:"O cuidado começa com uma boa base."}),e.jsx("p",{children:"Explore, tire dúvidas com seu preceptor e transforme conhecimento em cuidado."})]}),e.jsx("span",{className:"tip-decoration",children:"+"})]})]})]})]}):v?e.jsxs(e.Fragment,{children:[e.jsxs("a",{className:"back",href:"#modulos",children:[e.jsx(Le,{size:16})," Todos os módulos"]}),e.jsxs("div",{className:"eyebrow",children:["MÓDULO ",String(k.indexOf(v)+1).padStart(2,"0")," · CONTEÚDO DEMONSTRATIVO"]}),e.jsxs("div",{className:"module-heading-row",children:[e.jsx("h1",{ref:N,tabIndex:-1,className:"page-title",children:v.title}),e.jsx(B,{id:`module.${v.id}`})]}),e.jsx("p",{className:"page-description",children:v.description}),i==="acolhimento"&&e.jsxs("a",{className:"button",href:"#primeiro-dia",children:["Abrir checklist do primeiro dia ",e.jsx(Y,{size:17})]}),i==="acolher-familia"?e.jsx(d.Suspense,{fallback:e.jsx("p",{role:"status",children:"Preparando o módulo de acolhimento familiar…"}),children:e.jsx(As,{initialSection:t,initialCase:new URLSearchParams(r).get("caso")??void 0})}):i==="quiz"?e.jsxs(e.Fragment,{children:[e.jsx(ls,{initialCase:t}),e.jsx("h2",{className:"scales-extra-heading",children:"Quiz de revisão"}),e.jsx(fs,{})]}):i==="biblioteca"?e.jsxs(e.Fragment,{children:[e.jsx(Pi,{}),e.jsx(Ei,{}),e.jsx(Ii,{}),e.jsx("h2",{className:"sources-heading",children:"Fontes de consulta"}),e.jsx("p",{className:"library-intro",children:"Portais de consulta para aprofundamento. Os links não significam validação deste protótipo. Cada conteúdo precisa de revisão técnica e bibliográfica antes do uso no estágio."}),e.jsx("div",{className:"topic-grid",children:Wo.map(g=>e.jsxs("a",{className:"topic-card source",href:g.url,target:"_blank",rel:"noopener noreferrer",children:[e.jsx(Ve,{}),e.jsx("h2",{children:g.title}),e.jsx("p",{children:g.description}),e.jsxs("span",{children:["Consultar fonte oficial ",e.jsx(T,{size:16})]})]},g.url))}),e.jsxs("div",{className:"panel",children:[e.jsx("h2",{children:"Controle de revisão"}),e.jsx("p",{children:"Todos os módulos: revisão técnica e validação de referências pendentes. Data da revisão clínica: não realizada. Responsável técnico: a definir."}),e.jsx("p",{children:"Os módulos trazem introduções, sem calculadora clínica. Os cadernos anexados incluem quadros de escalas e suas referências."})]})]}):e.jsxs(e.Fragment,{children:[i==="escalas"&&e.jsx(e.Fragment,{children:e.jsx(wi,{initialScale:t,renderFavorite:fo,onOpenGlasgow:()=>q(v.topics.find(g=>g.title.includes("Glasgow"))??null)})}),e.jsx("div",{className:"topic-grid",children:(i==="escalas"?[]:v.topics).map((g,I)=>e.jsxs("article",{className:"topic-tile",children:[e.jsxs("button",{className:"topic-card",onClick:()=>q(g),children:[i==="equipamentos"?e.jsx("span",{className:"equipment-art",children:I===1||I===5||I===6?e.jsx(Do,{}):I===2||I===3?e.jsx(wo,{}):e.jsx(zo,{})}):e.jsx("span",{className:"topic-index",children:String(I+1).padStart(2,"0")}),e.jsx("h2",{children:g.title}),e.jsx("p",{children:g.purpose}),e.jsxs("span",{children:["Explorar conteúdo ",e.jsx(R,{size:16})]})]}),e.jsx(B,{id:ce(i,g.title)})]},g.title))}),e.jsx(Mi,{moduleId:i}),i==="escalas"&&e.jsxs("a",{className:"button",href:"#quiz",children:["Praticar com casos simulados ",e.jsx(R,{size:16})]}),e.jsxs("div",{className:"panel",children:[e.jsx("strong",{children:"Revisão clínica: pendente"}),e.jsxs("p",{children:["Material demonstrativo. Consulte a ",e.jsx("a",{href:"#biblioteca",children:"biblioteca científica"})," e valide o conteúdo com os responsáveis pelo estágio."]})]})]}),e.jsx(V,{contentId:`module.${v.id}`})]}):le[i]?e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"eyebrow",children:"FERRAMENTAS DE ESTUDO"}),e.jsx("h1",{ref:N,tabIndex:-1,className:"page-title",children:le[i]}),e.jsxs("nav",{className:"tools-nav","aria-label":"Ferramentas de estudo",children:[e.jsxs("a",{href:"#primeiro-dia","aria-current":i==="primeiro-dia"?"page":void 0,children:[e.jsx(Y,{size:17}),"Primeiro dia"]}),e.jsxs("a",{href:"#glossario","aria-current":i==="glossario"?"page":void 0,children:[e.jsx(fa,{size:17}),"Siglário"]}),e.jsxs("a",{href:"#favoritos","aria-current":i==="favoritos"?"page":void 0,children:[e.jsx(Pe,{size:17}),"Favoritos"]})]}),i==="primeiro-dia"?e.jsxs(e.Fragment,{children:[e.jsx(B,{id:"tool.primeiro-dia"}),e.jsx(ts,{})]}):i==="glossario"?e.jsxs(e.Fragment,{children:[e.jsx(B,{id:"tool.glossario"}),e.jsx(cs,{initialTerm:Object.hasOwn(ye,`term.${t}`)?ye[`term.${t}`].replace(/^term\./,""):t,initialQuery:u,renderFavorite:g=>e.jsx(B,{id:`term.${g}`})}),t&&e.jsx(V,{contentId:`term.${t}`})]}):i==="favoritos"?e.jsx(os,{}):i==="perfil"?e.jsx(ba,{}):i==="integracao"?e.jsx(Gi,{}):i==="laboratorio"?e.jsx(Ui,{initialScenario:t}):i==="cti-virtual"?e.jsx(Xi,{}):i==="avaliacao-pbl"?e.jsx(Ji,{}):i==="demonstracao"?e.jsx(Zi,{}):e.jsx(Si,{}),i!=="glossario"&&i!=="conteudos"&&e.jsx(V,{contentId:`tool.${i}`})]}):i==="caderno"?e.jsxs(e.Fragment,{children:[e.jsxs("a",{className:"back",href:"#biblioteca",children:[e.jsx(Le,{size:16})," Voltar à Biblioteca"]}),e.jsx("div",{className:"eyebrow",children:"LEITURA DIGITAL"}),e.jsx("h1",{ref:N,tabIndex:-1,className:"page-title",children:"Caderno CTI Adulto"}),e.jsx("p",{className:"page-description",children:"Uma página por vez. Deslize para os lados ou use os botões para continuar a leitura."}),e.jsx(B,{id:"tool.caderno"}),e.jsx(d.Suspense,{fallback:e.jsx("p",{role:"status",children:"Preparando o leitor…"}),children:e.jsx(Ns,{})}),e.jsx(V,{contentId:"tool.caderno"})]}):i==="pdf"&&z?e.jsx(d.Suspense,{fallback:e.jsxs("div",{className:"panel",children:[e.jsxs("a",{className:"back",href:`#biblioteca/${z.id}`,children:[e.jsx(Le,{size:16})," Voltar à biblioteca"]}),e.jsxs("a",{className:"back",href:"#inicio",children:[e.jsx(aa,{size:16})," Início"]}),e.jsx("p",{role:"status",children:"Preparando acesso ao documento…"})]}),children:e.jsx(Ss,{material:z,initialPage:new URLSearchParams(r).get("page")},z.id)}):i==="projeto"?e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"eyebrow",children:"APRENDIZAGEM BASEADA EM PROBLEMAS"}),e.jsx("h1",{ref:N,tabIndex:-1,className:"page-title",children:"Conhecimento que aproxima."}),e.jsx("p",{className:"page-description",children:"Um projeto PBL para apoiar a chegada de estagiários e novos colaboradores à CTI Adulto."}),e.jsx(Wi,{}),e.jsxs("div",{className:"panel",children:[e.jsx("h2",{children:"Privacidade"}),e.jsx("p",{children:"Não solicitamos nome, matrícula ou informações de pacientes. A escolha de perfil, as visitas, as marcações dos dois checklists, os favoritos e a última página do caderno são armazenados somente neste navegador. O texto do laboratório e as respostas da avaliação ficam apenas na sessão; não são enviados ou salvos automaticamente. A avaliação permite exportação manual de respostas fechadas, com consentimento. Eles não representam conclusão ou certificação. Não há sincronização entre aparelhos; limpar os dados do navegador remove esse progresso. A hospedagem pode manter registros técnicos de acesso conforme sua política."}),e.jsx("button",{className:"secondary",onClick:ho,children:"Apagar meus dados de aprendizado"}),h&&e.jsx("p",{role:"status",className:"project-clear-status",children:h}),e.jsx("h2",{children:"Adicionar à tela inicial"}),e.jsx(Yo,{}),E&&e.jsxs("button",{className:"button",onClick:async()=>{await E.prompt(),await E.userChoice,c(null)},children:[e.jsx(pe,{size:18})," Instalar aplicativo"]}),e.jsx("p",{children:"O aplicativo usa o endereço informado pelo autor. O QR Code continua válido enquanto esse endereço for mantido nas atualizações."})]})]}):e.jsxs("div",{className:"panel",children:[e.jsx("h1",{ref:N,tabIndex:-1,children:"Página não encontrada"}),e.jsx("a",{href:"#inicio",children:"Voltar ao início"})]}),e.jsxs("footer",{children:[e.jsxs("div",{children:[e.jsx(Ne,{size:18}),e.jsx("strong",{children:"Conhecendo a CTI"}),e.jsx("span",{children:"Aprender. Acolher. Cuidar."})]}),e.jsx("p",{children:"Conteúdo educativo e demonstrativo. Não substitui protocolos institucionais ou supervisão do enfermeiro."}),e.jsx("span",{children:"Projeto-piloto PBL · Revisão clínica pendente"})]})]})]}),e.jsxs("nav",{className:"mobile-nav","aria-label":"Navegação móvel",children:[e.jsxs("a",{className:i==="inicio"?"active":"","aria-current":F("inicio"),href:"#inicio",children:[e.jsx(aa,{}),"Início"]}),e.jsxs("a",{className:Te?"active":"","aria-current":F("modulos",Te),href:"#modulos",children:[e.jsx(D,{}),"Módulos"]}),e.jsxs("a",{className:i==="escalas"?"active":"","aria-current":F("escalas"),href:"#escalas",children:[e.jsx(me,{}),"Escalas"]}),e.jsxs("a",{className:we?"active":"","aria-current":F("biblioteca",we),href:"#biblioteca",children:[e.jsx(Ve,{}),"Biblioteca"]}),e.jsxs("a",{className:i==="projeto"?"active":"","aria-current":F("projeto"),href:"#projeto",children:[e.jsx(ka,{}),"Projeto"]})]}),j&&e.jsx(Ms,{topic:j,moduleId:i,close:()=>q(null)})]})}function Ms({topic:a,moduleId:o,close:s}){const n=d.useRef(null);return d.useEffect(()=>{const r=n.current,i=document.activeElement;return r==null||r.showModal(),()=>{r!=null&&r.open&&r.close(),i instanceof HTMLElement&&i.isConnected&&i.focus({preventScroll:!0})}},[]),e.jsxs("dialog",{ref:n,onCancel:r=>{r.preventDefault(),s()},onClick:r=>{r.target===n.current&&s()},"aria-labelledby":"detail-title",children:[e.jsxs("div",{className:"dialog-top",children:[e.jsx("span",{className:"eyebrow",children:"GUIA EDUCATIVO · DEMONSTRAÇÃO"}),e.jsx("button",{className:"icon-button",onClick:s,"aria-label":"Fechar conteúdo",children:e.jsx(_e,{})})]}),e.jsx("h2",{id:"detail-title",children:a.title}),e.jsx("div",{className:"detail-favorite",children:e.jsx(B,{id:ce(o,a.title)})}),e.jsx(mo,{moduleId:o,topicTitle:a.title}),e.jsx("h3",{children:"Finalidade e contexto"}),e.jsx("p",{children:a.purpose}),e.jsx("h3",{children:"Cuidados e atuação do técnico"}),e.jsx("p",{children:a.care}),e.jsxs("div",{className:"review-note",children:[e.jsx($e,{}),e.jsxs("div",{children:[e.jsx("strong",{children:"Atenção à segurança"}),e.jsx("p",{children:a.risk})]})]}),o==="rotinas"&&a.title===J.title&&e.jsx(hs,{}),e.jsx(V,{contentId:ce(o,a.title)}),e.jsxs("a",{href:"#biblioteca",onClick:s,children:["Consultar fontes na biblioteca ",e.jsx(T,{size:14})]})]})}vo.createRoot(document.getElementById("root")).render(e.jsx(xo.StrictMode,{children:e.jsx(as,{children:e.jsx(Li,{children:e.jsx(Es,{})})})}));"serviceWorker"in navigator&&window.addEventListener("load",()=>{navigator.serviceWorker.register("/sw.js").catch(()=>{})});export{Le as A,D as B,xe as C,pe as D,B as F,Ya as H,Ro as L,eo as M,To as P,he as R,$e as S,R as a,Na as b,sa as c,Re as d,Be as e,Ke as f,be as g,P as h,qa as i,T as j,No as k,Ee as l,Ni as m,aa as n,V as o,Bi as r,Rs as s,Sa as v};
