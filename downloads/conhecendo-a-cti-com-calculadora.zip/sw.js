const CACHE = 'cti-938cecb18315';
const PDF_CACHE = CACHE + '-apostilas';
const FILES = ["/","/index.html","/icon.svg","/icon-192.png","/icon-512.png","/manifest.webmanifest","/assets/BookReader-DM4O_-ah.js","/assets/BookReader-iSPfZ99S.css","/assets/Calculator-Bn0Zg-Og.js","/assets/Calculator-DaYHjAGB.css","/assets/FamilyWelcome-BhvNenP7.css","/assets/FamilyWelcome-DBlkjU2O.js","/assets/PdfReader-BCyel6lV.css","/assets/PdfReader-DFfQLIvU.js","/assets/index-BcOgEkDr.css","/assets/index-CqtDZSPE.js","/assets/react-vendor-CycvGi9z.js","/materiais/caderno-cti-adulto-bolso-a4.pdf","/materiais/caderno-cti-adulto-digital.pdf","/caderno/pagina-001.webp","/caderno/pagina-002.webp","/caderno/pagina-003.webp","/caderno/pagina-004.webp","/caderno/pagina-005.webp","/caderno/pagina-006.webp","/caderno/pagina-007.webp","/caderno/pagina-008.webp","/caderno/pagina-009.webp","/caderno/pagina-010.webp","/caderno/pagina-011.webp","/caderno/pagina-012.webp","/caderno/pagina-013.webp","/caderno/pagina-014.webp","/caderno/pagina-015.webp","/caderno/pagina-016.webp","/caderno/pagina-017.webp","/caderno/pagina-018.webp","/caderno/pagina-019.webp","/caderno/pagina-020.webp","/caderno/pagina-021.webp","/caderno/pagina-022.webp","/caderno/pagina-023.webp","/caderno/pagina-024.webp","/caderno/pagina-025.webp","/caderno/pagina-026.webp","/caderno/pagina-027.webp","/caderno/pagina-028.webp","/caderno/pagina-029.webp","/caderno/pagina-030.webp","/caderno/pagina-031.webp","/caderno/pagina-032.webp","/caderno/pagina-033.webp","/caderno/pagina-034.webp","/caderno/pagina-035.webp","/caderno/pagina-036.webp","/caderno/pagina-037.webp","/caderno/pagina-038.webp","/caderno/pagina-039.webp","/caderno/pagina-040.webp","/caderno/pagina-041.webp","/caderno/pagina-042.webp","/caderno/pagina-043.webp","/caderno/pagina-044.webp","/caderno/pagina-045.webp","/caderno/pagina-046.webp","/caderno/pagina-047.webp","/caderno/pagina-048.webp","/caderno/pagina-049.webp","/caderno/pagina-050.webp","/caderno/pagina-051.webp","/caderno/pagina-052.webp","/caderno/pagina-053.webp","/caderno/pagina-054.webp","/caderno/pagina-055.webp","/caderno/pagina-056.webp","/caderno/pagina-057.webp","/caderno/pagina-058.webp","/caderno/pagina-059.webp","/caderno/pagina-060.webp","/caderno/pagina-061.webp","/caderno/pagina-062.webp","/caderno/pagina-063.webp","/caderno/pagina-064.webp","/caderno/pagina-065.webp","/caderno/pagina-066.webp","/caderno/pagina-067.webp","/caderno/pagina-068.webp","/caderno/pagina-069.webp","/caderno/pagina-070.webp","/caderno/pagina-071.webp","/caderno/pagina-072.webp","/caderno/pagina-073.webp","/caderno/pagina-074.webp","/caderno/pagina-075.webp","/caderno/pagina-076.webp","/caderno/pagina-077.webp","/caderno/pagina-078.webp","/caderno/pagina-079.webp","/caderno/pagina-080.webp","/caderno/pagina-081.webp","/caderno/pagina-082.webp","/caderno/pagina-083.webp","/caderno/pagina-084.webp","/caderno/pagina-085.webp","/caderno/pagina-086.webp","/caderno/pagina-087.webp","/caderno/pagina-088.webp","/caderno/pagina-089.webp","/caderno/pagina-090.webp","/caderno/pagina-091.webp","/caderno/pagina-092.webp","/caderno/pagina-093.webp","/caderno/pagina-094.webp","/caderno/pagina-095.webp","/caderno/pagina-096.webp","/caderno/paginas.json","/materiais/acolher-familia/folheto-familia-a4.pdf","/materiais/acolher-familia/folheto-familia-a5.pdf","/materiais/acolher-familia/manifest.json","/materiais/apostilas/integridade.json"];
const APOSTILAS = new Set(["/materiais/apostilas/cuidados-paciente-critico.pdf","/materiais/apostilas/curativos-feridas.pdf","/materiais/apostilas/evolucao-anotacao-enfermagem.pdf","/materiais/apostilas/medicacoes-bombas-infusao.pdf","/materiais/apostilas/monitorizacao-equipamentos.pdf"]);

self.addEventListener('install', event => {
  // Large apostilas are saved only when opened; the caderno remains precached.
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(FILES)));
});

self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(
    keys.filter(key => key.startsWith('cti-') && key !== CACHE && key !== PDF_CACHE)
      .map(key => caches.delete(key))
  )).then(() => self.clients.claim()));
});

function completePdf(response) {
  return response && response.status === 200 && !response.headers.has('content-range')
    && response.headers.get('content-type')?.split(';')[0].trim().toLowerCase() === 'application/pdf';
}

function ifRangeMatches(response, ifRange) {
  if (!ifRange) return true;
  const value = ifRange.trim();
  if (value.startsWith('"') || value.startsWith('W/')) {
    return !value.startsWith('W/') && response.headers.get('etag') === value;
  }
  const limit = Date.parse(value);
  const modified = Date.parse(response.headers.get('last-modified') || '');
  return Number.isFinite(limit) && Number.isFinite(modified) && modified <= limit;
}

async function rangeResponse(response, range, ifRange) {
  // Unsupported/multiple ranges may legally receive the entire representation.
  const match = range?.trim().match(/^bytes=(\d*)-(\d*)$/i);
  if (!match || (!match[1] && !match[2]) || !ifRangeMatches(response, ifRange)) return response;
  const bytes = await response.arrayBuffer();
  const size = bytes.byteLength;
  let start;
  let end;
  if (!match[1]) {
    const suffix = Number(match[2]);
    start = Math.max(0, size - suffix);
    end = size - 1;
  } else {
    start = Number(match[1]);
    end = match[2] ? Math.min(Number(match[2]), size - 1) : size - 1;
  }
  const headers = new Headers(response.headers);
  headers.delete('content-encoding');
  headers.set('accept-ranges', 'bytes');
  if (size === 0 || start > end || start >= size) {
    headers.set('content-range', 'bytes */' + size);
    headers.set('content-length', '0');
    return new Response(null, { status: 416, statusText: 'Range Not Satisfiable', headers });
  }
  const body = bytes.slice(start, end + 1);
  headers.set('content-range', 'bytes ' + start + '-' + end + '/' + size);
  headers.set('content-length', String(body.byteLength));
  return new Response(body, { status: 206, statusText: 'Partial Content', headers });
}

async function apostilaResponse(request, pathname, background) {
  // Ignore URL query strings in the cache key: only the curated pathname is saved.
  const key = new URL(pathname, self.location.origin).href;
  const cache = await caches.open(PDF_CACHE).catch(() => null);
  const cached = await cache?.match(key, { ignoreVary: true }).catch(() => undefined);
  if (completePdf(cached)) {
    return rangeResponse(cached, request.headers.get('range'), request.headers.get('if-range'));
  }
  // A native PDF viewer may request just a small range. Fetch one complete PDF
  // so that later ranges and offline reads never depend on a partial cache entry.
  const headers = new Headers(request.headers);
  for (const header of ['range', 'if-range', 'if-none-match', 'if-modified-since']) headers.delete(header);
  const response = await fetch(new Request(request, { headers, cache: 'no-store' }));
  if (!completePdf(response)) return response;
  if (cache) {
    // Storage/quota errors must not prevent reading the online response.
    background.push(cache.put(key, response.clone()).catch(() => undefined));
  }
  return rangeResponse(response, request.headers.get('range'), request.headers.get('if-range'));
}

self.addEventListener('fetch', event => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin) return;
  if (APOSTILAS.has(url.pathname)) {
    const background = [];
    const response = apostilaResponse(request, url.pathname, background).catch(() => new Response(
      'Esta apostila ainda não está disponível sem internet. Conecte-se e abra o PDF completo para tentar novamente.',
      { status: 503, headers: { 'content-type': 'text/plain; charset=utf-8' } }
    ));
    event.respondWith(response);
    event.waitUntil(response.then(() => Promise.all(background)).catch(() => undefined));
    return;
  }
  event.respondWith(caches.open(CACHE).then(async cache => {
    if (request.mode === 'navigate' && !url.pathname.toLowerCase().endsWith('.pdf')) {
      try { return await fetch(request); }
      catch { return await cache.match('/index.html', { ignoreVary: true }); }
    }
    return await cache.match(request, { ignoreVary: true }) || fetch(request);
  }));
});
